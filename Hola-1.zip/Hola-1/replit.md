# Mi Bot Empresarial - Cazador de Productos Ganadores

## Overview

Mi Bot Empresarial is an automated e-commerce product analysis platform that uses four specialized bots to discover winning products across multiple marketplaces (eBay, Mercado Libre, Amazon, Walmart, AliExpress). The system leverages AI (OpenAI GPT-5) to analyze products, identify arbitrage opportunities, monitor stock levels, and generate comprehensive Excel reports for business decision-making.

**Core Functionality:**
- **Bot 1**: Analyzes top-selling products on eBay and Mercado Libre
- **Bot 2**: Identifies price arbitrage opportunities across Amazon, Walmart, and AliExpress
- **Bot 3**: Detects low-stock, high-demand products for restocking opportunities
- **Bot 4**: Generates Excel-format reports and manages email distribution

**Target Users:** E-commerce entrepreneurs and dropshippers seeking data-driven product sourcing insights.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript
- Vite for build tooling and development server
- Wouter for client-side routing
- TanStack Query (React Query) for server state management

**UI Framework:**
- shadcn/ui component library (Radix UI primitives)
- Tailwind CSS for styling with custom design system
- Theme: "new-york" style variant with dark mode support

**Design System:**
- Inspired by Linear and Notion for enterprise dashboard aesthetics
- Custom CSS variables for consistent theming across light/dark modes
- Typography: Inter font family for general UI, JetBrains Mono for numerical data
- Spacing system based on Tailwind units (2, 4, 6, 8, 12, 16)
- Custom color palette with HSL-based semantic tokens

**Key Architectural Decisions:**
- **Problem**: Need consistent, accessible UI components
- **Solution**: shadcn/ui provides a copy-paste component system built on Radix UI
- **Pros**: Full control over components, excellent accessibility, TypeScript support
- **Cons**: Components are copied into codebase (not installed as dependency)

**Layout Structure:**
- Collapsible sidebar navigation (18rem width when expanded)
- Main content area with responsive grid layouts (1-3 columns)
- Dashboard-first approach with individual bot detail pages

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js
- TypeScript for type safety
- ESBuild for server bundling (production)
- tsx for development hot-reloading

**Server Organization:**
- Modular route registration pattern
- Separation of concerns: routes, storage, bot logic, report generation
- Middleware for JSON parsing and request logging

**Bot System:**
- Four independent bot types with configurable execution
- AI-powered product generation using OpenAI GPT-5
- Fallback mechanisms when AI is unavailable
- Stateful bot run tracking (pending → executing → completed/error)

**Key Architectural Decisions:**
- **Problem**: Cold start performance in serverless environments
- **Solution**: Bundle frequently-used dependencies (allowlist in build script) to reduce file system calls
- **Rationale**: Reduces openat(2) syscalls which slows initial server startup
- **Pros**: Faster cold starts, smaller dependency tree in production
- **Cons**: Larger bundle size, some dependencies still external

### Data Storage

**Database:**
- PostgreSQL via Neon serverless platform
- Drizzle ORM for type-safe database queries
- WebSocket-based connection pooling (@neondatabase/serverless)

**Schema Design:**
```
products - Stores discovered products with marketplace data
botRuns - Tracks bot execution history and status
settings - User configuration (email, scheduling preferences)
reports - Generated Excel report metadata
marketplaceConnections - OAuth tokens and credentials for Mercado Libre and eBay
publishedListings - Products published to external marketplaces
```

**Key Architectural Decisions:**
- **Problem**: Need type-safe database operations with minimal boilerplate
- **Solution**: Drizzle ORM with schema-first approach and Zod integration
- **Rationale**: Provides full TypeScript inference, SQL-like query builder, and automatic type generation
- **Pros**: Excellent DX, type safety, lightweight, works well with serverless
- **Cons**: Smaller ecosystem than Prisma, less tooling support

**Migration Strategy:**
- Drizzle Kit for schema migrations
- Push-based workflow (drizzle-kit push) for development
- Migrations stored in `/migrations` directory

### AI Integration

**Provider:** OpenAI (via AI_INTEGRATIONS environment variables)
- Model: GPT-5 (hardcoded, only changeable by explicit user request)
- Structured output using JSON mode response format
- System prompts tailored for e-commerce product analysis

**Key Architectural Decisions:**
- **Problem**: Need realistic product data for marketplace analysis
- **Solution**: AI-generated product datasets with marketplace-specific characteristics
- **Rationale**: Simulates real-world data patterns without web scraping infrastructure
- **Alternatives**: Could use real marketplace APIs, but requires authentication and rate limiting
- **Pros**: No external API dependencies, flexible data generation, cost-effective
- **Cons**: Simulated data may not reflect actual market conditions

### Marketplace Integration (OAuth)

**Supported Marketplaces:**
- Mercado Libre (Mexico)
- eBay (International)

**OAuth Flow:**
1. User provides Client ID and Client Secret from marketplace developer portal
2. Backend stores credentials and generates random state parameter (CSRF protection)
3. User is redirected to marketplace OAuth authorization page
4. On callback, backend validates state parameter and exchanges code for tokens
5. Tokens are stored in database for future API calls

**Security Features:**
- State parameter validation for CSRF protection
- Credentials stored securely in database
- Token refresh mechanism for expired tokens

**Publishing Flow:**
1. Connect marketplace accounts via /marketplaces page
2. View products ready for publishing via /publicar page
3. Select products and publish to connected marketplaces
4. Backend creates listings via marketplace APIs

**Frontend Pages:**
- `/marketplaces` - Configure and connect marketplace accounts
- `/publicar` - Publish discovered products to connected marketplaces

### Session Management

**Current State:** Infrastructure present but not actively used
- connect-pg-simple for PostgreSQL session store
- express-session middleware
- Passport.js local strategy configured

**Note:** Application currently operates without authentication, but the foundation exists for future user management.

## External Dependencies

### Core Infrastructure

**Database:**
- Neon PostgreSQL (serverless)
- Connection via DATABASE_URL environment variable
- WebSocket protocol for connection pooling

**AI Services:**
- OpenAI API (GPT-5 model)
- Configuration: AI_INTEGRATIONS_OPENAI_BASE_URL, AI_INTEGRATIONS_OPENAI_API_KEY
- Used for: Product data generation, market analysis

### Build & Development Tools

**Replit-Specific:**
- @replit/vite-plugin-runtime-error-modal - Development error overlay
- @replit/vite-plugin-cartographer - Code navigation
- @replit/vite-plugin-dev-banner - Development mode indicator

**Build Pipeline:**
- Vite for client bundling
- ESBuild for server bundling
- tsx for development server

### UI Components & Styling

**Component Library:**
- Radix UI primitives (18+ packages for dialogs, dropdowns, tooltips, etc.)
- shadcn/ui configuration (components.json defines import paths)

**Styling:**
- Tailwind CSS with PostCSS
- class-variance-authority (CVA) for component variants
- clsx + tailwind-merge for className utilities

### Utilities

**Form Handling:**
- react-hook-form for form state management
- @hookform/resolvers with Zod for validation
- drizzle-zod for schema-to-Zod conversion

**Data Fetching:**
- @tanstack/react-query for async state management
- Custom fetch wrapper in lib/queryClient.ts

**Date & Time:**
- date-fns for date formatting and manipulation

**Report Generation:**
- xlsx library for spreadsheet creation (CSV format)
- PDFKit for PDF report generation with table pagination
- Both export types available via dropdown menu in dashboard

### Potential Future Dependencies

Based on session management infrastructure:
- nodemailer (installed but not actively used for email reports)
- jsonwebtoken (JWT infrastructure present)
- passport/passport-local (authentication system configured but inactive)