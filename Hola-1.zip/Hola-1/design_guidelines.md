# Guías de Diseño: Mi Bot Empresarial

## Enfoque de Diseño
Sistema de diseño empresarial moderno inspirado en Linear y Notion, optimizado para dashboards de datos con controles claros y jerarquía visual fuerte.

## Principios Fundamentales
- **Claridad sobre decoración**: Información accesible y accionable
- **Jerarquía decisiva**: Elementos importantes visualmente prominentes
- **Eficiencia espacial**: Maximizar densidad de información sin saturar

## Tipografía

**Familia de fuentes**: Inter (via Google Fonts)

- **Títulos principales**: text-2xl/text-3xl, font-semibold
- **Títulos de sección**: text-xl, font-semibold
- **Subtítulos/etiquetas**: text-sm, font-medium, text-gray-600
- **Datos destacados**: text-lg/text-xl, font-bold (para precios, ganancias)
- **Texto general**: text-base, font-normal
- **Datos numéricos**: font-mono para precios y estadísticas

## Sistema de Espaciado

Usar unidades Tailwind: **2, 4, 6, 8, 12, 16**
- Padding de tarjetas: p-6
- Espaciado entre secciones: gap-8 o mb-8
- Espaciado interno de componentes: gap-4
- Margenes de contenedores principales: p-8

## Estructura de Layout

### Panel Principal
- Sidebar izquierdo fijo (w-64) con navegación de bots
- Área de contenido principal con max-w-7xl
- Grid de 2-3 columnas para tarjetas de datos (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)

### Componentes Clave

**1. Botón Principal de Excel (Hero Element)**
- Tamaño: Prominente, mínimo py-6 px-12
- Ubicación: Superior derecha del dashboard, siempre visible
- Texto: "Generar Hoja de Cálculo Ahora"
- Icono: Documento/descarga grande
- Tratamiento especial: Border grueso, sombra pronunciada

**2. Tarjetas de Estado de Bots**
Grid de 4 tarjetas con:
- Icono de bot distintivo
- Nombre del bot
- Estado actual (Activo/En espera/Ejecutando)
- Última ejecución
- Botón de ejecución manual
- Indicador de progreso visual

**3. Tablas de Datos de Productos**
- Encabezados sticky
- Filas con hover state
- Columnas: Imagen thumbnail (80x80px), Nombre, Precio origen, Precio destino, Ganancia estimada, Competencia, Acciones
- Ordenamiento por columnas
- Badges para indicadores (Alto stock, Baja competencia, Ganancia alta)

**4. Sección de Configuración**
- Panel colapsable
- Campos para email
- Frecuencia de reportes (mostrar "cada 6 horas" preconfigurado)
- Preferencias de moneda

**5. Dashboard de Métricas**
Cards con números grandes:
- Total de productos encontrados hoy
- Ganancia potencial total
- Oportunidades de arbitraje activas
- Productos con escasez

## Imágenes

**Thumbnails de productos**: 
- Tamaño consistente 80x80px en tablas
- Tamaño 200x200px en vistas detalladas
- Border radius: rounded-lg
- Placeholder con icono de caja si no hay imagen

**No se requiere hero image** - es un dashboard funcional

## Componentes UI

**Botones**:
- Primario: Sólido, prominente para acciones principales
- Secundario: Outline para acciones alternativas
- Terciario: Ghost para acciones menores

**Badges de estado**:
- Ganancia Alta: Verde
- Competencia Baja: Azul
- Stock Bajo: Amarillo/Naranja
- Precio Subió: Rojo

**Cards**:
- Border sutil
- Padding: p-6
- Sombra ligera en hover
- Border radius: rounded-xl

**Tablas**:
- Bordes entre filas
- Background alternado opcional para legibilidad
- Sticky headers en scroll

## Idioma y Localización
- **Toda la interfaz en español**
- Formato de moneda: Mostrar símbolo de moneda original ($, €, USD, MXN, etc.)
- Formato de fecha: dd/mm/yyyy
- Separadores numéricos: punto para miles, coma para decimales (ej: 1.234,56)

## Navegación

Sidebar con:
- Logo/nombre "Mi Bot Empresarial"
- Dashboard (vista general)
- Bot 1: Productos Ganadores
- Bot 2: Arbitraje
- Bot 3: Reabastecimiento
- Bot 4: Reportes
- Configuración
- Historial

## Principios de Interacción
- Estados de carga claros durante ejecución de bots
- Feedback inmediato al presionar botones
- Toasts/notificaciones para confirmaciones
- Sin animaciones distractoras - solo transiciones funcionales (150-200ms)
- Loading spinners en operaciones que toman tiempo