import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Tabla de productos encontrados
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  imageUrl: text("image_url"),
  sourceMarketplace: text("source_marketplace").notNull(), // ebay, mercadolibre, amazon, walmart, aliexpress
  sourceUrl: text("source_url"),
  sourcePrice: real("source_price").notNull(),
  sourceCurrency: text("source_currency").notNull().default("USD"),
  targetMarketplace: text("target_marketplace"), // donde se puede vender
  targetUrl: text("target_url"),
  targetPrice: real("target_price"),
  targetCurrency: text("target_currency"),
  estimatedProfit: real("estimated_profit"),
  profitPercentage: real("profit_percentage"),
  dailySales: integer("daily_sales"),
  competitorCount: integer("competitor_count"),
  stockLevel: text("stock_level"), // alto, medio, bajo, agotado
  demandLevel: text("demand_level"), // alto, medio, bajo
  priceChange: real("price_change"), // cambio de precio en porcentaje
  botType: integer("bot_type").notNull(), // 1, 2, 3, 4
  category: text("category"),
  foundAt: timestamp("found_at").defaultNow(),
  isWorthPublishing: boolean("is_worth_publishing").default(false),
  opportunityStatus: text("opportunity_status").default("pendiente"), // pendiente, aprovechada, perdida
});

// Tabla de ejecuciones de bots
export const botRuns = pgTable("bot_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botType: integer("bot_type").notNull(), // 1, 2, 3, 4
  status: text("status").notNull().default("pendiente"), // pendiente, ejecutando, completado, error
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  productsFound: integer("products_found").default(0),
  errorMessage: text("error_message"),
});

// Tabla de configuración
export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email"),
  scheduleHours: integer("schedule_hours").default(6),
  lastScheduledRun: timestamp("last_scheduled_run"),
  isAutoRunEnabled: boolean("is_auto_run_enabled").default(true),
  minProfitAlert: real("min_profit_alert").default(20),
  minProfitPercentageAlert: real("min_profit_percentage_alert").default(15),
  alertsEnabled: boolean("alerts_enabled").default(true),
  masterPasswordHash: text("master_password_hash"),
  isMasterPasswordEnabled: boolean("is_master_password_enabled").default(false),
});

// Tabla de reportes generados
export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  fileData: text("file_data"), // base64 encoded
  generatedAt: timestamp("generated_at").defaultNow(),
  productCount: integer("product_count").default(0),
  sentByEmail: boolean("sent_by_email").default(false),
});

// Tabla de historial de oportunidades
export const opportunityActions = pgTable("opportunity_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").notNull().references(() => products.id),
  action: text("action").notNull(), // aprovechada, perdida, pendiente
  notes: text("notes"),
  actionAt: timestamp("action_at").defaultNow(),
});

// Tabla de conexiones a marketplaces (OAuth tokens)
export const marketplaceConnections = pgTable("marketplace_connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marketplace: text("marketplace").notNull(), // mercadolibre, ebay
  clientId: text("client_id"), // App ID del desarrollador
  clientSecret: text("client_secret"), // Secret del desarrollador
  oauthState: text("oauth_state"), // CSRF protection state
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  userId: text("user_id"), // ID del usuario en el marketplace
  userName: text("user_name"), // nombre del usuario en el marketplace
  isConnected: boolean("is_connected").default(false),
  connectedAt: timestamp("connected_at"),
  lastRefreshedAt: timestamp("last_refreshed_at"),
});

// Tabla de publicaciones realizadas
export const publishedListings = pgTable("published_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").notNull().references(() => products.id),
  marketplace: text("marketplace").notNull(), // mercadolibre, ebay
  listingId: text("listing_id"), // ID de la publicación en el marketplace
  listingUrl: text("listing_url"), // URL de la publicación
  status: text("status").notNull().default("pendiente"), // pendiente, publicado, error, pausado
  price: real("price"),
  currency: text("currency"),
  errorMessage: text("error_message"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const productsRelations = relations(products, ({ one }) => ({}));
export const botRunsRelations = relations(botRuns, ({ many }) => ({}));

// Insert schemas
export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  foundAt: true,
});

export const insertBotRunSchema = createInsertSchema(botRuns).omit({
  id: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  generatedAt: true,
});

export const insertOpportunityActionSchema = createInsertSchema(opportunityActions).omit({
  id: true,
  actionAt: true,
});

export const insertMarketplaceConnectionSchema = createInsertSchema(marketplaceConnections).omit({
  id: true,
});

export const insertPublishedListingSchema = createInsertSchema(publishedListings).omit({
  id: true,
  createdAt: true,
});

// Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type BotRun = typeof botRuns.$inferSelect;
export type InsertBotRun = z.infer<typeof insertBotRunSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export type OpportunityAction = typeof opportunityActions.$inferSelect;
export type InsertOpportunityAction = z.infer<typeof insertOpportunityActionSchema>;

export type MarketplaceConnection = typeof marketplaceConnections.$inferSelect;
export type InsertMarketplaceConnection = z.infer<typeof insertMarketplaceConnectionSchema>;

export type PublishedListing = typeof publishedListings.$inferSelect;
export type InsertPublishedListing = z.infer<typeof insertPublishedListingSchema>;

// Users table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
