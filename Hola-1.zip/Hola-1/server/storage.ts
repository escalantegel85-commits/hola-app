import { 
  products, 
  botRuns, 
  settings, 
  reports,
  opportunityActions,
  marketplaceConnections,
  publishedListings,
  users,
  type Product, 
  type InsertProduct,
  type BotRun,
  type InsertBotRun,
  type Settings,
  type InsertSettings,
  type Report,
  type InsertReport,
  type OpportunityAction,
  type InsertOpportunityAction,
  type MarketplaceConnection,
  type InsertMarketplaceConnection,
  type PublishedListing,
  type InsertPublishedListing,
  type User,
  type UpsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql, ilike, or } from "drizzle-orm";

export interface ProductFilters {
  botType?: number;
  category?: string;
  marketplace?: string;
  demandLevel?: string;
  stockLevel?: string;
  minPrice?: number;
  maxPrice?: number;
  isWorthPublishing?: boolean;
  limit?: number;
}

export interface TrendDataPoint {
  date: string;
  count: number;
  totalProfit: number;
}

export interface MarketplaceDistribution {
  marketplace: string;
  count: number;
  averageProfit: number;
}

export interface CategoryDistribution {
  category: string;
  count: number;
  totalProfit: number;
}

export interface IStorage {
  // Users (for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Products
  getProducts(botType?: number, limit?: number): Promise<Product[]>;
  getProductsByBotType(botType: number): Promise<Product[]>;
  getFilteredProducts(filters: ProductFilters): Promise<Product[]>;
  getUniqueCategories(): Promise<string[]>;
  getUniqueMarketplaces(): Promise<string[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProductUrls(id: string, sourceUrl: string | null, targetUrl: string | null): Promise<void>;
  updateProductFull(id: string, data: {
    sourceUrl?: string | null;
    targetUrl?: string | null;
    targetMarketplace?: string | null;
    targetPrice?: number | null;
    targetCurrency?: string | null;
    estimatedProfit?: number | null;
    profitPercentage?: number | null;
  }): Promise<void>;
  getProductsFoundToday(): Promise<number>;
  clearAllProducts(): Promise<void>;
  getProductCount(): Promise<number>;
  
  // Analytics
  getProductTrendsByDay(days?: number): Promise<TrendDataPoint[]>;
  getMarketplaceDistribution(): Promise<MarketplaceDistribution[]>;
  getCategoryDistribution(): Promise<CategoryDistribution[]>;
  getProfitTrends(days?: number): Promise<TrendDataPoint[]>;
  
  // Bot Runs
  getBotRuns(limit?: number): Promise<BotRun[]>;
  getLatestBotRun(botType: number): Promise<BotRun | null>;
  getLastScheduledRun(): Promise<BotRun | null>;
  createBotRun(run: InsertBotRun): Promise<BotRun>;
  updateBotRun(id: string, data: Partial<BotRun>): Promise<BotRun | null>;
  
  // Settings
  getSettings(): Promise<Settings | null>;
  updateSettings(data: InsertSettings): Promise<Settings>;
  
  // Reports
  getReports(limit?: number): Promise<Report[]>;
  getReportById(id: string): Promise<Report | null>;
  createReport(report: InsertReport): Promise<Report>;
  markReportAsSent(id: string): Promise<void>;
  
  // Opportunity Actions
  getOpportunityActions(limit?: number): Promise<(OpportunityAction & { product?: Product })[]>;
  getOpportunityActionsByProduct(productId: string): Promise<OpportunityAction[]>;
  createOpportunityAction(action: InsertOpportunityAction): Promise<OpportunityAction>;
  updateProductOpportunityStatus(productId: string, status: string): Promise<Product | null>;
  getOpportunityStats(): Promise<{ taken: number; missed: number; pending: number }>;
  
  // Marketplace Connections
  getMarketplaceConnections(): Promise<MarketplaceConnection[]>;
  getMarketplaceConnection(marketplace: string): Promise<MarketplaceConnection | null>;
  upsertMarketplaceConnection(data: InsertMarketplaceConnection): Promise<MarketplaceConnection>;
  disconnectMarketplace(marketplace: string): Promise<void>;
  
  // Published Listings
  getPublishedListings(limit?: number): Promise<(PublishedListing & { product?: Product })[]>;
  getPublishedListingsByProduct(productId: string): Promise<PublishedListing[]>;
  createPublishedListing(listing: InsertPublishedListing): Promise<PublishedListing>;
  updatePublishedListing(id: string, data: Partial<PublishedListing>): Promise<PublishedListing | null>;
  getProductById(id: string): Promise<Product | null>;
}

export class DatabaseStorage implements IStorage {
  // Users (for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Products
  async getProducts(botType?: number, limit: number = 100): Promise<Product[]> {
    if (botType) {
      return await db.select()
        .from(products)
        .where(eq(products.botType, botType))
        .orderBy(desc(products.foundAt))
        .limit(limit);
    }
    return await db.select()
      .from(products)
      .orderBy(desc(products.foundAt))
      .limit(limit);
  }

  async getProductsByBotType(botType: number): Promise<Product[]> {
    return await db.select()
      .from(products)
      .where(eq(products.botType, botType))
      .orderBy(desc(products.foundAt))
      .limit(50);
  }

  async getFilteredProducts(filters: ProductFilters): Promise<Product[]> {
    const conditions: any[] = [];
    
    if (filters.botType) {
      conditions.push(eq(products.botType, filters.botType));
    }
    if (filters.category) {
      conditions.push(ilike(products.category, `%${filters.category}%`));
    }
    if (filters.marketplace) {
      conditions.push(
        or(
          eq(products.sourceMarketplace, filters.marketplace),
          eq(products.targetMarketplace, filters.marketplace)
        )
      );
    }
    if (filters.demandLevel) {
      conditions.push(eq(products.demandLevel, filters.demandLevel));
    }
    if (filters.stockLevel) {
      conditions.push(eq(products.stockLevel, filters.stockLevel));
    }
    if (filters.minPrice !== undefined) {
      conditions.push(gte(products.sourcePrice, filters.minPrice));
    }
    if (filters.maxPrice !== undefined) {
      conditions.push(lte(products.sourcePrice, filters.maxPrice));
    }
    if (filters.isWorthPublishing !== undefined) {
      conditions.push(eq(products.isWorthPublishing, filters.isWorthPublishing));
    }

    const query = db.select()
      .from(products)
      .orderBy(desc(products.foundAt))
      .limit(filters.limit || 100);

    if (conditions.length > 0) {
      return await query.where(and(...conditions));
    }
    
    return await query;
  }

  async getUniqueCategories(): Promise<string[]> {
    const result = await db.selectDistinct({ category: products.category })
      .from(products)
      .where(sql`${products.category} IS NOT NULL`);
    return result.map(r => r.category).filter((c): c is string => c !== null);
  }

  async getUniqueMarketplaces(): Promise<string[]> {
    const sources = await db.selectDistinct({ marketplace: products.sourceMarketplace })
      .from(products);
    const targets = await db.selectDistinct({ marketplace: products.targetMarketplace })
      .from(products)
      .where(sql`${products.targetMarketplace} IS NOT NULL`);
    
    const allMarketplaces = new Set<string>();
    sources.forEach(s => allMarketplaces.add(s.marketplace));
    targets.forEach(t => t.marketplace && allMarketplaces.add(t.marketplace));
    
    return Array.from(allMarketplaces);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProductUrls(id: string, sourceUrl: string | null, targetUrl: string | null): Promise<void> {
    await db.update(products)
      .set({ sourceUrl, targetUrl })
      .where(eq(products.id, id));
  }

  async updateProductFull(id: string, data: {
    sourceUrl?: string | null;
    targetUrl?: string | null;
    targetMarketplace?: string | null;
    targetPrice?: number | null;
    targetCurrency?: string | null;
    estimatedProfit?: number | null;
    profitPercentage?: number | null;
  }): Promise<void> {
    await db.update(products)
      .set(data)
      .where(eq(products.id, id));
  }

  async getProductsFoundToday(): Promise<number> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(products)
      .where(gte(products.foundAt, today));
    
    return Number(result[0]?.count || 0);
  }

  async clearAllProducts(): Promise<void> {
    await db.delete(products);
  }

  async getProductCount(): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(products);
    return Number(result[0]?.count || 0);
  }

  // Analytics
  async getProductTrendsByDay(days: number = 30): Promise<TrendDataPoint[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    startDate.setHours(0, 0, 0, 0);

    const result = await db.select({
      date: sql<string>`DATE(${products.foundAt})`,
      count: sql<number>`COUNT(*)`,
      totalProfit: sql<number>`COALESCE(SUM(${products.estimatedProfit}), 0)`,
    })
      .from(products)
      .where(gte(products.foundAt, startDate))
      .groupBy(sql`DATE(${products.foundAt})`)
      .orderBy(sql`DATE(${products.foundAt})`);

    return result.map(r => ({
      date: String(r.date),
      count: Number(r.count),
      totalProfit: Number(r.totalProfit),
    }));
  }

  async getMarketplaceDistribution(): Promise<MarketplaceDistribution[]> {
    const result = await db.select({
      marketplace: products.sourceMarketplace,
      count: sql<number>`COUNT(*)`,
      averageProfit: sql<number>`COALESCE(AVG(${products.estimatedProfit}), 0)`,
    })
      .from(products)
      .groupBy(products.sourceMarketplace)
      .orderBy(sql`COUNT(*) DESC`);

    return result.map(r => ({
      marketplace: r.marketplace,
      count: Number(r.count),
      averageProfit: Number(r.averageProfit),
    }));
  }

  async getCategoryDistribution(): Promise<CategoryDistribution[]> {
    const result = await db.select({
      category: products.category,
      count: sql<number>`COUNT(*)`,
      totalProfit: sql<number>`COALESCE(SUM(${products.estimatedProfit}), 0)`,
    })
      .from(products)
      .where(sql`${products.category} IS NOT NULL`)
      .groupBy(products.category)
      .orderBy(sql`COUNT(*) DESC`)
      .limit(10);

    return result.map(r => ({
      category: r.category || "Sin categoría",
      count: Number(r.count),
      totalProfit: Number(r.totalProfit),
    }));
  }

  async getProfitTrends(days: number = 30): Promise<TrendDataPoint[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    startDate.setHours(0, 0, 0, 0);

    const result = await db.select({
      date: sql<string>`DATE(${products.foundAt})`,
      count: sql<number>`COUNT(*)`,
      totalProfit: sql<number>`COALESCE(SUM(${products.estimatedProfit}), 0)`,
    })
      .from(products)
      .where(and(
        gte(products.foundAt, startDate),
        gte(products.estimatedProfit, 0)
      ))
      .groupBy(sql`DATE(${products.foundAt})`)
      .orderBy(sql`DATE(${products.foundAt})`);

    return result.map(r => ({
      date: String(r.date),
      count: Number(r.count),
      totalProfit: Number(r.totalProfit),
    }));
  }

  // Bot Runs
  async getBotRuns(limit: number = 50): Promise<BotRun[]> {
    return await db.select()
      .from(botRuns)
      .orderBy(desc(botRuns.startedAt))
      .limit(limit);
  }

  async getLatestBotRun(botType: number): Promise<BotRun | null> {
    const [run] = await db.select()
      .from(botRuns)
      .where(eq(botRuns.botType, botType))
      .orderBy(desc(botRuns.startedAt))
      .limit(1);
    return run || null;
  }

  async createBotRun(run: InsertBotRun): Promise<BotRun> {
    const [newRun] = await db.insert(botRuns).values(run).returning();
    return newRun;
  }

  async updateBotRun(id: string, data: Partial<BotRun>): Promise<BotRun | null> {
    const [updated] = await db.update(botRuns)
      .set(data)
      .where(eq(botRuns.id, id))
      .returning();
    return updated || null;
  }

  // Settings
  async getSettings(): Promise<Settings | null> {
    const [setting] = await db.select().from(settings).limit(1);
    return setting || null;
  }

  async updateSettings(data: InsertSettings): Promise<Settings> {
    const existing = await this.getSettings();
    if (existing) {
      const [updated] = await db.update(settings)
        .set(data)
        .where(eq(settings.id, existing.id))
        .returning();
      return updated;
    }
    const [newSettings] = await db.insert(settings).values(data).returning();
    return newSettings;
  }

  // Reports
  async getReports(limit: number = 20): Promise<Report[]> {
    return await db.select()
      .from(reports)
      .orderBy(desc(reports.generatedAt))
      .limit(limit);
  }

  async getReportById(id: string): Promise<Report | null> {
    const [report] = await db.select()
      .from(reports)
      .where(eq(reports.id, id))
      .limit(1);
    return report || null;
  }

  async createReport(report: InsertReport): Promise<Report> {
    const [newReport] = await db.insert(reports).values(report).returning();
    return newReport;
  }

  async markReportAsSent(id: string): Promise<void> {
    await db.update(reports)
      .set({ sentByEmail: true })
      .where(eq(reports.id, id));
  }

  async getLastScheduledRun(): Promise<BotRun | null> {
    const [run] = await db.select()
      .from(botRuns)
      .orderBy(desc(botRuns.startedAt))
      .limit(1);
    return run || null;
  }

  // Opportunity Actions
  async getOpportunityActions(limit: number = 50): Promise<(OpportunityAction & { product?: Product })[]> {
    const actions = await db.select()
      .from(opportunityActions)
      .orderBy(desc(opportunityActions.actionAt))
      .limit(limit);
    
    const result = await Promise.all(actions.map(async (action) => {
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, action.productId))
        .limit(1);
      return { ...action, product: product || undefined };
    }));
    
    return result;
  }

  async getOpportunityActionsByProduct(productId: string): Promise<OpportunityAction[]> {
    return await db.select()
      .from(opportunityActions)
      .where(eq(opportunityActions.productId, productId))
      .orderBy(desc(opportunityActions.actionAt));
  }

  async createOpportunityAction(action: InsertOpportunityAction): Promise<OpportunityAction> {
    const [newAction] = await db.insert(opportunityActions).values(action).returning();
    
    await db.update(products)
      .set({ opportunityStatus: action.action })
      .where(eq(products.id, action.productId));
    
    return newAction;
  }

  async updateProductOpportunityStatus(productId: string, status: string): Promise<Product | null> {
    const [updated] = await db.update(products)
      .set({ opportunityStatus: status })
      .where(eq(products.id, productId))
      .returning();
    return updated || null;
  }

  async getOpportunityStats(): Promise<{ taken: number; missed: number; pending: number }> {
    const result = await db.select({
      status: products.opportunityStatus,
      count: sql<number>`COUNT(*)`,
    })
      .from(products)
      .groupBy(products.opportunityStatus);
    
    const stats = { taken: 0, missed: 0, pending: 0 };
    result.forEach(r => {
      if (r.status === "aprovechada") stats.taken = Number(r.count);
      else if (r.status === "perdida") stats.missed = Number(r.count);
      else stats.pending = Number(r.count);
    });
    
    return stats;
  }

  // Marketplace Connections
  async getMarketplaceConnections(): Promise<MarketplaceConnection[]> {
    return await db.select()
      .from(marketplaceConnections)
      .orderBy(marketplaceConnections.marketplace);
  }

  async getMarketplaceConnection(marketplace: string): Promise<MarketplaceConnection | null> {
    const [connection] = await db.select()
      .from(marketplaceConnections)
      .where(eq(marketplaceConnections.marketplace, marketplace))
      .limit(1);
    return connection || null;
  }

  async upsertMarketplaceConnection(data: InsertMarketplaceConnection): Promise<MarketplaceConnection> {
    const existing = await this.getMarketplaceConnection(data.marketplace);
    if (existing) {
      const [updated] = await db.update(marketplaceConnections)
        .set({
          ...data,
          lastRefreshedAt: new Date(),
        })
        .where(eq(marketplaceConnections.id, existing.id))
        .returning();
      return updated;
    }
    const [newConnection] = await db.insert(marketplaceConnections).values(data).returning();
    return newConnection;
  }

  async disconnectMarketplace(marketplace: string): Promise<void> {
    await db.update(marketplaceConnections)
      .set({
        isConnected: false,
        accessToken: null,
        refreshToken: null,
        expiresAt: null,
      })
      .where(eq(marketplaceConnections.marketplace, marketplace));
  }

  // Published Listings
  async getPublishedListings(limit: number = 50): Promise<(PublishedListing & { product?: Product })[]> {
    const listings = await db.select()
      .from(publishedListings)
      .orderBy(desc(publishedListings.createdAt))
      .limit(limit);
    
    const result = await Promise.all(listings.map(async (listing) => {
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, listing.productId))
        .limit(1);
      return { ...listing, product: product || undefined };
    }));
    
    return result;
  }

  async getPublishedListingsByProduct(productId: string): Promise<PublishedListing[]> {
    return await db.select()
      .from(publishedListings)
      .where(eq(publishedListings.productId, productId))
      .orderBy(desc(publishedListings.createdAt));
  }

  async createPublishedListing(listing: InsertPublishedListing): Promise<PublishedListing> {
    const [newListing] = await db.insert(publishedListings).values(listing).returning();
    return newListing;
  }

  async updatePublishedListing(id: string, data: Partial<PublishedListing>): Promise<PublishedListing | null> {
    const [updated] = await db.update(publishedListings)
      .set(data)
      .where(eq(publishedListings.id, id))
      .returning();
    return updated || null;
  }

  async getProductById(id: string): Promise<Product | null> {
    const [product] = await db.select()
      .from(products)
      .where(eq(products.id, id))
      .limit(1);
    return product || null;
  }
}

export const storage = new DatabaseStorage();
