import nodemailer from "nodemailer";
import { storage } from "./storage";
import { decodeReportData } from "./reports";

// Configure email transporter
// Uses environment variables for SMTP configuration
function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || "587");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    console.log("SMTP no configurado - los emails no se enviarán");
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: {
      user,
      pass,
    },
  });
}

export async function sendReportEmail(
  reportId: string,
  recipientEmail: string
): Promise<boolean> {
  const transporter = createTransporter();
  
  if (!transporter) {
    console.log("Transporter no disponible - email no enviado");
    return false;
  }

  try {
    const report = await storage.getReportById(reportId);
    if (!report || !report.fileData) {
      console.error("Reporte no encontrado:", reportId);
      return false;
    }

    const fileBuffer = decodeReportData(report.fileData);
    const now = new Date();
    const dateStr = now.toLocaleDateString("es-ES", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: recipientEmail,
      subject: `Mi Bot Empresarial - Reporte de Productos ${dateStr}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Reporte de Productos - Mi Bot Empresarial</h2>
          <p>Hola,</p>
          <p>Adjunto encontrarás el reporte más reciente de productos analizados por nuestros bots.</p>
          <ul>
            <li><strong>Productos incluidos:</strong> ${report.productCount || 0}</li>
            <li><strong>Fecha de generación:</strong> ${dateStr}</li>
          </ul>
          <p>El archivo CSV puede abrirse directamente en Excel o Google Sheets.</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
          <p style="color: #666; font-size: 12px;">
            Este es un email automático generado por Mi Bot Empresarial.
          </p>
        </div>
      `,
      attachments: [
        {
          filename: report.fileName,
          content: fileBuffer,
          contentType: "text/csv",
        },
      ],
    });

    // Mark report as sent by email
    await storage.markReportAsSent(reportId);
    
    console.log(`Email enviado exitosamente a ${recipientEmail}`);
    return true;
  } catch (error) {
    console.error("Error enviando email:", error);
    return false;
  }
}

export async function sendTestEmail(recipientEmail: string): Promise<boolean> {
  const transporter = createTransporter();
  
  if (!transporter) {
    return false;
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: recipientEmail,
      subject: "Mi Bot Empresarial - Email de Prueba",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Email de Prueba</h2>
          <p>La configuración de email está funcionando correctamente.</p>
          <p>Recibirás los reportes automáticos en esta dirección.</p>
        </div>
      `,
    });
    return true;
  } catch (error) {
    console.error("Error enviando email de prueba:", error);
    return false;
  }
}
