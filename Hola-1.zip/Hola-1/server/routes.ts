import type { Express } from "express";
import { createServer, type Server } from "http";
import crypto from "crypto";
import { storage } from "./storage";
import { runBot } from "./bots";
import { createAndSaveReport, decodeReportData, generatePDFReport } from "./reports";
import { insertSettingsSchema } from "@shared/schema";
import { getSchedulerStatus, restartScheduler, triggerScheduledRun } from "./scheduler";
import { sendTestEmail, sendReportEmail } from "./email";
import { setupAuth, isAuthenticated } from "./replitAuth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Master password routes
  app.get('/api/auth/master-password-status', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json({
        isEnabled: settings?.isMasterPasswordEnabled || false,
        isSet: !!settings?.masterPasswordHash,
      });
    } catch (error) {
      console.error("Error checking master password status:", error);
      res.status(500).json({ message: "Error al verificar estado de contraseña" });
    }
  });

  app.post('/api/auth/verify-master-password', isAuthenticated, async (req, res) => {
    try {
      const { password } = req.body;
      if (!password) {
        return res.status(400).json({ message: "Contraseña requerida" });
      }

      const settings = await storage.getSettings();
      if (!settings?.masterPasswordHash) {
        return res.status(400).json({ message: "Contraseña maestra no configurada" });
      }

      const hash = crypto.createHash('sha256').update(password).digest('hex');
      if (hash === settings.masterPasswordHash) {
        res.json({ success: true });
      } else {
        res.status(401).json({ message: "Contraseña incorrecta" });
      }
    } catch (error) {
      console.error("Error verifying master password:", error);
      res.status(500).json({ message: "Error al verificar contraseña" });
    }
  });

  app.post('/api/auth/set-master-password', isAuthenticated, async (req, res) => {
    try {
      const { password, currentPassword } = req.body;
      if (!password || password.length < 4) {
        return res.status(400).json({ message: "La contraseña debe tener al menos 4 caracteres" });
      }

      const settings = await storage.getSettings();
      
      // If password is already set, verify current password
      if (settings?.masterPasswordHash && settings.isMasterPasswordEnabled) {
        if (!currentPassword) {
          return res.status(400).json({ message: "Contraseña actual requerida" });
        }
        const currentHash = crypto.createHash('sha256').update(currentPassword).digest('hex');
        if (currentHash !== settings.masterPasswordHash) {
          return res.status(401).json({ message: "Contraseña actual incorrecta" });
        }
      }

      const hash = crypto.createHash('sha256').update(password).digest('hex');
      await storage.updateSettings({
        masterPasswordHash: hash,
        isMasterPasswordEnabled: true,
      });

      res.json({ success: true, message: "Contraseña maestra configurada" });
    } catch (error) {
      console.error("Error setting master password:", error);
      res.status(500).json({ message: "Error al configurar contraseña" });
    }
  });

  app.post('/api/auth/disable-master-password', isAuthenticated, async (req, res) => {
    try {
      const { password } = req.body;
      const settings = await storage.getSettings();
      
      if (settings?.masterPasswordHash) {
        if (!password) {
          return res.status(400).json({ message: "Contraseña requerida para desactivar" });
        }
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        if (hash !== settings.masterPasswordHash) {
          return res.status(401).json({ message: "Contraseña incorrecta" });
        }
      }

      await storage.updateSettings({
        isMasterPasswordEnabled: false,
        masterPasswordHash: null,
      });

      res.json({ success: true, message: "Contraseña maestra desactivada" });
    } catch (error) {
      console.error("Error disabling master password:", error);
      res.status(500).json({ message: "Error al desactivar contraseña" });
    }
  });

  // Dashboard data
  app.get("/api/dashboard", isAuthenticated, async (req, res) => {
    try {
      const [
        totalProducts,
        products,
        botRun1,
        botRun2,
        botRun3,
        botRun4,
      ] = await Promise.all([
        storage.getProductsFoundToday(),
        storage.getProducts(undefined, 50),
        storage.getLatestBotRun(1),
        storage.getLatestBotRun(2),
        storage.getLatestBotRun(3),
        storage.getLatestBotRun(4),
      ]);

      const arbitrageProducts = products.filter(p => p.botType === 2);
      const lowStockProducts = products.filter(p => p.stockLevel === "bajo" || p.stockLevel === "agotado");
      const potentialProfit = arbitrageProducts.reduce((sum, p) => sum + (p.estimatedProfit || 0), 0);

      res.json({
        metrics: {
          totalProducts,
          potentialProfit,
          arbitrageOpportunities: arbitrageProducts.length,
          lowStockProducts: lowStockProducts.length,
        },
        latestProducts: products,
        botRuns: {
          1: botRun1,
          2: botRun2,
          3: botRun3,
          4: botRun4,
        },
      });
    } catch (error) {
      console.error("Error fetching dashboard:", error);
      res.status(500).json({ error: "Error al cargar el dashboard" });
    }
  });

  // Get all products
  app.get("/api/products", isAuthenticated, async (req, res) => {
    try {
      const products = await storage.getProducts(undefined, 500);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Error al cargar productos" });
    }
  });

  // Filter options
  app.get("/api/filters/options", isAuthenticated, async (req, res) => {
    try {
      const [categories, marketplaces] = await Promise.all([
        storage.getUniqueCategories(),
        storage.getUniqueMarketplaces(),
      ]);

      res.json({
        categories,
        marketplaces,
        demandLevels: ["alto", "medio", "bajo"],
        stockLevels: ["alto", "medio", "bajo", "agotado"],
      });
    } catch (error) {
      console.error("Error fetching filter options:", error);
      res.status(500).json({ error: "Error al cargar opciones de filtro" });
    }
  });

  // Filtered products
  app.get("/api/products/filter", isAuthenticated, async (req, res) => {
    try {
      const filters = {
        botType: req.query.botType ? parseInt(req.query.botType as string) : undefined,
        category: req.query.category as string | undefined,
        marketplace: req.query.marketplace as string | undefined,
        demandLevel: req.query.demandLevel as string | undefined,
        stockLevel: req.query.stockLevel as string | undefined,
        minPrice: req.query.minPrice ? parseFloat(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined,
        isWorthPublishing: req.query.isWorthPublishing === "true" ? true : req.query.isWorthPublishing === "false" ? false : undefined,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 100,
      };

      const products = await storage.getFilteredProducts(filters);
      res.json(products);
    } catch (error) {
      console.error("Error fetching filtered products:", error);
      res.status(500).json({ error: "Error al filtrar productos" });
    }
  });

  // Bot 1 products
  app.get("/api/bots/1/products", isAuthenticated, async (req, res) => {
    try {
      const [products, lastRun] = await Promise.all([
        storage.getProductsByBotType(1),
        storage.getLatestBotRun(1),
      ]);

      const ebayProducts = products.filter(p => p.sourceMarketplace === "ebay");
      const mlProducts = products.filter(p => p.sourceMarketplace === "mercadolibre");
      const tiktokProducts = products.filter(p => p.sourceMarketplace === "tiktokshop");
      const highDemand = products.filter(p => p.demandLevel === "alto");
      const worthPublishing = products.filter(p => p.isWorthPublishing);

      res.json({
        products,
        lastRun,
        stats: {
          ebayProducts: ebayProducts.length,
          mercadoLibreProducts: mlProducts.length,
          tiktokProducts: tiktokProducts.length,
          highDemand: highDemand.length,
          worthPublishing: worthPublishing.length,
        },
      });
    } catch (error) {
      console.error("Error fetching bot 1 products:", error);
      res.status(500).json({ error: "Error al cargar productos" });
    }
  });

  // Bot 2 products
  app.get("/api/bots/2/products", isAuthenticated, async (req, res) => {
    try {
      const [products, lastRun] = await Promise.all([
        storage.getProductsByBotType(2),
        storage.getLatestBotRun(2),
      ]);

      const totalPotentialProfit = products.reduce((sum, p) => sum + (p.estimatedProfit || 0), 0);
      const avgProfitPercentage = products.length > 0 
        ? products.reduce((sum, p) => sum + (p.profitPercentage || 0), 0) / products.length 
        : 0;
      const bestMargin = Math.max(...products.map(p => p.profitPercentage || 0), 0);

      res.json({
        products,
        lastRun,
        stats: {
          totalOpportunities: products.length,
          avgProfitPercentage,
          totalPotentialProfit,
          bestMargin,
        },
      });
    } catch (error) {
      console.error("Error fetching bot 2 products:", error);
      res.status(500).json({ error: "Error al cargar productos" });
    }
  });

  // Bot 3 products
  app.get("/api/bots/3/products", isAuthenticated, async (req, res) => {
    try {
      const [products, lastRun] = await Promise.all([
        storage.getProductsByBotType(3),
        storage.getLatestBotRun(3),
      ]);

      const lowStock = products.filter(p => p.stockLevel === "bajo" || p.stockLevel === "agotado");
      const fastSelling = products.filter(p => p.demandLevel === "alto");
      const noCompetition = products.filter(p => (p.competitorCount || 0) <= 3);
      const priceIncrease = products.filter(p => (p.priceChange || 0) > 5);

      res.json({
        products,
        lastRun,
        stats: {
          lowStockProducts: lowStock.length,
          fastSellingProducts: fastSelling.length,
          noCompetitionProducts: noCompetition.length,
          priceIncreaseProducts: priceIncrease.length,
        },
      });
    } catch (error) {
      console.error("Error fetching bot 3 products:", error);
      res.status(500).json({ error: "Error al cargar productos" });
    }
  });

  // Bot 4 reports
  app.get("/api/bots/4/reports", isAuthenticated, async (req, res) => {
    try {
      const [reports, lastRun, allProducts] = await Promise.all([
        storage.getReports(20),
        storage.getLatestBotRun(4),
        storage.getProducts(undefined, 1000),
      ]);

      const emailsSent = reports.filter(r => r.sentByEmail).length;
      const lastReport = reports[0];

      res.json({
        reports,
        lastRun,
        stats: {
          totalReports: reports.length,
          lastReportDate: lastReport?.generatedAt || null,
          emailsSent,
          totalProducts: allProducts.length,
        },
      });
    } catch (error) {
      console.error("Error fetching bot 4 reports:", error);
      res.status(500).json({ error: "Error al cargar reportes" });
    }
  });

  // Promise queue for automatic bot runs to ensure sequential execution
  let automaticBotsQueue: Promise<void> = Promise.resolve();

  // Helper function to run Bot 3 and Bot 4 automatically
  function queueAutomaticBots() {
    automaticBotsQueue = automaticBotsQueue.then(async () => {
      console.log("Ejecutando bots automáticos (Bot 3 y Bot 4)...");
      
      try {
        // Run Bot 3 (escasez)
        const botRun3 = await storage.createBotRun({
          botType: 3,
          status: "ejecutando",
          startedAt: new Date(),
        });
        
        try {
          const result3 = await runBot(3);
          await storage.updateBotRun(botRun3.id, {
            status: "completado",
            completedAt: new Date(),
            productsFound: result3.productsFound,
          });
          console.log(`Bot 3 ejecutado automáticamente: ${result3.productsFound} productos`);
        } catch (error: any) {
          await storage.updateBotRun(botRun3.id, {
            status: "error",
            completedAt: new Date(),
            errorMessage: error.message,
          });
          console.error("Error en Bot 3:", error);
        }

        // Run Bot 4 (reportes)
        const botRun4 = await storage.createBotRun({
          botType: 4,
          status: "ejecutando",
          startedAt: new Date(),
        });
        
        try {
          const result4 = await runBot(4);
          await storage.updateBotRun(botRun4.id, {
            status: "completado",
            completedAt: new Date(),
            productsFound: result4.productsFound,
          });
          console.log(`Bot 4 ejecutado automáticamente: ${result4.productsFound} productos en reporte`);
        } catch (error: any) {
          await storage.updateBotRun(botRun4.id, {
            status: "error",
            completedAt: new Date(),
            errorMessage: error.message,
          });
          console.error("Error en Bot 4:", error);
        }
      } catch (error) {
        console.error("Error crítico en ejecución automática de bots:", error);
      }
    }).catch((error) => {
      console.error("Error en cola de bots automáticos:", error);
    });
  }

  // Run bot
  app.post("/api/bots/:botType/run", isAuthenticated, async (req, res) => {
    try {
      const botType = parseInt(req.params.botType);
      if (botType < 1 || botType > 4) {
        return res.status(400).json({ error: "Bot inválido" });
      }

      // Create bot run record
      const botRun = await storage.createBotRun({
        botType,
        status: "ejecutando",
        startedAt: new Date(),
      });

      // Run bot asynchronously
      runBot(botType)
        .then(async (result) => {
          await storage.updateBotRun(botRun.id, {
            status: "completado",
            completedAt: new Date(),
            productsFound: result.productsFound,
          });
          
          // Auto-run Bot 3 and Bot 4 after Bot 1 or Bot 2 complete
          if (botType === 1 || botType === 2) {
            console.log(`Bot ${botType} completado - ejecutando Bot 3 y Bot 4 automáticamente...`);
            queueAutomaticBots();
          }
        })
        .catch(async (error) => {
          await storage.updateBotRun(botRun.id, {
            status: "error",
            completedAt: new Date(),
            errorMessage: error.message,
          });
        });

      res.json({ 
        success: true, 
        message: `Bot ${botType} iniciado`,
        runId: botRun.id,
      });
    } catch (error) {
      console.error("Error running bot:", error);
      res.status(500).json({ error: "Error al ejecutar el bot" });
    }
  });

  // Refresh products - Clear all and run bots fresh
  app.post("/api/products/refresh", isAuthenticated, async (req, res) => {
    try {
      console.log("Iniciando refresco de productos...");
      
      // Clear all existing products
      await storage.clearAllProducts();
      console.log("Productos anteriores eliminados");
      
      // Run Bot 1 and 2 to get fresh products
      const results = [];
      
      for (const botType of [1, 2, 3]) {
        const botRun = await storage.createBotRun({
          botType,
          status: "ejecutando",
          startedAt: new Date(),
        });
        
        try {
          const result = await runBot(botType);
          await storage.updateBotRun(botRun.id, {
            status: "completado",
            completedAt: new Date(),
            productsFound: result.productsFound,
          });
          results.push({ botType, productsFound: result.productsFound });
          console.log(`Bot ${botType} completado: ${result.productsFound} productos`);
        } catch (error: any) {
          await storage.updateBotRun(botRun.id, {
            status: "error",
            completedAt: new Date(),
            errorMessage: error.message,
          });
          results.push({ botType, error: error.message });
        }
      }
      
      const totalProducts = await storage.getProductCount();
      
      res.json({ 
        success: true, 
        message: "Productos actualizados con éxito",
        totalProducts,
        results,
      });
    } catch (error) {
      console.error("Error refreshing products:", error);
      res.status(500).json({ error: "Error al refrescar productos" });
    }
  });

  // Generate report
  app.post("/api/reports/generate", isAuthenticated, async (req, res) => {
    try {
      // Create bot run for bot 4
      const botRun = await storage.createBotRun({
        botType: 4,
        status: "ejecutando",
        startedAt: new Date(),
      });

      try {
        const report = await createAndSaveReport();
        
        await storage.updateBotRun(botRun.id, {
          status: "completado",
          completedAt: new Date(),
          productsFound: report.productCount,
        });

        res.json({
          success: true,
          report: {
            id: report.id,
            fileName: report.fileName,
            productCount: report.productCount,
          },
        });
      } catch (error: any) {
        await storage.updateBotRun(botRun.id, {
          status: "error",
          completedAt: new Date(),
          errorMessage: error.message,
        });
        throw error;
      }
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ error: "Error al generar el reporte" });
    }
  });

  // Download report (CSV)
  app.get("/api/reports/:id/download", isAuthenticated, async (req, res) => {
    try {
      const report = await storage.getReportById(req.params.id);
      if (!report || !report.fileData) {
        return res.status(404).json({ error: "Reporte no encontrado" });
      }

      const fileBuffer = decodeReportData(report.fileData);
      
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${report.fileName}"`);
      res.send(fileBuffer);
    } catch (error) {
      console.error("Error downloading report:", error);
      res.status(500).json({ error: "Error al descargar el reporte" });
    }
  });

  // Generate and download PDF report
  app.get("/api/reports/download-pdf", isAuthenticated, async (req, res) => {
    try {
      const { fileName, buffer, productCount } = await generatePDFReport();
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
      res.setHeader("Content-Length", buffer.length.toString());
      res.send(buffer);
    } catch (error) {
      console.error("Error generating PDF report:", error);
      res.status(500).json({ error: "Error al generar el reporte PDF" });
    }
  });

  // Get all reports
  app.get("/api/reports", isAuthenticated, async (req, res) => {
    try {
      const reports = await storage.getReports(20);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ error: "Error al cargar reportes" });
    }
  });

  // Regenerate product URLs and add target marketplace suggestions
  app.post("/api/products/regenerate-urls", isAuthenticated, async (req, res) => {
    try {
      const products = await storage.getProducts(undefined, 1000);
      let updatedCount = 0;
      
      // Suggest best marketplace to sell based on source
      const suggestTarget = (source: string): string => {
        const suggestions: Record<string, string> = {
          "ebay": "mercadolibre",
          "mercadolibre": "ebay",
          "amazon": "mercadolibre",
          "walmart": "ebay",
          "aliexpress": "mercadolibre",
          "tiktokshop": "mercadolibre",
        };
        return suggestions[source] || "mercadolibre";
      };
      
      for (const product of products) {
        const cleanName = product.name
          .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
          .replace(/[''""]/g, "")
          .trim();
        
        const encodedName = encodeURIComponent(cleanName);
        
        const urlTemplates: Record<string, string> = {
          "ebay": `https://www.ebay.com/sch/i.html?_nkw=${encodedName}`,
          "mercadolibre": `https://listado.mercadolibre.com.mx/${cleanName.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-]/g, "")}`,
          "amazon": `https://www.amazon.com/s?k=${encodedName}`,
          "walmart": `https://www.walmart.com/search?q=${encodedName}`,
          "aliexpress": `https://www.aliexpress.com/wholesale?SearchText=${encodedName}`,
          "tiktokshop": `https://shop.tiktok.com/search?q=${encodedName}`,
        };
        
        // Generate source URL
        const newSourceUrl = product.sourceMarketplace ? 
          (urlTemplates[product.sourceMarketplace] || product.sourceUrl) : product.sourceUrl;
        
        // Add target marketplace if missing
        let targetMarketplace = product.targetMarketplace;
        if (!targetMarketplace && product.sourceMarketplace) {
          targetMarketplace = suggestTarget(product.sourceMarketplace);
        }
        
        // Generate target URL
        const newTargetUrl = targetMarketplace ? urlTemplates[targetMarketplace] : null;
        
        // Calculate estimated profit if missing (15-30% margin)
        let estimatedProfit = product.estimatedProfit;
        let targetPrice = product.targetPrice;
        let profitPercentage = product.profitPercentage;
        
        if (!estimatedProfit && product.sourcePrice && product.sourcePrice > 0) {
          const marginPercent = 15 + Math.random() * 15;
          estimatedProfit = Math.round(product.sourcePrice * (marginPercent / 100) * 100) / 100;
          targetPrice = Math.round((product.sourcePrice + estimatedProfit) * 100) / 100;
          profitPercentage = marginPercent;
        }
        
        // Update product with new data
        const needsUpdate = 
          newSourceUrl !== product.sourceUrl || 
          newTargetUrl !== product.targetUrl ||
          targetMarketplace !== product.targetMarketplace ||
          estimatedProfit !== product.estimatedProfit;
        
        if (needsUpdate) {
          await storage.updateProductFull(product.id, {
            sourceUrl: newSourceUrl,
            targetUrl: newTargetUrl,
            targetMarketplace: targetMarketplace,
            targetPrice: targetPrice,
            targetCurrency: product.targetCurrency || product.sourceCurrency,
            estimatedProfit: estimatedProfit,
            profitPercentage: profitPercentage,
          });
          updatedCount++;
        }
      }
      
      res.json({ 
        success: true, 
        message: `${updatedCount} productos actualizados con URLs y sugerencias de venta`,
        totalProducts: products.length,
        updatedCount 
      });
    } catch (error) {
      console.error("Error regenerating URLs:", error);
      res.status(500).json({ error: "Error al regenerar URLs" });
    }
  });

  // Generate Bot 3 scarcity products directly (fallback when AI is slow)
  app.post("/api/bots/3/generate-fallback", isAuthenticated, async (req, res) => {
    try {
      // Create scarcity products with stock levels
      const scarcityProducts = [
        { name: "Stanley Quencher H2.0 FlowState 40oz", category: "Deportes", price: 45, stockLevel: "bajo", demandLevel: "alto", priceChange: 15.5, marketplace: "amazon" },
        { name: "Meta Quest 3 128GB VR Headset", category: "Electrónica", price: 499, stockLevel: "agotado", demandLevel: "alto", priceChange: 8.2, marketplace: "ebay" },
        { name: "Dyson Airwrap Complete Styler", category: "Belleza", price: 599, stockLevel: "bajo", demandLevel: "alto", priceChange: 12.0, marketplace: "mercadolibre" },
        { name: "PlayStation 5 Slim Digital Edition", category: "Electrónica", price: 449, stockLevel: "bajo", demandLevel: "alto", priceChange: 5.5, marketplace: "amazon" },
        { name: "LEGO Star Wars Millennium Falcon 75375", category: "Juguetes", price: 169, stockLevel: "medio", demandLevel: "alto", priceChange: 3.2, marketplace: "ebay" },
        { name: "Nike Air Jordan 1 Retro High OG", category: "Moda", price: 180, stockLevel: "agotado", demandLevel: "alto", priceChange: 25.0, marketplace: "mercadolibre" },
        { name: "Apple AirPods Pro 2da Generación", category: "Electrónica", price: 249, stockLevel: "bajo", demandLevel: "alto", priceChange: -5.0, marketplace: "amazon" },
        { name: "Garmin Forerunner 265 GPS Running Watch", category: "Deportes", price: 449, stockLevel: "medio", demandLevel: "medio", priceChange: 2.1, marketplace: "ebay" },
        { name: "KitchenAid Artisan Stand Mixer 5Qt", category: "Hogar", price: 449, stockLevel: "bajo", demandLevel: "medio", priceChange: 7.8, marketplace: "amazon" },
        { name: "Theragun Prime Masajeador Percusión", category: "Deportes", price: 299, stockLevel: "agotado", demandLevel: "alto", priceChange: 18.0, marketplace: "mercadolibre" },
      ];

      const suggestTarget = (source: string): string => {
        const suggestions: Record<string, string> = {
          "ebay": "mercadolibre", "mercadolibre": "ebay", "amazon": "mercadolibre",
        };
        return suggestions[source] || "mercadolibre";
      };

      const generateUrl = (marketplace: string, name: string): string => {
        const cleanName = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[''""]/g, "").trim();
        const encoded = encodeURIComponent(cleanName);
        const urls: Record<string, string> = {
          "ebay": `https://www.ebay.com/sch/i.html?_nkw=${encoded}`,
          "mercadolibre": `https://listado.mercadolibre.com.mx/${cleanName.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-]/g, "")}`,
          "amazon": `https://www.amazon.com/s?k=${encoded}`,
        };
        return urls[marketplace] || `https://www.google.com/search?q=${encoded}`;
      };

      let created = 0;
      for (const p of scarcityProducts) {
        const targetMarketplace = suggestTarget(p.marketplace);
        const marginPercent = 15 + Math.random() * 15;
        const estimatedProfit = Math.round(p.price * (marginPercent / 100) * 100) / 100;
        
        await storage.createProduct({
          name: p.name,
          category: p.category,
          sourceMarketplace: p.marketplace,
          sourceUrl: generateUrl(p.marketplace, p.name),
          sourcePrice: p.price,
          sourceCurrency: "USD",
          targetMarketplace: targetMarketplace,
          targetUrl: generateUrl(targetMarketplace, p.name),
          targetPrice: Math.round((p.price + estimatedProfit) * 100) / 100,
          targetCurrency: "USD",
          estimatedProfit: estimatedProfit,
          profitPercentage: marginPercent,
          stockLevel: p.stockLevel,
          demandLevel: p.demandLevel,
          priceChange: p.priceChange,
          dailySales: Math.floor(Math.random() * 80) + 20,
          competitorCount: Math.floor(Math.random() * 20) + 1,
          botType: 3,
          isWorthPublishing: p.stockLevel === "bajo" || p.stockLevel === "agotado",
        });
        created++;
      }

      // Update bot run status
      const lastRun = await storage.getLatestBotRun(3);
      if (lastRun) {
        await storage.updateBotRun(lastRun.id, {
          status: "completado",
          completedAt: new Date(),
          productsFound: created,
        });
      }

      res.json({ success: true, message: `${created} productos de escasez creados`, productsFound: created });
    } catch (error) {
      console.error("Error generating fallback products:", error);
      res.status(500).json({ error: "Error al generar productos" });
    }
  });

  // Bot history
  app.get("/api/bots/history", isAuthenticated, async (req, res) => {
    try {
      const history = await storage.getBotRuns(50);
      res.json(history);
    } catch (error) {
      console.error("Error fetching history:", error);
      res.status(500).json({ error: "Error al cargar historial" });
    }
  });

  // Analytics
  app.get("/api/analytics/trends", isAuthenticated, async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const [productTrends, profitTrends] = await Promise.all([
        storage.getProductTrendsByDay(days),
        storage.getProfitTrends(days),
      ]);
      res.json({ productTrends, profitTrends });
    } catch (error) {
      console.error("Error fetching trends:", error);
      res.status(500).json({ error: "Error al cargar tendencias" });
    }
  });

  app.get("/api/analytics/distribution", isAuthenticated, async (req, res) => {
    try {
      const [marketplaceDistribution, categoryDistribution] = await Promise.all([
        storage.getMarketplaceDistribution(),
        storage.getCategoryDistribution(),
      ]);
      res.json({ marketplaceDistribution, categoryDistribution });
    } catch (error) {
      console.error("Error fetching distribution:", error);
      res.status(500).json({ error: "Error al cargar distribución" });
    }
  });

  // Settings
  app.get("/api/settings", isAuthenticated, async (req, res) => {
    try {
      let settings = await storage.getSettings();
      if (!settings) {
        settings = await storage.updateSettings({
          email: "",
          scheduleHours: 6,
          isAutoRunEnabled: true,
          minProfitAlert: 20,
          minProfitPercentageAlert: 15,
          alertsEnabled: true,
        });
      }
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Error al cargar configuración" });
    }
  });

  app.put("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const parsed = insertSettingsSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Datos inválidos" });
      }

      const settings = await storage.updateSettings(parsed.data);
      
      // Restart scheduler with new settings
      await restartScheduler();
      
      res.json(settings);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ error: "Error al guardar configuración" });
    }
  });

  // Scheduler status
  app.get("/api/scheduler/status", isAuthenticated, async (req, res) => {
    try {
      const status = getSchedulerStatus();
      res.json(status);
    } catch (error) {
      console.error("Error fetching scheduler status:", error);
      res.status(500).json({ error: "Error al obtener estado del scheduler" });
    }
  });

  // Trigger scheduled run manually
  app.post("/api/scheduler/trigger", isAuthenticated, async (req, res) => {
    try {
      triggerScheduledRun();
      res.json({ success: true, message: "Ejecución programada iniciada" });
    } catch (error) {
      console.error("Error triggering scheduled run:", error);
      res.status(500).json({ error: "Error al iniciar ejecución programada" });
    }
  });

  // Send test email
  app.post("/api/email/test", isAuthenticated, async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email requerido" });
      }

      const success = await sendTestEmail(email);
      if (success) {
        res.json({ success: true, message: "Email de prueba enviado" });
      } else {
        res.json({ 
          success: false, 
          message: "SMTP no configurado. Configure SMTP_HOST, SMTP_USER, SMTP_PASS para habilitar emails." 
        });
      }
    } catch (error) {
      console.error("Error sending test email:", error);
      res.status(500).json({ error: "Error al enviar email de prueba" });
    }
  });

  // Send report by email
  app.post("/api/reports/:id/email", isAuthenticated, async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ error: "Email requerido" });
      }

      const success = await sendReportEmail(req.params.id, email);
      if (success) {
        res.json({ success: true, message: "Reporte enviado por email" });
      } else {
        res.json({ 
          success: false, 
          message: "No se pudo enviar el email. Verifique la configuración SMTP." 
        });
      }
    } catch (error) {
      console.error("Error sending report email:", error);
      res.status(500).json({ error: "Error al enviar reporte por email" });
    }
  });

  // Opportunity Actions
  app.get("/api/opportunities", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const actions = await storage.getOpportunityActions(limit);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching opportunity actions:", error);
      res.status(500).json({ error: "Error al cargar historial de oportunidades" });
    }
  });

  app.get("/api/opportunities/stats", isAuthenticated, async (req, res) => {
    try {
      const stats = await storage.getOpportunityStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching opportunity stats:", error);
      res.status(500).json({ error: "Error al cargar estadísticas de oportunidades" });
    }
  });

  app.get("/api/opportunities/:productId", isAuthenticated, async (req, res) => {
    try {
      const actions = await storage.getOpportunityActionsByProduct(req.params.productId);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching product opportunity actions:", error);
      res.status(500).json({ error: "Error al cargar acciones de oportunidad" });
    }
  });

  app.post("/api/opportunities", isAuthenticated, async (req, res) => {
    try {
      const { productId, action, notes } = req.body;
      if (!productId || !action) {
        return res.status(400).json({ error: "productId y action son requeridos" });
      }
      
      if (!["aprovechada", "perdida", "pendiente"].includes(action)) {
        return res.status(400).json({ error: "Acción inválida" });
      }

      const newAction = await storage.createOpportunityAction({
        productId,
        action,
        notes: notes || null,
      });
      res.json(newAction);
    } catch (error) {
      console.error("Error creating opportunity action:", error);
      res.status(500).json({ error: "Error al registrar acción de oportunidad" });
    }
  });

  // ========== MARKETPLACE CONNECTIONS ==========

  // Get all marketplace connections
  app.get("/api/marketplace/connections", isAuthenticated, async (req, res) => {
    try {
      const connections = await storage.getMarketplaceConnections();
      res.json(connections);
    } catch (error) {
      console.error("Error fetching marketplace connections:", error);
      res.status(500).json({ error: "Error al cargar conexiones de marketplace" });
    }
  });

  // Get specific marketplace connection
  app.get("/api/marketplace/connections/:marketplace", isAuthenticated, async (req, res) => {
    try {
      const connection = await storage.getMarketplaceConnection(req.params.marketplace);
      res.json(connection || { marketplace: req.params.marketplace, isConnected: false });
    } catch (error) {
      console.error("Error fetching marketplace connection:", error);
      res.status(500).json({ error: "Error al cargar conexión de marketplace" });
    }
  });

  // Save marketplace credentials and start OAuth flow
  app.post("/api/marketplace/connections/:marketplace/credentials", isAuthenticated, async (req, res) => {
    try {
      const { marketplace } = req.params;
      const { clientId, clientSecret } = req.body;
      
      if (!clientId || !clientSecret) {
        return res.status(400).json({ error: "Client ID y Client Secret son requeridos" });
      }

      // Generate random state for CSRF protection
      const oauthState = crypto.randomUUID();
      const redirectUri = req.protocol + "://" + req.get("host") + `/api/auth/${marketplace}/callback`;

      // Store credentials and state in database
      await storage.upsertMarketplaceConnection({
        marketplace,
        clientId,
        clientSecret,
        oauthState,
        isConnected: false,
      });

      // Build OAuth authorization URLs
      let authUrl: string;
      if (marketplace === "mercadolibre") {
        authUrl = `https://auth.mercadolibre.com.mx/authorization?response_type=code&client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&state=${oauthState}`;
      } else if (marketplace === "ebay") {
        authUrl = `https://auth.ebay.com/oauth2/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=https://api.ebay.com/oauth/api_scope/sell.inventory&state=${oauthState}`;
      } else {
        return res.status(400).json({ error: "Marketplace no soportado" });
      }

      res.json({
        success: true,
        message: "Credenciales guardadas. Ahora debes autorizar la conexión.",
        authUrl,
      });
    } catch (error) {
      console.error("Error saving credentials:", error);
      res.status(500).json({ error: "Error al guardar credenciales" });
    }
  });

  // Mercado Libre OAuth callback
  app.get("/api/auth/mercadolibre/callback", async (req, res) => {
    try {
      const { code, state, error: authError } = req.query;
      
      if (authError) {
        return res.redirect("/marketplaces?error=mercadolibre&message=" + encodeURIComponent(String(authError)));
      }

      if (!code) {
        return res.redirect("/marketplaces?error=mercadolibre&message=No authorization code received");
      }

      // Get stored connection to retrieve credentials and validate state
      const connection = await storage.getMarketplaceConnection("mercadolibre");
      
      if (!connection || !connection.clientId || !connection.clientSecret) {
        return res.redirect("/marketplaces?error=mercadolibre&message=Missing API credentials. Please configure your app first.");
      }

      // Validate state for CSRF protection
      if (!state || state !== connection.oauthState) {
        return res.redirect("/marketplaces?error=mercadolibre&message=Invalid state parameter. Security validation failed.");
      }

      const redirectUri = req.protocol + "://" + req.get("host") + "/api/auth/mercadolibre/callback";

      const tokenResponse = await fetch("https://api.mercadolibre.com/oauth/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          client_id: connection.clientId,
          client_secret: connection.clientSecret,
          code: String(code),
          redirect_uri: redirectUri,
        }),
      });

      if (!tokenResponse.ok) {
        const errorData = await tokenResponse.text();
        console.error("ML token error:", errorData);
        return res.redirect("/marketplaces?error=mercadolibre&message=Token exchange failed: " + encodeURIComponent(errorData));
      }

      const tokenData = await tokenResponse.json();

      // Get user info
      const userResponse = await fetch("https://api.mercadolibre.com/users/me", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      const userData = await userResponse.json();

      // Save connection with tokens (keep credentials)
      await storage.upsertMarketplaceConnection({
        marketplace: "mercadolibre",
        clientId: connection.clientId,
        clientSecret: connection.clientSecret,
        oauthState: null, // Clear state after successful auth
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        expiresAt: new Date(Date.now() + tokenData.expires_in * 1000),
        userId: String(userData.id),
        userName: userData.nickname || userData.first_name,
        isConnected: true,
        connectedAt: new Date(),
      });

      res.redirect("/marketplaces?connected=mercadolibre");
    } catch (error) {
      console.error("Error in ML callback:", error);
      res.redirect("/marketplaces?error=mercadolibre&message=Connection failed");
    }
  });

  // eBay OAuth callback
  app.get("/api/auth/ebay/callback", async (req, res) => {
    try {
      const { code, state, error: authError } = req.query;
      
      if (authError) {
        return res.redirect("/marketplaces?error=ebay&message=" + encodeURIComponent(String(authError)));
      }

      if (!code) {
        return res.redirect("/marketplaces?error=ebay&message=No authorization code received");
      }

      // Get stored connection to retrieve credentials and validate state
      const connection = await storage.getMarketplaceConnection("ebay");
      
      if (!connection || !connection.clientId || !connection.clientSecret) {
        return res.redirect("/marketplaces?error=ebay&message=Missing API credentials. Please configure your app first.");
      }

      // Validate state for CSRF protection
      if (!state || state !== connection.oauthState) {
        return res.redirect("/marketplaces?error=ebay&message=Invalid state parameter. Security validation failed.");
      }

      const redirectUri = req.protocol + "://" + req.get("host") + "/api/auth/ebay/callback";
      const credentials = Buffer.from(`${connection.clientId}:${connection.clientSecret}`).toString("base64");
      
      const tokenResponse = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Basic ${credentials}`,
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code: String(code),
          redirect_uri: redirectUri,
        }),
      });

      if (!tokenResponse.ok) {
        const errorData = await tokenResponse.text();
        console.error("eBay token error:", errorData);
        return res.redirect("/marketplaces?error=ebay&message=Token exchange failed: " + encodeURIComponent(errorData));
      }

      const tokenData = await tokenResponse.json();

      // Save connection with tokens (keep credentials)
      await storage.upsertMarketplaceConnection({
        marketplace: "ebay",
        clientId: connection.clientId,
        clientSecret: connection.clientSecret,
        oauthState: null, // Clear state after successful auth
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        expiresAt: new Date(Date.now() + tokenData.expires_in * 1000),
        isConnected: true,
        connectedAt: new Date(),
      });

      res.redirect("/marketplaces?connected=ebay");
    } catch (error) {
      console.error("Error in eBay callback:", error);
      res.redirect("/marketplaces?error=ebay&message=Connection failed");
    }
  });

  // Disconnect marketplace
  app.post("/api/marketplace/connections/:marketplace/disconnect", isAuthenticated, async (req, res) => {
    try {
      await storage.disconnectMarketplace(req.params.marketplace);
      res.json({ success: true, message: "Marketplace desconectado" });
    } catch (error) {
      console.error("Error disconnecting marketplace:", error);
      res.status(500).json({ error: "Error al desconectar marketplace" });
    }
  });

  // ========== PRODUCT PUBLISHING ==========

  // Get published listings
  app.get("/api/listings", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const listings = await storage.getPublishedListings(limit);
      res.json(listings);
    } catch (error) {
      console.error("Error fetching listings:", error);
      res.status(500).json({ error: "Error al cargar publicaciones" });
    }
  });

  // Get listings for a product
  app.get("/api/products/:productId/listings", isAuthenticated, async (req, res) => {
    try {
      const listings = await storage.getPublishedListingsByProduct(req.params.productId);
      res.json(listings);
    } catch (error) {
      console.error("Error fetching product listings:", error);
      res.status(500).json({ error: "Error al cargar publicaciones del producto" });
    }
  });

  // Publish product to marketplace
  app.post("/api/products/:productId/publish/:marketplace", isAuthenticated, async (req, res) => {
    try {
      const { productId, marketplace } = req.params;
      const { price, currency } = req.body;

      // Check if marketplace is connected
      const connection = await storage.getMarketplaceConnection(marketplace);
      if (!connection || !connection.isConnected) {
        return res.status(400).json({ 
          error: `No estás conectado a ${marketplace}. Primero conecta tu cuenta.` 
        });
      }

      // Get product details
      const product = await storage.getProductById(productId);
      if (!product) {
        return res.status(404).json({ error: "Producto no encontrado" });
      }

      // Create pending listing
      const listing = await storage.createPublishedListing({
        productId,
        marketplace,
        status: "pendiente",
        price: price || product.targetPrice || product.sourcePrice,
        currency: currency || product.targetCurrency || product.sourceCurrency || "USD",
      });

      // Attempt to publish (simulate for now - real API calls would go here)
      try {
        if (marketplace === "mercadolibre") {
          // Mercado Libre publish logic
          const mlListing = await publishToMercadoLibre(connection, product, listing);
          await storage.updatePublishedListing(listing.id, {
            status: "publicado",
            listingId: mlListing.id,
            listingUrl: mlListing.permalink,
            publishedAt: new Date(),
          });
        } else if (marketplace === "ebay") {
          // eBay publish logic  
          const ebayListing = await publishToEbay(connection, product, listing);
          await storage.updatePublishedListing(listing.id, {
            status: "publicado",
            listingId: ebayListing.offerId,
            listingUrl: ebayListing.listingUrl,
            publishedAt: new Date(),
          });
        }

        const updatedListing = await storage.getPublishedListingsByProduct(productId);
        res.json({ 
          success: true, 
          message: `Producto publicado en ${marketplace}`,
          listing: updatedListing[0],
        });
      } catch (publishError: any) {
        await storage.updatePublishedListing(listing.id, {
          status: "error",
          errorMessage: publishError.message || "Error al publicar",
        });
        throw publishError;
      }
    } catch (error: any) {
      console.error("Error publishing product:", error);
      res.status(500).json({ 
        error: error.message || "Error al publicar producto" 
      });
    }
  });

  // Get products ready to publish (Bot 2 with good profit margin)
  app.get("/api/products/ready-to-publish", isAuthenticated, async (req, res) => {
    try {
      const products = await storage.getFilteredProducts({
        botType: 2,
        isWorthPublishing: true,
        limit: 100,
      });

      // Get connections status
      const connections = await storage.getMarketplaceConnections();
      const connectedMarketplaces = connections
        .filter(c => c.isConnected)
        .map(c => c.marketplace);

      // Get published listings for these products
      const productsWithListings = await Promise.all(
        products.map(async (product) => {
          const listings = await storage.getPublishedListingsByProduct(product.id);
          return {
            ...product,
            listings,
            canPublishTo: connectedMarketplaces.filter(
              m => !listings.some(l => l.marketplace === m && l.status === "publicado")
            ),
          };
        })
      );

      res.json({
        products: productsWithListings,
        connectedMarketplaces,
      });
    } catch (error) {
      console.error("Error fetching ready-to-publish products:", error);
      res.status(500).json({ error: "Error al cargar productos listos para publicar" });
    }
  });

  return httpServer;
}

// Helper functions for publishing
async function publishToMercadoLibre(
  connection: any, 
  product: any, 
  listing: any
): Promise<{ id: string; permalink: string }> {
  // This would make actual API call to Mercado Libre
  // For now, simulate the response structure
  const response = await fetch("https://api.mercadolibre.com/items", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${connection.accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      title: product.name.slice(0, 60), // ML has 60 char limit
      category_id: "MLM1055", // Default category, would need to be predicted
      price: listing.price,
      currency_id: listing.currency === "USD" ? "USD" : "MXN",
      available_quantity: 1,
      buying_mode: "buy_it_now",
      listing_type_id: "gold_special",
      condition: "new",
      description: { plain_text: `${product.name} - Producto importado de ${product.sourceMarketplace}` },
      pictures: product.imageUrl ? [{ source: product.imageUrl }] : [],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error publicando en Mercado Libre");
  }

  return await response.json();
}

async function publishToEbay(
  connection: any,
  product: any,
  listing: any
): Promise<{ offerId: string; listingUrl: string }> {
  // This would make actual API calls to eBay Inventory API
  // For now, simulate the response structure
  const sku = `PROD-${product.id.slice(0, 8)}`;
  
  // Step 1: Create inventory item
  const inventoryResponse = await fetch(
    `https://api.ebay.com/sell/inventory/v1/inventory_item/${sku}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${connection.accessToken}`,
        "Content-Type": "application/json",
        "Content-Language": "en-US",
      },
      body: JSON.stringify({
        availability: { shipToLocationAvailability: { quantity: 1 } },
        condition: "NEW",
        product: {
          title: product.name,
          description: `${product.name} - Imported from ${product.sourceMarketplace}`,
          imageUrls: product.imageUrl ? [product.imageUrl] : [],
        },
      }),
    }
  );

  if (!inventoryResponse.ok) {
    const errorData = await inventoryResponse.json();
    throw new Error(errorData.message || "Error creating eBay inventory");
  }

  // Step 2: Create offer
  const offerResponse = await fetch("https://api.ebay.com/sell/inventory/v1/offer", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${connection.accessToken}`,
      "Content-Type": "application/json",
      "Content-Language": "en-US",
    },
    body: JSON.stringify({
      sku,
      marketplaceId: "EBAY_US",
      format: "FIXED_PRICE",
      availableQuantity: 1,
      pricingSummary: {
        price: { currency: listing.currency || "USD", value: String(listing.price) },
      },
    }),
  });

  if (!offerResponse.ok) {
    const errorData = await offerResponse.json();
    throw new Error(errorData.message || "Error creating eBay offer");
  }

  const offerData = await offerResponse.json();

  // Step 3: Publish offer
  const publishResponse = await fetch(
    `https://api.ebay.com/sell/inventory/v1/offer/${offerData.offerId}/publish`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${connection.accessToken}` },
    }
  );

  if (!publishResponse.ok) {
    const errorData = await publishResponse.json();
    throw new Error(errorData.message || "Error publishing eBay listing");
  }

  const publishData = await publishResponse.json();

  return {
    offerId: offerData.offerId,
    listingUrl: `https://www.ebay.com/itm/${publishData.listingId}`,
  };
}
