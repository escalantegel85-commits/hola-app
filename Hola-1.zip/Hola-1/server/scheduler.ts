import { storage } from "./storage";
import { runBot } from "./bots";
import { createAndSaveReport } from "./reports";
import { sendReportEmail } from "./email";

let schedulerInterval: NodeJS.Timeout | null = null;
let lastRunTime: Date | null = null;
let currentIntervalHours: number = 6;

export function getSchedulerStatus() {
  return {
    isRunning: schedulerInterval !== null,
    lastRunTime,
    currentIntervalHours,
    nextRunTime: lastRunTime && schedulerInterval 
      ? new Date(lastRunTime.getTime() + (currentIntervalHours * 60 * 60 * 1000)) 
      : null,
  };
}

async function runScheduledTasks() {
  console.log("Iniciando ejecución programada de bots...");
  
  try {
    const settings = await storage.getSettings();
    
    if (!settings?.isAutoRunEnabled) {
      console.log("Ejecución automática deshabilitada");
      return;
    }

    // Update lastRunTime only after confirming auto-run is enabled
    lastRunTime = new Date();

    // Run all bots sequentially
    console.log("Ejecutando Bot 1...");
    const run1 = await storage.createBotRun({
      botType: 1,
      status: "ejecutando",
      startedAt: new Date(),
    });
    try {
      const result1 = await runBot(1);
      await storage.updateBotRun(run1.id, {
        status: "completado",
        completedAt: new Date(),
        productsFound: result1.productsFound,
      });
    } catch (error: any) {
      await storage.updateBotRun(run1.id, {
        status: "error",
        completedAt: new Date(),
        errorMessage: error.message,
      });
    }

    console.log("Ejecutando Bot 2...");
    const run2 = await storage.createBotRun({
      botType: 2,
      status: "ejecutando",
      startedAt: new Date(),
    });
    try {
      const result2 = await runBot(2);
      await storage.updateBotRun(run2.id, {
        status: "completado",
        completedAt: new Date(),
        productsFound: result2.productsFound,
      });
    } catch (error: any) {
      await storage.updateBotRun(run2.id, {
        status: "error",
        completedAt: new Date(),
        errorMessage: error.message,
      });
    }

    console.log("Ejecutando Bot 3...");
    const run3 = await storage.createBotRun({
      botType: 3,
      status: "ejecutando",
      startedAt: new Date(),
    });
    try {
      const result3 = await runBot(3);
      await storage.updateBotRun(run3.id, {
        status: "completado",
        completedAt: new Date(),
        productsFound: result3.productsFound,
      });
    } catch (error: any) {
      await storage.updateBotRun(run3.id, {
        status: "error",
        completedAt: new Date(),
        errorMessage: error.message,
      });
    }

    // Generate and send report
    console.log("Generando reporte...");
    const report = await createAndSaveReport();
    
    if (settings.email) {
      console.log(`Enviando reporte a ${settings.email}...`);
      await sendReportEmail(report.id, settings.email);
    }

    console.log("Ejecución programada completada exitosamente");
  } catch (error) {
    console.error("Error en ejecución programada:", error);
  }
}

export async function startScheduler() {
  // Get settings to determine interval
  const settings = await storage.getSettings();
  const hours = settings?.scheduleHours || 6;
  currentIntervalHours = hours;
  const intervalMs = hours * 60 * 60 * 1000;

  // Clear existing interval if any
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
  }

  // Start the scheduler
  schedulerInterval = setInterval(runScheduledTasks, intervalMs);
  
  console.log(`Scheduler iniciado - ejecutando cada ${hours} horas`);
  
  // Run immediately on startup if auto-run is enabled
  if (settings?.isAutoRunEnabled) {
    // Check if there are any products - if not, run immediately regardless of last run
    const products = await storage.getProducts();
    
    if (products.length === 0) {
      console.log("No hay productos, ejecutando bots inmediatamente...");
      runScheduledTasks();
    } else {
      // Only run if it's been more than 30 minutes since last run
      const lastRun = await storage.getLastScheduledRun();
      const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);
      
      if (!lastRun || !lastRun.startedAt || new Date(lastRun.startedAt) < thirtyMinutesAgo) {
        console.log("Ejecutando bots en startup...");
        runScheduledTasks();
      } else {
        console.log("Bots ejecutados recientemente, saltando ejecución de startup");
        // Set lastRunTime from the database record for accurate status reporting
        lastRunTime = lastRun.startedAt ? new Date(lastRun.startedAt) : null;
      }
    }
  }
}

export function stopScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
    console.log("Scheduler detenido");
  }
}

export async function restartScheduler() {
  stopScheduler();
  await startScheduler();
}

// Manual trigger for scheduled run
export async function triggerScheduledRun() {
  await runScheduledTasks();
}
