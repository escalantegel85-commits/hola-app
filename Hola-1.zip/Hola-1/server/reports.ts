import { storage } from "./storage";
import type { Product, InsertReport } from "@shared/schema";
import PDFDocument from "pdfkit";

// Generate Excel-like CSV data (can be opened in Excel)
export async function generateExcelReport(): Promise<{ fileName: string; fileData: string; productCount: number }> {
  const allProducts = await storage.getProducts(undefined, 500);
  
  // CSV Header - Including URLs for buy/sell links
  const headers = [
    "ID",
    "Nombre",
    "Categoría",
    "Marketplace Origen",
    "URL Comprar",
    "Precio Origen",
    "Moneda Origen",
    "Marketplace Destino",
    "URL Vender",
    "Precio Destino",
    "Moneda Destino",
    "Ganancia Estimada",
    "% Ganancia",
    "Ventas Diarias",
    "Competidores",
    "Nivel de Stock",
    "Nivel de Demanda",
    "Cambio de Precio %",
    "Bot",
    "Vale Publicar",
    "Fecha Encontrado"
  ];

  // CSV Rows - Including URLs
  const rows = allProducts.map((product) => [
    product.id,
    `"${(product.name || "").replace(/"/g, '""')}"`,
    product.category || "",
    product.sourceMarketplace,
    product.sourceUrl || "",
    product.sourcePrice?.toString() || "",
    product.sourceCurrency || "",
    product.targetMarketplace || "",
    product.targetUrl || "",
    product.targetPrice?.toString() || "",
    product.targetCurrency || "",
    product.estimatedProfit?.toString() || "",
    product.profitPercentage?.toFixed(2) || "",
    product.dailySales?.toString() || "",
    product.competitorCount?.toString() || "",
    product.stockLevel || "",
    product.demandLevel || "",
    product.priceChange?.toFixed(2) || "",
    `Bot ${product.botType}`,
    product.isWorthPublishing ? "Sí" : "No",
    product.foundAt ? new Date(product.foundAt).toLocaleString("es-ES") : ""
  ]);

  // Build CSV content with UTF-8 BOM for Excel compatibility
  // BOM (Byte Order Mark) helps Excel recognize UTF-8 encoding
  const BOM = "\uFEFF";
  const csvContent = BOM + [
    headers.join(","),
    ...rows.map(row => row.join(","))
  ].join("\r\n"); // Use Windows line endings for Excel compatibility

  // Generate filename with timestamp
  const now = new Date();
  const timestamp = now.toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const fileName = `reporte_productos_${timestamp}.csv`;

  // Encode to base64
  const fileData = Buffer.from(csvContent, "utf-8").toString("base64");

  return {
    fileName,
    fileData,
    productCount: allProducts.length
  };
}

export async function createAndSaveReport(): Promise<{
  id: string;
  fileName: string;
  productCount: number;
}> {
  const { fileName, fileData, productCount } = await generateExcelReport();
  
  const report = await storage.createReport({
    fileName,
    fileData,
    productCount,
    sentByEmail: false,
  });

  return {
    id: report.id,
    fileName: report.fileName,
    productCount: report.productCount || 0,
  };
}

export function decodeReportData(base64Data: string): Buffer {
  return Buffer.from(base64Data, "base64");
}

// Generate PDF report with product data
export async function generatePDFReport(): Promise<{ fileName: string; buffer: Buffer; productCount: number }> {
  const allProducts = await storage.getProducts(undefined, 500);
  
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 40 });
      const chunks: Buffer[] = [];
      
      doc.on("data", (chunk: Buffer) => chunks.push(chunk));
      doc.on("end", () => {
        const buffer = Buffer.concat(chunks);
        const now = new Date();
        const timestamp = now.toISOString().replace(/[:.]/g, "-").slice(0, 19);
        const fileName = `reporte_productos_${timestamp}.pdf`;
        resolve({ fileName, buffer, productCount: allProducts.length });
      });
      doc.on("error", reject);
      
      // Header
      doc.fontSize(20).font("Helvetica-Bold").text("Reporte de Productos", { align: "center" });
      doc.moveDown(0.5);
      doc.fontSize(10).font("Helvetica").fillColor("#666666")
        .text(`Generado: ${new Date().toLocaleString("es-ES")}`, { align: "center" });
      doc.text(`Total de productos: ${allProducts.length}`, { align: "center" });
      doc.moveDown(1);
      
      // Summary stats
      const bot1Products = allProducts.filter(p => p.botType === 1);
      const bot2Products = allProducts.filter(p => p.botType === 2);
      const bot3Products = allProducts.filter(p => p.botType === 3);
      const totalProfit = allProducts.reduce((sum, p) => sum + (p.estimatedProfit || 0), 0);
      
      doc.fillColor("#000000").fontSize(12).font("Helvetica-Bold").text("Resumen por Bot:");
      doc.moveDown(0.3);
      doc.fontSize(10).font("Helvetica");
      doc.text(`Bot 1 (Top Ventas eBay/ML): ${bot1Products.length} productos`);
      doc.text(`Bot 2 (Arbitraje): ${bot2Products.length} productos`);
      doc.text(`Bot 3 (Bajo Stock): ${bot3Products.length} productos`);
      doc.text(`Ganancia Potencial Total: $${totalProfit.toFixed(2)} USD`);
      doc.moveDown(1);
      
      // Products table
      doc.fontSize(12).font("Helvetica-Bold").text("Detalle de Productos:");
      doc.moveDown(0.5);
      
      // Table header
      const tableTop = doc.y;
      const tableLeft = 40;
      const colWidths = [140, 80, 70, 80, 70, 75];
      const headers = ["Nombre", "Origen", "Precio", "Destino", "Ganancia", "Bot"];
      
      // Draw header background
      doc.rect(tableLeft, tableTop, 515, 18).fill("#333333");
      // Reset to white text for header
      doc.fontSize(8).font("Helvetica-Bold").fillColor("#ffffff");
      
      let xPos = tableLeft + 5;
      headers.forEach((header, i) => {
        doc.text(header, xPos, tableTop + 5, { width: colWidths[i] - 10, align: "left" });
        xPos += colWidths[i];
      });
      
      // Table rows
      let yPos = tableTop + 18;
      const rowHeight = 22;
      const margin = 40;
      const footerHeight = 60;
      const usableHeight = doc.page.height - margin - footerHeight;
      
      doc.font("Helvetica").fillColor("#000000");
      
      allProducts.forEach((product, index) => {
        // Check if we need a new page (leave room for footer on last page)
        if (yPos + rowHeight > usableHeight) {
          doc.addPage();
          yPos = margin;
          // Redraw header on new page - draw background first, then set white text
          doc.rect(tableLeft, yPos, 515, 18).fill("#333333");
          doc.fontSize(8).font("Helvetica-Bold").fillColor("#ffffff");
          xPos = tableLeft + 5;
          headers.forEach((header, i) => {
            doc.text(header, xPos, yPos + 5, { width: colWidths[i] - 10, align: "left" });
            xPos += colWidths[i];
          });
          yPos += 18;
        }
        
        // Alternate row colors (fill background first, then reset color for text)
        if (index % 2 === 0) {
          doc.save();
          doc.rect(tableLeft, yPos, 515, rowHeight).fill("#f5f5f5");
          doc.restore();
        }
        
        // Reset to black text color after background fill
        doc.font("Helvetica").fillColor("#000000").fontSize(7);
        
        const name = (product.name || "Sin nombre").slice(0, 28);
        const sourcePrice = `${product.sourceCurrency || "USD"} ${product.sourcePrice || 0}`;
        const target = product.targetMarketplace || "-";
        const profit = product.estimatedProfit ? `$${product.estimatedProfit.toFixed(0)} (${product.profitPercentage?.toFixed(0)}%)` : "-";
        const bot = `Bot ${product.botType}`;
        
        const rowData = [name, product.sourceMarketplace || "-", sourcePrice, target, profit, bot];
        xPos = tableLeft + 5;
        rowData.forEach((data, i) => {
          doc.text(data, xPos, yPos + 5, { width: colWidths[i] - 10, align: "left" });
          xPos += colWidths[i];
        });
        
        yPos += rowHeight;
      });
      
      // Add new page if footer would overlap with content
      if (yPos + 40 > doc.page.height - margin) {
        doc.addPage();
      }
      
      // Footer at the bottom of the current page (fixed position)
      const footerY = doc.page.height - margin - 30;
      doc.fontSize(9).font("Helvetica").fillColor("#666666");
      doc.text("Mi Bot Empresarial - Cazador de Productos Ganadores", margin, footerY, { 
        align: "center", 
        width: doc.page.width - margin * 2 
      });
      doc.text("Este reporte fue generado automaticamente", margin, footerY + 12, { 
        align: "center", 
        width: doc.page.width - margin * 2 
      });
      
      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}
