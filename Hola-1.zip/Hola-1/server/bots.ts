import OpenAI from "openai";
import { storage } from "./storage";
import type { InsertProduct } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

// Simulated product data generation with AI analysis
async function generateProductsWithAI(
  botType: number,
  marketplaces: string[],
  count: number = 10
): Promise<InsertProduct[]> {
  try {
    const prompt = getBotPrompt(botType, marketplaces, count);
    
    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "Eres un experto en análisis de productos de e-commerce. Genera datos realistas de productos para análisis de mercado. Responde siempre en formato JSON válido."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 4096,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      return generateFallbackProducts(botType, marketplaces, count);
    }

    const parsed = JSON.parse(content);
    const productsData = parsed.products || parsed.productos || [];
    
    return productsData.map((p: any) => mapToInsertProduct(p, botType));
  } catch (error) {
    console.error("Error generating products with AI:", error);
    return generateFallbackProducts(botType, marketplaces, count);
  }
}

function getBotPrompt(botType: number, marketplaces: string[], count: number): string {
  // Add current date for freshness and randomness
  const now = new Date();
  const dateStr = now.toLocaleDateString('es-MX', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const randomSeed = Math.floor(Math.random() * 10000);
  
  // Rotating categories for variety
  const trendingCategories = [
    "tecnología viral", "moda streetwear", "skincare coreano", "gaming accessories",
    "fitness equipment", "smart home", "pet accessories", "cocina gourmet",
    "organización hogar", "bebés y niños", "deportes extremos", "música y audio",
    "fotografía móvil", "jardinería urbana", "manualidades DIY", "snacks importados"
  ];
  const randomCategories = trendingCategories.sort(() => Math.random() - 0.5).slice(0, 5).join(", ");

  switch (botType) {
    case 1:
      return `FECHA: ${dateStr} | SEED: ${randomSeed}
      
      Genera ${count} productos TRENDING que se están vendiendo MÁS DE 1000 UNIDADES por mes en ${marketplaces.join(", ")}.
      
      REQUISITOS CRÍTICOS:
      - Solo productos VIRALES y BESTSELLERS actuales (${dateStr})
      - Ventas mínimas: 1000+ unidades mensuales (indica el número exacto estimado)
      - Productos DIFERENTES a los típicos (no repitas iPhone, AirPods, etc.)
      - Enfócate en: ${randomCategories}
      - Precios variados: 30% económicos ($5-$25), 40% medios ($25-$80), 30% premium ($80-$200)
      
      PRODUCTOS TRENDING ACTUALES (ejemplos ${now.getMonth() + 1}/${now.getFullYear()}):
      - Mini proyector portátil LED ($35) - 5000+ ventas/mes
      - Lámpara sunset/atardecer TikTok ($18) - 8000+ ventas/mes
      - Botella agua con marcador tiempo ($12) - 12000+ ventas/mes
      - Masajeador facial jade roller ($15) - 6000+ ventas/mes
      - Organizador cables silicona ($8) - 15000+ ventas/mes
      - Espejo LED maquillaje plegable ($25) - 4000+ ventas/mes
      - Taza térmica inteligente ($45) - 3500+ ventas/mes
      - Almohada ergonómica memory foam ($35) - 7000+ ventas/mes
      
      Formato JSON: { "products": [{ "name": string, "category": string, "price": number, "currency": "USD", 
      "dailySales": number (>33 para superar 1000/mes), "competitors": number, "demandLevel": "alto", 
      "worthPublishing": boolean, "marketplace": string }] }`;
    
    case 2:
      return `FECHA: ${dateStr} | SEED: ${randomSeed}
      
      Genera ${count} oportunidades de ARBITRAJE REAL con productos vendiendo MÁS DE 1000 UNIDADES/mes.
      
      REQUISITOS:
      - Productos con alta rotación (1000+ ventas mensuales)
      - Diferencia de precio REAL entre marketplaces
      - Ganancia mínima: $5 USD o 25%
      - Productos DIFERENTES cada vez (usa seed: ${randomSeed})
      - Enfócate en: ${randomCategories}
      
      EJEMPLOS DE ARBITRAJE REAL (${now.getMonth() + 1}/${now.getFullYear()}):
      - Luz LED tira 5m en AliExpress $8 → Mercado Libre $28 (ganancia $20, 250%)
      - Soporte celular auto magnético AliExpress $4 → Amazon $18 (ganancia $14, 350%)
      - Funda laptop neopreno AliExpress $6 → eBay $22 (ganancia $16, 266%)
      - Auriculares TWS genéricos AliExpress $12 → Mercado Libre $45 (ganancia $33, 275%)
      - Ring light 10" con trípode AliExpress $15 → Amazon $55 (ganancia $40, 266%)
      
      Formato JSON: { "products": [{ "name": string, "category": string, "sourcePrice": number, 
      "sourceCurrency": "USD", "targetPrice": number, "targetCurrency": "USD", "profit": number, 
      "profitPercentage": number, "sourceMarketplace": string, "targetMarketplace": string,
      "monthlySales": number }] }`;
    
    case 3:
      return `FECHA: ${dateStr} | SEED: ${randomSeed}
      
      Genera ${count} productos con ESCASEZ y ALTA DEMANDA (1000+ ventas/mes).
      
      REQUISITOS:
      - Productos que se AGOTAN rápidamente
      - Demanda alta, stock limitado
      - Oportunidad de reventa con margen
      - Productos TRENDING diferentes (seed: ${randomSeed})
      - Enfócate en: ${randomCategories}
      
      EJEMPLOS DE ESCASEZ ACTUAL (${now.getMonth() + 1}/${now.getFullYear()}):
      - Consolas retro portátiles ($45) - stock bajo, 3000+ ventas/mes
      - Figuras coleccionables anime ($25) - agotándose, 2500+ ventas/mes
      - Tenis edición limitada ($120) - escasos, 1500+ ventas/mes
      - Sets LEGO descontinuados ($80) - últimas unidades
      - Perfumes nicho ($65) - difícil conseguir
      
      Formato JSON: { "products": [{ "name": string, "category": string, "price": number, "currency": "USD",
      "stockLevel": string, "demandLevel": "alto", "competitors": number, "priceChange": number,
      "marketplace": string, "monthlySales": number }] }`;
    
    default:
      return `Genera ${count} productos trending para análisis de mercado.`;
  }
}

function normalizeMarketplace(marketplace: string | undefined): string {
  if (!marketplace) return "ebay";
  const lower = marketplace.toLowerCase().replace(/\s+/g, "").replace(/-/g, "");
  const mappings: Record<string, string> = {
    "ebay": "ebay",
    "mercadolibre": "mercadolibre",
    "mercado libre": "mercadolibre",
    "amazon": "amazon",
    "walmart": "walmart",
    "aliexpress": "aliexpress",
    "ali express": "aliexpress",
    "tiktokshop": "tiktokshop",
    "tiktok shop": "tiktokshop",
    "tiktok": "tiktokshop",
  };
  return mappings[lower] || lower;
}

// Suggest best marketplace to sell based on source marketplace
function suggestTargetMarketplace(sourceMarketplace: string): string {
  const suggestions: Record<string, string> = {
    // If found on eBay, suggest selling on Mercado Libre (good margin in LATAM)
    "ebay": "mercadolibre",
    // If found on Mercado Libre, suggest selling on eBay (access to US market)
    "mercadolibre": "ebay",
    // If found on Amazon, suggest Mercado Libre (better margin without Prime competition)
    "amazon": "mercadolibre",
    // If found on Walmart, suggest eBay (good for reselling)
    "walmart": "ebay",
    // If found on AliExpress, suggest both eBay and Mercado Libre
    "aliexpress": "mercadolibre",
    // If found on TikTok Shop, suggest Mercado Libre (LATAM market potential)
    "tiktokshop": "mercadolibre",
  };
  return suggestions[sourceMarketplace] || "mercadolibre";
}

function generateMarketplaceUrl(marketplace: string, productName: string): string {
  // Clean the product name for URL encoding - remove special characters but keep spaces
  const cleanName = productName
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // Remove accents
    .replace(/[''""«»]/g, "") // Remove quotes
    .replace(/[^\w\s-]/g, " ") // Replace special chars with space
    .replace(/\s+/g, " ") // Normalize spaces
    .trim();
  
  // Different encoding for different marketplaces
  const spaceToPlus = cleanName.replace(/\s+/g, "+");
  const spaceToPercent20 = encodeURIComponent(cleanName);
  const spaceToDash = cleanName.replace(/\s+/g, "-").toLowerCase();
  
  // URLs that actually work and show search results
  const urlTemplates: Record<string, string> = {
    // eBay search - works worldwide
    "ebay": `https://www.ebay.com/sch/i.html?_nkw=${spaceToPlus}&_sacat=0`,
    
    // Mercado Libre Mexico search - proper format
    "mercadolibre": `https://listado.mercadolibre.com.mx/${spaceToDash}`,
    
    // Amazon US search
    "amazon": `https://www.amazon.com/s?k=${spaceToPlus}`,
    
    // Amazon Mexico search (better for LATAM users)
    "amazonmx": `https://www.amazon.com.mx/s?k=${spaceToPlus}`,
    
    // Walmart search
    "walmart": `https://www.walmart.com/search?q=${spaceToPlus}`,
    
    // AliExpress search - proper format
    "aliexpress": `https://www.aliexpress.com/w/wholesale-${spaceToDash}.html`,
    
    // TikTok Shop - redirects to search
    "tiktokshop": `https://www.tiktok.com/search?q=${spaceToPercent20}+shop`,
  };
  
  return urlTemplates[marketplace] || `https://www.google.com/search?q=${spaceToPlus}+comprar`;
}

function mapToInsertProduct(p: any, botType: number): InsertProduct {
  const rawMarketplace = p.sourceMarketplace || p.marketplace || "ebay";
  const normalizedSourceMarketplace = normalizeMarketplace(rawMarketplace);
  const productName = p.name || p.nombre || "Producto sin nombre";
  
  // For Bot 2 (arbitrage), use provided target; for others, suggest based on source
  let normalizedTargetMarketplace: string | null = null;
  if (p.targetMarketplace) {
    normalizedTargetMarketplace = normalizeMarketplace(p.targetMarketplace);
  } else {
    // All bots now suggest where to sell
    normalizedTargetMarketplace = suggestTargetMarketplace(normalizedSourceMarketplace);
  }
  
  // Calculate estimated profit for non-arbitrage products (10-25% margin suggestion)
  const sourcePrice = p.sourcePrice || p.price || p.precio || 0;
  let estimatedProfit = p.profit || p.estimatedProfit || null;
  let targetPrice = p.targetPrice || null;
  let profitPercentage = p.profitPercentage || null;
  
  // For Bot 1 and Bot 3, estimate potential profit if not provided
  if ((botType === 1 || botType === 3) && sourcePrice > 0 && !estimatedProfit) {
    const marginPercent = 15 + Math.random() * 15; // 15-30% margin
    estimatedProfit = Math.round(sourcePrice * (marginPercent / 100) * 100) / 100;
    targetPrice = Math.round((sourcePrice + estimatedProfit) * 100) / 100;
    profitPercentage = marginPercent;
  }
  
  const baseProduct: InsertProduct = {
    name: productName,
    imageUrl: p.imageUrl || null,
    sourceMarketplace: normalizedSourceMarketplace,
    sourceUrl: p.sourceUrl || generateMarketplaceUrl(normalizedSourceMarketplace, productName),
    sourcePrice: sourcePrice,
    sourceCurrency: p.sourceCurrency || p.currency || "USD",
    targetMarketplace: normalizedTargetMarketplace,
    targetUrl: normalizedTargetMarketplace ? generateMarketplaceUrl(normalizedTargetMarketplace, productName) : null,
    targetPrice: targetPrice,
    targetCurrency: p.targetCurrency || p.sourceCurrency || p.currency || "USD",
    estimatedProfit: estimatedProfit,
    profitPercentage: profitPercentage,
    dailySales: p.dailySales || p.ventasDiarias || null,
    competitorCount: p.competitors || p.competidores || null,
    stockLevel: p.stockLevel || null,
    demandLevel: p.demandLevel || null,
    priceChange: p.priceChange || null,
    botType: botType,
    category: p.category || p.categoria || null,
    isWorthPublishing: p.worthPublishing || false,
  };

  return baseProduct;
}

const REAL_PRODUCTS: Record<string, { name: string; price: number; currency: string; monthlySales: number }[]> = {
  "Trending Viral": [
    { name: "Mini Proyector Portátil LED 1080p", price: 45, currency: "USD", monthlySales: 8500 },
    { name: "Lámpara Sunset Atardecer TikTok RGB", price: 18, currency: "USD", monthlySales: 12000 },
    { name: "Botella Agua con Marcador Tiempo 1L", price: 15, currency: "USD", monthlySales: 15000 },
    { name: "Ring Light 10\" con Trípode Ajustable", price: 28, currency: "USD", monthlySales: 9500 },
    { name: "Organizador Cables Silicona Pack 10", price: 8, currency: "USD", monthlySales: 22000 },
    { name: "Masajeador Facial Jade Roller Gua Sha", price: 12, currency: "USD", monthlySales: 11000 },
    { name: "Espejo LED Maquillaje Plegable 3x", price: 22, currency: "USD", monthlySales: 7800 },
    { name: "Luz LED Tira RGB 5m con Control", price: 15, currency: "USD", monthlySales: 18000 },
    { name: "Soporte Celular Auto Magnético MagSafe", price: 18, currency: "USD", monthlySales: 9200 },
    { name: "Auriculares TWS Bluetooth 5.3", price: 22, currency: "USD", monthlySales: 25000 },
    { name: "Plancha Cabello Mini Portátil USB", price: 25, currency: "USD", monthlySales: 6500 },
    { name: "Humidificador Mini USB Escritorio", price: 18, currency: "USD", monthlySales: 8800 },
    { name: "Lámpara Luna 3D Levitante Magnética", price: 35, currency: "USD", monthlySales: 4500 },
    { name: "Taza Térmica Inteligente Display LCD", price: 28, currency: "USD", monthlySales: 5200 },
    { name: "Ventilador Cuello Portátil USB", price: 15, currency: "USD", monthlySales: 14000 },
  ],
  "Electrónica": [
    { name: "Cable USB-C a Lightning 1m Apple", price: 19, currency: "USD", monthlySales: 45000 },
    { name: "Cargador USB 20W Carga Rápida", price: 12, currency: "USD", monthlySales: 38000 },
    { name: "Memoria USB SanDisk Ultra 64GB", price: 8, currency: "USD", monthlySales: 52000 },
    { name: "Protector Pantalla Vidrio Templado Universal", price: 7, currency: "USD", monthlySales: 85000 },
    { name: "Audífonos Inalámbricos In-Ear", price: 15, currency: "USD", monthlySales: 32000 },
    { name: "Mouse Inalámbrico 2.4GHz Silencioso", price: 12, currency: "USD", monthlySales: 28000 },
    { name: "Funda Silicona Transparente Universal", price: 8, currency: "USD", monthlySales: 65000 },
    { name: "Cable HDMI 4K 2m Alta Velocidad", price: 10, currency: "USD", monthlySales: 22000 },
    { name: "Hub USB-C 7 en 1 Multiport", price: 25, currency: "USD", monthlySales: 15000 },
    { name: "Power Bank 10000mAh Carga Rápida", price: 22, currency: "USD", monthlySales: 18500 },
    { name: "Teclado Mecánico RGB Gaming 60%", price: 45, currency: "USD", monthlySales: 8200 },
    { name: "Webcam 1080p con Micrófono", price: 28, currency: "USD", monthlySales: 12000 },
    { name: "Soporte Laptop Aluminio Ajustable", price: 25, currency: "USD", monthlySales: 9800 },
    { name: "Mousepad XXL Gaming RGB", price: 18, currency: "USD", monthlySales: 14500 },
    { name: "Cargador Inalámbrico Qi 15W", price: 18, currency: "USD", monthlySales: 21000 },
  ],
  "Hogar": [
    { name: "Organizador Cajones Acrílico 4 Pack", price: 15, currency: "USD", monthlySales: 18000 },
    { name: "Lámpara LED Escritorio Touch Dimmer", price: 22, currency: "USD", monthlySales: 12500 },
    { name: "Set Contenedores Vidrio Hermético 10pcs", price: 25, currency: "USD", monthlySales: 9800 },
    { name: "Alfombra Antideslizante Baño Memory Foam", price: 18, currency: "USD", monthlySales: 14200 },
    { name: "Timer Digital Cocina Magnético LCD", price: 8, currency: "USD", monthlySales: 22000 },
    { name: "Báscula Digital Cocina Precisión 5kg", price: 15, currency: "USD", monthlySales: 16800 },
    { name: "Termo Stanley IceFlow 30oz", price: 35, currency: "USD", monthlySales: 8500 },
    { name: "Set Utensilios Cocina Silicona 12pcs", price: 22, currency: "USD", monthlySales: 11200 },
    { name: "Organizador Maquillaje Acrílico Rotatorio", price: 28, currency: "USD", monthlySales: 7800 },
    { name: "Dispensador Jabón Automático Sin Contacto", price: 22, currency: "USD", monthlySales: 9500 },
    { name: "Cubiertos Bambú Reutilizables Set", price: 12, currency: "USD", monthlySales: 15500 },
    { name: "Funda Almohada Seda Natural 2 Pack", price: 28, currency: "USD", monthlySales: 6800 },
  ],
  "Moda Trending": [
    { name: "Bucket Hat Unisex Algodón", price: 12, currency: "USD", monthlySales: 28000 },
    { name: "Calcetines Divertidos Pack 6", price: 15, currency: "USD", monthlySales: 35000 },
    { name: "Cinturón Tela Sin Hebilla", price: 12, currency: "USD", monthlySales: 22000 },
    { name: "Hoodie Oversized Unisex", price: 35, currency: "USD", monthlySales: 18500 },
    { name: "Crocs Classic Clog Unisex", price: 45, currency: "USD", monthlySales: 42000 },
    { name: "Gafas Sol Retro Vintage", price: 15, currency: "USD", monthlySales: 25000 },
    { name: "Bolso Crossbody Mini Nylon", price: 18, currency: "USD", monthlySales: 19500 },
    { name: "Scrunchie Seda Set 6", price: 12, currency: "USD", monthlySales: 32000 },
    { name: "Claw Clip Cabello Grande Pack 4", price: 10, currency: "USD", monthlySales: 45000 },
    { name: "Tote Bag Canvas Reutilizable", price: 15, currency: "USD", monthlySales: 28500 },
    { name: "Pulsera Cuenta Personalizable", price: 12, currency: "USD", monthlySales: 38000 },
    { name: "Bandana Paisley Multicolor", price: 8, currency: "USD", monthlySales: 24000 },
  ],
  "Fitness": [
    { name: "Banda Resistencia Set 5 Niveles", price: 15, currency: "USD", monthlySales: 32000 },
    { name: "Cuerda Saltar Speed Rope Pro", price: 12, currency: "USD", monthlySales: 18500 },
    { name: "Guantes Gimnasio Silicona Grip", price: 18, currency: "USD", monthlySales: 14200 },
    { name: "Botella Shaker Proteína 700ml", price: 12, currency: "USD", monthlySales: 22000 },
    { name: "Rodillera Compresión Deportiva Par", price: 18, currency: "USD", monthlySales: 16800 },
    { name: "Mat Yoga TPE Antideslizante 6mm", price: 28, currency: "USD", monthlySales: 25000 },
    { name: "Stanley Quencher H2.0 40oz", price: 45, currency: "USD", monthlySales: 85000 },
    { name: "Foam Roller Masaje Muscular", price: 22, currency: "USD", monthlySales: 12500 },
    { name: "Muñequera Sudor Nike Par", price: 12, currency: "USD", monthlySales: 28000 },
    { name: "Faja Lumbar Entrenamiento", price: 22, currency: "USD", monthlySales: 9800 },
    { name: "Pelota Lacrosse Masaje Set 2", price: 10, currency: "USD", monthlySales: 15500 },
    { name: "Cinta Kinesiológica 5cm x 5m", price: 12, currency: "USD", monthlySales: 18200 },
  ],
  "Coleccionables": [
    { name: "Pokemon Cards Booster Pack", price: 5, currency: "USD", monthlySales: 125000 },
    { name: "Funko Pop! Figura Anime", price: 15, currency: "USD", monthlySales: 45000 },
    { name: "Squishmallows 8 Pulgadas", price: 15, currency: "USD", monthlySales: 68000 },
    { name: "Crocs Jibbitz Charms Pack 10", price: 15, currency: "USD", monthlySales: 52000 },
    { name: "Trading Cards One Piece Booster", price: 8, currency: "USD", monthlySales: 38000 },
    { name: "Mini Brands Surprise Ball", price: 10, currency: "USD", monthlySales: 42000 },
    { name: "Figura Anime Acrylic Stand", price: 12, currency: "USD", monthlySales: 28500 },
    { name: "Llavero Plush Sanrio", price: 10, currency: "USD", monthlySales: 35000 },
    { name: "Sticker Pack Aesthetic 50pcs", price: 8, currency: "USD", monthlySales: 55000 },
    { name: "Washi Tape Set 10 Rollos", price: 12, currency: "USD", monthlySales: 22000 },
    { name: "Pin Enamel Kawaii Set 5", price: 12, currency: "USD", monthlySales: 18500 },
    { name: "Poster Anime A3 Laminado", price: 8, currency: "USD", monthlySales: 32000 },
  ],
  "Skincare K-Beauty": [
    { name: "Esencia Snail Mucin COSRX", price: 22, currency: "USD", monthlySales: 85000 },
    { name: "Protector Solar Beauty of Joseon", price: 18, currency: "USD", monthlySales: 62000 },
    { name: "Cleansing Balm Heimish", price: 18, currency: "USD", monthlySales: 45000 },
    { name: "Toner Calmante Some By Mi", price: 15, currency: "USD", monthlySales: 38000 },
    { name: "Mascarilla Facial Sheet Pack 10", price: 12, currency: "USD", monthlySales: 52000 },
    { name: "Sérum Vitamina C Klairs", price: 22, currency: "USD", monthlySales: 42000 },
    { name: "Crema Hidratante COSRX Birch", price: 25, currency: "USD", monthlySales: 35000 },
    { name: "Lip Sleeping Mask Laneige", price: 22, currency: "USD", monthlySales: 48000 },
    { name: "Parches Acné Mighty Patch", price: 15, currency: "USD", monthlySales: 72000 },
    { name: "Gel Aloe Vera 300ml Nature Republic", price: 12, currency: "USD", monthlySales: 55000 },
    { name: "Exfoliante BHA Paula's Choice", price: 32, currency: "USD", monthlySales: 28000 },
    { name: "Serum Niacinamide The Ordinary", price: 12, currency: "USD", monthlySales: 95000 },
  ],
};

function generateFallbackProducts(botType: number, marketplaces: string[], count: number): InsertProduct[] {
  const products: InsertProduct[] = [];
  const categories = Object.keys(REAL_PRODUCTS);
  const usedProducts = new Set<string>();
  
  // Shuffle categories to get different products each time
  const shuffledCategories = [...categories].sort(() => Math.random() - 0.5);
  
  for (let i = 0; i < count; i++) {
    const marketplace = marketplaces[Math.floor(Math.random() * marketplaces.length)];
    // Use shuffled categories for more variety
    const category = shuffledCategories[i % shuffledCategories.length];
    const categoryProducts = REAL_PRODUCTS[category];
    
    // Shuffle products within category for variety
    const shuffledProducts = [...categoryProducts].sort(() => Math.random() - 0.5);
    
    let productData = shuffledProducts[0];
    let attempts = 0;
    let productIndex = 0;
    while (usedProducts.has(productData.name) && attempts < shuffledProducts.length) {
      productIndex++;
      productData = shuffledProducts[productIndex % shuffledProducts.length];
      attempts++;
    }
    usedProducts.add(productData.name);
    
    // Small price variation to simulate real market conditions
    const priceVariation = 0.95 + Math.random() * 0.1;
    const adjustedPrice = Math.round(productData.price * priceVariation * 100) / 100;
    
    // Calculate daily sales from monthly (all products have 1000+ monthly)
    const monthlySales = productData.monthlySales || 5000;
    const dailySalesBase = Math.floor(monthlySales / 30);
    // Add some variation to daily sales
    const dailySalesVariation = Math.floor(dailySalesBase * (0.8 + Math.random() * 0.4));
    
    const normalizedMarketplace = normalizeMarketplace(marketplace);
    const product: InsertProduct = {
      name: productData.name,
      imageUrl: null,
      sourceMarketplace: normalizedMarketplace,
      sourceUrl: generateMarketplaceUrl(normalizedMarketplace, productData.name),
      sourcePrice: adjustedPrice,
      sourceCurrency: productData.currency,
      botType: botType,
      category: category,
      dailySales: dailySalesVariation, // Now shows 33+ daily (1000+ monthly)
      competitorCount: Math.floor(Math.random() * 30) + 5,
      isWorthPublishing: monthlySales > 10000, // Auto-recommend high sellers
    };

    if (botType === 2) {
      const targetMarketplaces = ["ebay", "mercadolibre"];
      const targetMarketplace = targetMarketplaces[Math.floor(Math.random() * 2)];
      product.targetMarketplace = targetMarketplace;
      product.targetUrl = generateMarketplaceUrl(targetMarketplace, productData.name);
      product.targetPrice = adjustedPrice * (1 + Math.random() * 0.5);
      product.targetCurrency = productData.currency;
      product.estimatedProfit = product.targetPrice - adjustedPrice;
      product.profitPercentage = ((product.targetPrice - adjustedPrice) / adjustedPrice) * 100;
    }

    if (botType === 3) {
      const stockLevels = ["bajo", "medio", "alto", "agotado"];
      const demandLevels = ["alto", "medio", "bajo"];
      product.stockLevel = stockLevels[Math.floor(Math.random() * 4)];
      product.demandLevel = demandLevels[Math.floor(Math.random() * 3)];
      product.priceChange = (Math.random() - 0.5) * 20;
      // Add target marketplace suggestion for Bot 3
      const targetMarketplace = suggestTargetMarketplace(normalizedMarketplace);
      product.targetMarketplace = targetMarketplace;
      product.targetUrl = generateMarketplaceUrl(targetMarketplace, productData.name);
      const marginPercent = 15 + Math.random() * 15;
      product.estimatedProfit = Math.round(adjustedPrice * (marginPercent / 100) * 100) / 100;
      product.targetPrice = Math.round((adjustedPrice + product.estimatedProfit) * 100) / 100;
      product.targetCurrency = productData.currency;
      product.profitPercentage = marginPercent;
    }

    if (botType === 1) {
      const demandLevels = ["alto", "medio", "bajo"];
      product.demandLevel = demandLevels[Math.floor(Math.random() * 3)];
      // Add target marketplace suggestion for Bot 1
      const targetMarketplace = suggestTargetMarketplace(normalizedMarketplace);
      product.targetMarketplace = targetMarketplace;
      product.targetUrl = generateMarketplaceUrl(targetMarketplace, productData.name);
      const marginPercent = 15 + Math.random() * 15;
      product.estimatedProfit = Math.round(adjustedPrice * (marginPercent / 100) * 100) / 100;
      product.targetPrice = Math.round((adjustedPrice + product.estimatedProfit) * 100) / 100;
      product.targetCurrency = productData.currency;
      product.profitPercentage = marginPercent;
    }

    products.push(product);
  }

  return products;
}

export async function runBot1(): Promise<{ productsFound: number }> {
  const marketplaces = ["ebay", "mercadolibre", "tiktokshop"];
  const products = await generateProductsWithAI(1, marketplaces, 15);
  
  for (const product of products) {
    await storage.createProduct(product);
  }
  
  return { productsFound: products.length };
}

export async function runBot2(): Promise<{ productsFound: number }> {
  const sourceMarketplaces = ["amazon", "walmart", "aliexpress"];
  const products = await generateProductsWithAI(2, sourceMarketplaces, 12);
  
  for (const product of products) {
    await storage.createProduct(product);
  }
  
  return { productsFound: products.length };
}

export async function runBot3(): Promise<{ productsFound: number }> {
  const marketplaces = ["ebay", "mercadolibre", "amazon"];
  const products = await generateProductsWithAI(3, marketplaces, 10);
  
  for (const product of products) {
    await storage.createProduct(product);
  }
  
  return { productsFound: products.length };
}

export async function runBot4(): Promise<{ productsFound: number }> {
  // Bot 4 doesn't find new products, it generates reports
  // Just return the count of all products available
  const allProducts = await storage.getProducts();
  return { productsFound: allProducts.length };
}

export async function runBot(botType: number): Promise<{ productsFound: number }> {
  switch (botType) {
    case 1:
      return runBot1();
    case 2:
      return runBot2();
    case 3:
      return runBot3();
    case 4:
      return runBot4();
    default:
      throw new Error(`Bot ${botType} no existe`);
  }
}
