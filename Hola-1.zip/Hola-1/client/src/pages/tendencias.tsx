import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { TrendingUp, BarChart3, PieChart, DollarSign, Flame, ShoppingCart, Store, Package, ExternalLink, Trophy, Star } from "lucide-react";
import type { Product } from "@shared/schema";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface TrendDataPoint {
  date: string;
  count: number;
  totalProfit: number;
}

interface MarketplaceDistribution {
  marketplace: string;
  count: number;
  averageProfit: number;
}

interface CategoryDistribution {
  category: string;
  count: number;
  totalProfit: number;
}

interface TrendsResponse {
  productTrends: TrendDataPoint[];
  profitTrends: TrendDataPoint[];
}

interface DistributionResponse {
  marketplaceDistribution: MarketplaceDistribution[];
  categoryDistribution: CategoryDistribution[];
}

const MARKETPLACE_COLORS: Record<string, string> = {
  ebay: "#E53238",
  mercadolibre: "#FFE600",
  amazon: "#FF9900",
  walmart: "#0071CE",
  aliexpress: "#FF4747",
  tiktokshop: "#00F2EA",
};

const CATEGORY_COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "#8884d8",
  "#82ca9d",
  "#ffc658",
  "#ff8042",
  "#a4de6c",
];

function formatMarketplaceName(name: string): string {
  const names: Record<string, string> = {
    ebay: "eBay",
    mercadolibre: "Mercado Libre",
    amazon: "Amazon",
    walmart: "Walmart",
    aliexpress: "AliExpress",
    tiktokshop: "TikTok Shop",
  };
  return names[name.toLowerCase()] || name;
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(value);
}

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr);
    return format(date, "dd MMM", { locale: es });
  } catch {
    return dateStr;
  }
}

export default function Tendencias() {
  const [days, setDays] = useState("30");

  const { data: trendsData, isLoading: trendsLoading } = useQuery<TrendsResponse>({
    queryKey: ["/api/analytics/trends", days],
    queryFn: async () => {
      const res = await fetch(`/api/analytics/trends?days=${days}`);
      if (!res.ok) throw new Error("Error loading trends");
      return res.json();
    },
  });

  const { data: distributionData, isLoading: distributionLoading } = useQuery<DistributionResponse>({
    queryKey: ["/api/analytics/distribution"],
    queryFn: async () => {
      const res = await fetch("/api/analytics/distribution");
      if (!res.ok) throw new Error("Error loading distribution");
      return res.json();
    },
  });

  interface DashboardData {
    latestProducts: Product[];
  }

  const { data: dashboardData } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
  });

  const topSellingProducts = (dashboardData?.latestProducts || [])
    .filter(p => p.dailySales && p.dailySales > 0)
    .sort((a, b) => (b.dailySales || 0) - (a.dailySales || 0))
    .slice(0, 10);

  const topProfitProducts = (dashboardData?.latestProducts || [])
    .filter(p => p.estimatedProfit && p.estimatedProfit > 0)
    .sort((a, b) => (b.estimatedProfit || 0) - (a.estimatedProfit || 0))
    .slice(0, 10);

  const isLoading = trendsLoading || distributionLoading;

  const formattedTrends = trendsData?.productTrends.map(d => ({
    ...d,
    date: formatDate(d.date),
  })) || [];

  const formattedProfitTrends = trendsData?.profitTrends.map(d => ({
    ...d,
    date: formatDate(d.date),
  })) || [];

  const marketplaceData = distributionData?.marketplaceDistribution.map(d => ({
    name: formatMarketplaceName(d.marketplace),
    value: d.count,
    averageProfit: d.averageProfit,
    fill: MARKETPLACE_COLORS[d.marketplace.toLowerCase()] || "#8884d8",
  })) || [];

  const categoryData = distributionData?.categoryDistribution.map((d, i) => ({
    name: d.category.length > 15 ? d.category.substring(0, 15) + "..." : d.category,
    fullName: d.category,
    count: d.count,
    profit: d.totalProfit,
    fill: CATEGORY_COLORS[i % CATEGORY_COLORS.length],
  })) || [];

  return (
    <div className="p-6 space-y-6" data-testid="page-tendencias">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-muted-foreground" />
          <div>
            <h1 className="text-2xl font-semibold" data-testid="text-title">
              Tendencias y Analíticas
            </h1>
            <p className="text-muted-foreground text-sm">
              Visualiza el rendimiento de productos y oportunidades
            </p>
          </div>
        </div>

        <Select value={days} onValueChange={setDays} data-testid="select-days">
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Últimos 7 días</SelectItem>
            <SelectItem value="14">Últimos 14 días</SelectItem>
            <SelectItem value="30">Últimos 30 días</SelectItem>
            <SelectItem value="90">Últimos 90 días</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-5 w-40" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-64 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          <Card data-testid="card-products-trend">
            <CardHeader className="flex flex-row items-center gap-2">
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Productos Encontrados por Día</CardTitle>
            </CardHeader>
            <CardContent>
              {formattedTrends.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={formattedTrends}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                      formatter={(value: number) => [value, "Productos"]}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="count"
                      name="Productos"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Sin datos en este período
                </div>
              )}
            </CardContent>
          </Card>

          <Card data-testid="card-profit-trend">
            <CardHeader className="flex flex-row items-center gap-2">
              <DollarSign className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Ganancias Potenciales por Día</CardTitle>
            </CardHeader>
            <CardContent>
              {formattedProfitTrends.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={formattedProfitTrends}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                    <YAxis
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => `$${value}`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                      formatter={(value: number) => [formatCurrency(value), "Ganancia"]}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="totalProfit"
                      name="Ganancia Total"
                      stroke="hsl(var(--chart-2))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--chart-2))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Sin datos en este período
                </div>
              )}
            </CardContent>
          </Card>

          <Card data-testid="card-marketplace-distribution">
            <CardHeader className="flex flex-row items-center gap-2">
              <PieChart className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Distribución por Marketplace</CardTitle>
            </CardHeader>
            <CardContent>
              {marketplaceData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <RechartsPieChart>
                    <Pie
                      data={marketplaceData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {marketplaceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                      formatter={(value: number, name: string, props: any) => [
                        `${value} productos`,
                        name,
                      ]}
                    />
                  </RechartsPieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Sin datos disponibles
                </div>
              )}
            </CardContent>
          </Card>

          <Card data-testid="card-category-distribution">
            <CardHeader className="flex flex-row items-center gap-2">
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Top 10 Categorías</CardTitle>
            </CardHeader>
            <CardContent>
              {categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={categoryData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" tick={{ fontSize: 12 }} />
                    <YAxis
                      type="category"
                      dataKey="name"
                      tick={{ fontSize: 11 }}
                      width={100}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                      }}
                      formatter={(value: number, name: string) => [
                        name === "count" ? `${value} productos` : formatCurrency(value),
                        name === "count" ? "Cantidad" : "Ganancia",
                      ]}
                      labelFormatter={(label: string) => label}
                    />
                    <Legend />
                    <Bar dataKey="count" name="Productos" fill="hsl(var(--chart-1))" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Sin categorías disponibles
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* TOP PRODUCTOS MÁS VENDIDOS */}
      {topSellingProducts.length > 0 && (
        <Card data-testid="card-top-selling">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/20">
                <Flame className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <CardTitle className="text-lg">TOP 10 Productos Más Vendidos</CardTitle>
                <CardDescription>Productos con mayor cantidad de ventas diarias</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topSellingProducts.map((product, index) => (
                <div 
                  key={product.id}
                  className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 border"
                  data-testid={`top-selling-${product.id}`}
                >
                  {/* Ranking */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                    index === 0 ? 'bg-yellow-500' : 
                    index === 1 ? 'bg-gray-400' : 
                    index === 2 ? 'bg-amber-600' : 
                    'bg-muted-foreground'
                  }`}>
                    #{index + 1}
                  </div>

                  {/* Icon */}
                  <div className="w-12 h-12 rounded-md bg-background flex items-center justify-center border">
                    <Package className="w-6 h-6 text-muted-foreground" />
                  </div>

                  {/* Product Info */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm leading-snug">{product.name}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="outline" className="text-xs">
                        {product.category || 'Sin categoría'}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {product.sourceMarketplace}
                      </Badge>
                    </div>
                  </div>

                  {/* Sales */}
                  <div className="text-center px-4 shrink-0">
                    <p className="text-xl font-bold text-orange-500">{product.dailySales}</p>
                    <p className="text-xs text-muted-foreground">ventas/día</p>
                  </div>

                  {/* Price */}
                  <div className="text-right px-4">
                    <p className="font-semibold">{product.sourceCurrency || 'USD'} ${product.sourcePrice?.toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">precio</p>
                  </div>

                  {/* Action */}
                  {product.sourceUrl && (
                    <Button variant="outline" size="sm" asChild className="gap-1 shrink-0">
                      <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                        Ver
                      </a>
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* TOP PRODUCTOS POR GANANCIA */}
      {topProfitProducts.length > 0 && (
        <Card data-testid="card-top-profit">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <Trophy className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <CardTitle className="text-lg">TOP 10 Productos por Ganancia</CardTitle>
                <CardDescription>Productos con mayor margen de ganancia estimado</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topProfitProducts.map((product, index) => (
                <div 
                  key={product.id}
                  className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 border"
                  data-testid={`top-profit-${product.id}`}
                >
                  {/* Ranking */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                    index === 0 ? 'bg-green-500' : 
                    index === 1 ? 'bg-green-400' : 
                    index === 2 ? 'bg-green-300 text-green-800' : 
                    'bg-muted-foreground'
                  }`}>
                    #{index + 1}
                  </div>

                  {/* Icon */}
                  <div className="w-12 h-12 rounded-md bg-background flex items-center justify-center border">
                    <Star className="w-6 h-6 text-muted-foreground" />
                  </div>

                  {/* Product Info */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm leading-snug">{product.name}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="outline" className="text-xs">
                        <ShoppingCart className="w-3 h-3 mr-1" />
                        {product.sourceMarketplace}
                      </Badge>
                      {product.targetMarketplace && (
                        <Badge variant="secondary" className="text-xs bg-blue-500/20 text-blue-700 dark:text-blue-300">
                          <Store className="w-3 h-3 mr-1" />
                          {product.targetMarketplace}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Profit */}
                  <div className="text-center px-4 shrink-0">
                    <p className="text-xl font-bold text-green-500">
                      ${product.estimatedProfit?.toFixed(0)}
                    </p>
                    <p className="text-xs text-muted-foreground">ganancia</p>
                  </div>

                  {/* Percentage */}
                  <div className="text-right px-4">
                    <p className="font-semibold text-green-600 dark:text-green-400">
                      +{product.profitPercentage?.toFixed(1)}%
                    </p>
                    <p className="text-xs text-muted-foreground">margen</p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    {product.sourceUrl && (
                      <Button variant="outline" size="sm" asChild className="gap-1">
                        <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                          <ShoppingCart className="w-3 h-3" />
                          Comprar
                        </a>
                      </Button>
                    )}
                    {product.targetUrl && (
                      <Button variant="default" size="sm" asChild className="gap-1">
                        <a href={product.targetUrl} target="_blank" rel="noopener noreferrer">
                          <Store className="w-3 h-3" />
                          Vender
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
