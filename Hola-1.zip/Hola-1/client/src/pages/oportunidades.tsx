import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { History, CheckCircle2, XCircle, Clock, TrendingUp, Target } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Product, OpportunityAction } from "@shared/schema";

interface OpportunityWithProduct extends OpportunityAction {
  product?: Product;
}

interface OpportunityStats {
  taken: number;
  missed: number;
  pending: number;
}

function formatCurrency(value: number, currency: string = "USD"): string {
  const symbols: Record<string, string> = {
    USD: "$",
    MXN: "MX$",
    EUR: "\u20AC",
  };
  const symbol = symbols[currency] || currency + " ";
  return `${symbol}${value.toFixed(2)}`;
}

function formatDate(dateStr: string | Date | null): string {
  if (!dateStr) return "-";
  try {
    const date = typeof dateStr === "string" ? new Date(dateStr) : dateStr;
    return format(date, "dd MMM yyyy HH:mm", { locale: es });
  } catch {
    return "-";
  }
}

function StatusBadge({ status }: { status: string }) {
  if (status === "aprovechada") {
    return (
      <Badge variant="default" className="bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30">
        <CheckCircle2 className="h-3 w-3 mr-1" />
        Aprovechada
      </Badge>
    );
  }
  if (status === "perdida") {
    return (
      <Badge variant="default" className="bg-red-500/20 text-red-600 dark:text-red-400 border-red-500/30">
        <XCircle className="h-3 w-3 mr-1" />
        Perdida
      </Badge>
    );
  }
  return (
    <Badge variant="secondary">
      <Clock className="h-3 w-3 mr-1" />
      Pendiente
    </Badge>
  );
}

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  colorClass 
}: { 
  title: string; 
  value: number; 
  icon: typeof CheckCircle2;
  colorClass: string;
}) {
  return (
    <Card data-testid={`stat-${title.toLowerCase().replace(/\s+/g, "-")}`}>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
          </div>
          <div className={`p-3 rounded-full ${colorClass}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MarkOpportunityDialog({
  products,
  onSuccess,
}: {
  products: Product[];
  onSuccess: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [action, setAction] = useState<string>("");
  const [notes, setNotes] = useState("");
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: async (data: { productId: string; action: string; notes: string }) => {
      return apiRequest("POST", "/api/opportunities", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/opportunities/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Registrado",
        description: "La acción ha sido registrada correctamente.",
      });
      setOpen(false);
      setSelectedProduct("");
      setAction("");
      setNotes("");
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo registrar la acción.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!selectedProduct || !action) {
      toast({
        title: "Error",
        description: "Selecciona un producto y una acción.",
        variant: "destructive",
      });
      return;
    }
    mutation.mutate({ productId: selectedProduct, action, notes });
  };

  const pendingProducts = products.filter(p => p.opportunityStatus === "pendiente" || !p.opportunityStatus);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-mark-opportunity">
          <Target className="h-4 w-4 mr-2" />
          Marcar Oportunidad
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Marcar Oportunidad</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div>
            <Label>Producto</Label>
            <select
              className="w-full mt-1 p-2 border rounded-md bg-background"
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              data-testid="select-product"
            >
              <option value="">Seleccionar producto...</option>
              {pendingProducts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name.length > 40 ? p.name.substring(0, 40) + "..." : p.name}
                </option>
              ))}
            </select>
            {pendingProducts.length === 0 && (
              <p className="text-sm text-muted-foreground mt-1">
                No hay productos pendientes de marcar.
              </p>
            )}
          </div>

          <div>
            <Label>Acción</Label>
            <div className="flex gap-2 mt-1">
              <Button
                type="button"
                variant={action === "aprovechada" ? "default" : "outline"}
                className={action === "aprovechada" ? "bg-green-600" : ""}
                onClick={() => setAction("aprovechada")}
                data-testid="button-action-taken"
              >
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Aprovechada
              </Button>
              <Button
                type="button"
                variant={action === "perdida" ? "default" : "outline"}
                className={action === "perdida" ? "bg-red-600" : ""}
                onClick={() => setAction("perdida")}
                data-testid="button-action-missed"
              >
                <XCircle className="h-4 w-4 mr-1" />
                Perdida
              </Button>
            </div>
          </div>

          <div>
            <Label>Notas (opcional)</Label>
            <Textarea
              className="mt-1"
              placeholder="Agrega notas sobre esta oportunidad..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="input-notes"
            />
          </div>

          <Button 
            className="w-full" 
            onClick={handleSubmit}
            disabled={mutation.isPending || !selectedProduct || !action}
            data-testid="button-submit"
          >
            {mutation.isPending ? "Guardando..." : "Guardar"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Oportunidades() {
  const { data: actions, isLoading: actionsLoading, refetch: refetchActions } = useQuery<OpportunityWithProduct[]>({
    queryKey: ["/api/opportunities"],
    queryFn: async () => {
      const res = await fetch("/api/opportunities?limit=100");
      if (!res.ok) throw new Error("Error loading opportunities");
      return res.json();
    },
  });

  const { data: stats, isLoading: statsLoading } = useQuery<OpportunityStats>({
    queryKey: ["/api/opportunities/stats"],
    queryFn: async () => {
      const res = await fetch("/api/opportunities/stats");
      if (!res.ok) throw new Error("Error loading stats");
      return res.json();
    },
  });

  const { data: allProducts } = useQuery<Product[]>({
    queryKey: ["/api/products/filter", "all"],
    queryFn: async () => {
      const res = await fetch("/api/products/filter?limit=200");
      if (!res.ok) throw new Error("Error loading products");
      return res.json();
    },
  });

  const isLoading = actionsLoading || statsLoading;

  return (
    <div className="p-6 space-y-6" data-testid="page-oportunidades">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Target className="h-8 w-8 text-muted-foreground" />
          <div>
            <h1 className="text-2xl font-semibold" data-testid="text-title">
              Historial de Oportunidades
            </h1>
            <p className="text-muted-foreground text-sm">
              Seguimiento de productos marcados como aprovechados o perdidos
            </p>
          </div>
        </div>

        {allProducts && allProducts.length > 0 && (
          <MarkOpportunityDialog 
            products={allProducts} 
            onSuccess={() => refetchActions()} 
          />
        )}
      </div>

      {isLoading ? (
        <>
          <div className="grid gap-4 md:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <Skeleton className="h-16 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-3" data-testid="stats-grid">
            <StatCard
              title="Aprovechadas"
              value={stats?.taken || 0}
              icon={CheckCircle2}
              colorClass="bg-green-500/20 text-green-600"
            />
            <StatCard
              title="Perdidas"
              value={stats?.missed || 0}
              icon={XCircle}
              colorClass="bg-red-500/20 text-red-600"
            />
            <StatCard
              title="Pendientes"
              value={stats?.pending || 0}
              icon={Clock}
              colorClass="bg-yellow-500/20 text-yellow-600"
            />
          </div>

          <Card data-testid="card-history">
            <CardHeader className="flex flex-row items-center gap-2">
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
              <CardTitle className="text-base">Registro de Acciones</CardTitle>
            </CardHeader>
            <CardContent>
              {!actions || actions.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground" data-testid="empty-state">
                  <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No hay acciones registradas aún.</p>
                  <p className="text-sm mt-1">
                    Marca productos como aprovechados o perdidos usando el botón de arriba.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {actions.map((action) => (
                    <div
                      key={action.id}
                      className="flex items-center justify-between p-4 rounded-lg border gap-4"
                      data-testid={`action-${action.id}`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium truncate max-w-xs">
                            {action.product?.name || "Producto no encontrado"}
                          </span>
                          <StatusBadge status={action.action} />
                        </div>
                        {action.product && (
                          <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground flex-wrap">
                            <span>{action.product.sourceMarketplace}</span>
                            {action.product.sourcePrice && (
                              <span>
                                {formatCurrency(action.product.sourcePrice, action.product.sourceCurrency || "USD")}
                              </span>
                            )}
                            {action.product.estimatedProfit && action.product.estimatedProfit > 0 && (
                              <span className="text-green-600">
                                +{formatCurrency(action.product.estimatedProfit, "USD")} ganancia
                              </span>
                            )}
                          </div>
                        )}
                        {action.notes && (
                          <p className="text-sm text-muted-foreground mt-2 italic">
                            "{action.notes}"
                          </p>
                        )}
                      </div>
                      <div className="text-right text-sm text-muted-foreground whitespace-nowrap">
                        {formatDate(action.actionAt)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
