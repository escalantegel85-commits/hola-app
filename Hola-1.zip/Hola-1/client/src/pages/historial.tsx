import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  History, 
  Target, 
  Scale, 
  Package, 
  FileSpreadsheet,
  Check,
  AlertCircle,
  Loader2,
  Clock
} from "lucide-react";
import type { BotRun } from "@shared/schema";

const botIcons = {
  1: Target,
  2: Scale,
  3: Package,
  4: FileSpreadsheet,
};

const botNames = {
  1: "Productos Ganadores",
  2: "Arbitraje",
  3: "Reabastecimiento",
  4: "Reportes",
};

const botColors = {
  1: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  2: "bg-green-500/10 text-green-600 dark:text-green-400",
  3: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
  4: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
};

function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "-";
  return new Date(date).toLocaleString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function formatDuration(start: Date | string | null, end: Date | string | null): string {
  if (!start || !end) return "-";
  const startDate = new Date(start);
  const endDate = new Date(end);
  const diffMs = endDate.getTime() - startDate.getTime();
  
  if (diffMs < 1000) return `${diffMs}ms`;
  if (diffMs < 60000) return `${Math.round(diffMs / 1000)}s`;
  return `${Math.round(diffMs / 60000)}m ${Math.round((diffMs % 60000) / 1000)}s`;
}

function getStatusBadge(status: string) {
  switch (status) {
    case "ejecutando":
      return (
        <Badge variant="secondary" className="gap-1">
          <Loader2 className="w-3 h-3 animate-spin" />
          Ejecutando
        </Badge>
      );
    case "completado":
      return (
        <Badge variant="default" className="gap-1 bg-green-600">
          <Check className="w-3 h-3" />
          Completado
        </Badge>
      );
    case "error":
      return (
        <Badge variant="destructive" className="gap-1">
          <AlertCircle className="w-3 h-3" />
          Error
        </Badge>
      );
    default:
      return (
        <Badge variant="outline" className="gap-1">
          <Clock className="w-3 h-3" />
          Pendiente
        </Badge>
      );
  }
}

export default function HistorialPage() {
  const { data: botRuns, isLoading } = useQuery<BotRun[]>({
    queryKey: ["/api/bots/history"],
  });

  return (
    <div className="p-8 space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-muted">
            <History className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-semibold">Historial de Ejecuciones</h1>
        </div>
        <p className="text-muted-foreground">
          Registro completo de todas las ejecuciones de los bots
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Últimas Ejecuciones</CardTitle>
          <CardDescription>
            Historial de las últimas 50 ejecuciones de todos los bots
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <Skeleton className="w-10 h-10 rounded-lg" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-24" />
                </div>
              ))}
            </div>
          ) : botRuns && botRuns.length > 0 ? (
            <div className="space-y-3">
              {botRuns.map((run) => {
                const Icon = botIcons[run.botType as keyof typeof botIcons] || Target;
                const colorClass = botColors[run.botType as keyof typeof botColors] || botColors[1];
                const botName = botNames[run.botType as keyof typeof botNames] || `Bot ${run.botType}`;
                
                return (
                  <div 
                    key={run.id} 
                    className="flex items-center justify-between p-4 rounded-lg border"
                    data-testid={`history-row-${run.id}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${colorClass}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium">Bot {run.botType}: {botName}</p>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatDate(run.startedAt)}
                          </span>
                          {run.completedAt && (
                            <span>
                              Duración: {formatDuration(run.startedAt, run.completedAt)}
                            </span>
                          )}
                          <span className="font-mono">
                            {run.productsFound ?? 0} productos
                          </span>
                        </div>
                        {run.errorMessage && (
                          <p className="text-sm text-destructive mt-1">
                            {run.errorMessage}
                          </p>
                        )}
                      </div>
                    </div>
                    {getStatusBadge(run.status)}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <History className="w-12 h-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">Sin historial</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Las ejecuciones de los bots aparecerán aquí
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
