import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { ProductTable } from "@/components/product-table";
import { ProductFilters } from "@/components/product-filters";
import { BotStatusCard } from "@/components/bot-status-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Package, AlertTriangle, TrendingUp, Users } from "lucide-react";
import type { Product, BotRun } from "@shared/schema";

interface Bot3Data {
  products: Product[];
  lastRun: BotRun | null;
  stats: {
    lowStockProducts: number;
    fastSellingProducts: number;
    noCompetitionProducts: number;
    priceIncreaseProducts: number;
  };
}

export default function Bot3Page() {
  const { toast } = useToast();
  const [filters, setFilters] = useState<Record<string, string | undefined>>({});

  const { data, isLoading } = useQuery<Bot3Data>({
    queryKey: ["/api/bots/3/products"],
  });

  const { data: filteredProducts } = useQuery<Product[]>({
    queryKey: ["/api/products/filter", { ...filters, botType: "3" }],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("botType", "3");
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });
      const res = await fetch(`/api/products/filter?${params}`);
      return res.json();
    },
    enabled: Object.keys(filters).some(k => filters[k] !== undefined),
  });

  const displayProducts = Object.values(filters).some(v => v !== undefined)
    ? (filteredProducts || [])
    : (data?.products || []);

  const runBotMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/bots/3/run");
    },
    onSuccess: () => {
      toast({
        title: "Bot Iniciado",
        description: "El Bot 3 ha comenzado a analizar stock y escasez",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/3/products"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stats = data?.stats || {
    lowStockProducts: 0,
    fastSellingProducts: 0,
    noCompetitionProducts: 0,
    priceIncreaseProducts: 0,
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-orange-500/10">
              <Package className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
            <h1 className="text-3xl font-semibold">Bot 3: Reabastecimiento y Escasez</h1>
          </div>
          <p className="text-muted-foreground">
            Detecta productos agotándose, alta velocidad de venta y oportunidades sin competencia
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <BotStatusCard
            botNumber={3}
            title="Bot 3: Escasez"
            description="Monitorea stock y precios en tiempo real"
            lastRun={data?.lastRun}
            isRunning={runBotMutation.isPending}
            onRun={() => runBotMutation.mutate()}
          />
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Análisis de Escasez</CardTitle>
              <CardDescription>Oportunidades detectadas por tipo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    Stock Bajo
                  </div>
                  <p className="text-2xl font-bold font-mono text-red-600">{stats.lowStockProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <TrendingUp className="w-4 h-4 text-orange-500" />
                    Venta Rápida
                  </div>
                  <p className="text-2xl font-bold font-mono text-orange-600">{stats.fastSellingProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Users className="w-4 h-4 text-green-500" />
                    Sin Competencia
                  </div>
                  <p className="text-2xl font-bold font-mono text-green-600">{stats.noCompetitionProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <TrendingUp className="w-4 h-4 text-blue-500" />
                    Precio Subió
                  </div>
                  <p className="text-2xl font-bold font-mono text-blue-600">{stats.priceIncreaseProducts}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="text-xl">Productos con Oportunidades de Escasez</CardTitle>
            <CardDescription>
              Productos para comprar antes de que se agoten o suban de precio
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="destructive" className="text-xs">Stock Bajo</Badge>
            <Badge variant="secondary" className="text-xs bg-orange-500/20 text-orange-700 dark:text-orange-400">
              Venta Rápida
            </Badge>
            <Badge variant="secondary" className="text-xs bg-green-500/20 text-green-700 dark:text-green-400">
              Sin Competencia
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <ProductFilters
            onFiltersChange={setFilters}
            showDemandLevel={true}
            showStockLevel={true}
          />
          <ProductTable 
            products={displayProducts} 
            isLoading={isLoading}
            showStock
          />
        </CardContent>
      </Card>
    </div>
  );
}
