import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Settings, Mail, Clock, Save, Bell, DollarSign, Percent, AlertCircle, Download, Shield, Eye, EyeOff, Lock } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import type { Settings as SettingsType } from "@shared/schema";

const settingsSchema = z.object({
  email: z.string().email("Email inválido").or(z.literal("")),
  scheduleHours: z.number().min(1).max(24),
  isAutoRunEnabled: z.boolean(),
  minProfitAlert: z.number().min(0).max(10000),
  minProfitPercentageAlert: z.number().min(0).max(100),
  alertsEnabled: z.boolean(),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export default function ConfiguracionPage() {
  const { toast } = useToast();
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const { data: settings, isLoading } = useQuery<SettingsType>({
    queryKey: ["/api/settings"],
  });

  const { data: masterPasswordStatus } = useQuery<{ isEnabled: boolean; isSet: boolean }>({
    queryKey: ["/api/auth/master-password-status"],
  });

  const setMasterPasswordMutation = useMutation({
    mutationFn: async (data: { password: string; currentPassword?: string }) => {
      await apiRequest("POST", "/api/auth/set-master-password", data);
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Contraseña Configurada",
        description: "Tu contraseña maestra ha sido configurada exitosamente",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/master-password-status"] });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo configurar la contraseña",
        variant: "destructive",
      });
    },
  });

  const disableMasterPasswordMutation = useMutation({
    mutationFn: async (password: string) => {
      await apiRequest("POST", "/api/auth/disable-master-password", { password });
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Contraseña Desactivada",
        description: "La contraseña maestra ha sido desactivada",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/master-password-status"] });
      sessionStorage.removeItem("masterPasswordVerified");
      setCurrentPassword("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo desactivar la contraseña",
        variant: "destructive",
      });
    },
  });

  const handleSetMasterPassword = () => {
    if (newPassword.length < 4) {
      toast({
        title: "Error",
        description: "La contraseña debe tener al menos 4 caracteres",
        variant: "destructive",
      });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      });
      return;
    }
    setMasterPasswordMutation.mutate({
      password: newPassword,
      currentPassword: masterPasswordStatus?.isEnabled ? currentPassword : undefined,
    });
  };

  const handleDisableMasterPassword = () => {
    if (!currentPassword) {
      toast({
        title: "Error",
        description: "Ingresa tu contraseña actual para desactivar",
        variant: "destructive",
      });
      return;
    }
    disableMasterPasswordMutation.mutate(currentPassword);
  };

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      email: "",
      scheduleHours: 6,
      isAutoRunEnabled: true,
      minProfitAlert: 20,
      minProfitPercentageAlert: 15,
      alertsEnabled: true,
    },
    values: settings ? {
      email: settings.email || "",
      scheduleHours: settings.scheduleHours || 6,
      isAutoRunEnabled: settings.isAutoRunEnabled ?? true,
      minProfitAlert: settings.minProfitAlert ?? 20,
      minProfitPercentageAlert: settings.minProfitPercentageAlert ?? 15,
      alertsEnabled: settings.alertsEnabled ?? true,
    } : undefined,
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: SettingsFormData) => {
      return await apiRequest("PUT", "/api/settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Configuración Guardada",
        description: "Los cambios han sido guardados exitosamente",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SettingsFormData) => {
    updateSettingsMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-8">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-muted">
            <Settings className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-semibold">Configuración</h1>
        </div>
        <p className="text-muted-foreground">
          Configura las opciones de tus bots y notificaciones
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Notificaciones por Email
              </CardTitle>
              <CardDescription>
                Configura tu email para recibir reportes automáticos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="border-amber-500/50 bg-amber-500/10" data-testid="alert-smtp-config">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                <AlertTitle className="text-amber-600 dark:text-amber-400">Configuración de servidor de correo requerida</AlertTitle>
                <AlertDescription className="text-muted-foreground">
                  Para enviar reportes por email, es necesario configurar un servidor SMTP. 
                  Contacta al administrador para configurar las variables de entorno: 
                  <span className="font-mono text-xs ml-1">SMTP_HOST</span>, 
                  <span className="font-mono text-xs">SMTP_PORT</span>, 
                  <span className="font-mono text-xs">SMTP_USER</span>, 
                  <span className="font-mono text-xs">SMTP_PASS</span>.
                  <br />
                  <span className="mt-2 inline-block">
                    Mientras tanto, puedes descargar los reportes directamente desde el panel de cada bot usando el boton 
                    <Download className="inline-block w-3 h-3 mx-1" />
                    Descargar.
                  </span>
                </AlertDescription>
              </Alert>

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Dirección de Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="tu@email.com"
                        {...field}
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormDescription>
                      Recibirás los reportes de productos en este email cuando el servidor SMTP esté configurado
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Alertas de Ganancias
              </CardTitle>
              <CardDescription>
                Configura los umbrales para recibir alertas de productos rentables
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="alertsEnabled"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Alertas Activas</FormLabel>
                      <FormDescription>
                        Mostrar alertas cuando se encuentren productos que superen los umbrales
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-alerts-enabled"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="minProfitAlert"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4" />
                        Ganancia Mínima (USD)
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={0}
                          step={1}
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          disabled={!form.watch("alertsEnabled")}
                          data-testid="input-min-profit"
                        />
                      </FormControl>
                      <FormDescription>
                        Alerta cuando la ganancia estimada supere este monto
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="minProfitPercentageAlert"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Percent className="w-4 h-4" />
                        Margen Mínimo (%)
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={0}
                          max={100}
                          step={1}
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          disabled={!form.watch("alertsEnabled")}
                          data-testid="input-min-percentage"
                        />
                      </FormControl>
                      <FormDescription>
                        Alerta cuando el margen de ganancia supere este porcentaje
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Programación Automática
              </CardTitle>
              <CardDescription>
                Configura la frecuencia de ejecución de los bots
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="isAutoRunEnabled"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Ejecución Automática</FormLabel>
                      <FormDescription>
                        Ejecutar los bots automáticamente según la frecuencia configurada
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-auto-run"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="scheduleHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Frecuencia de Ejecución</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      value={field.value.toString()}
                      disabled={!form.watch("isAutoRunEnabled")}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-frequency">
                          <SelectValue placeholder="Selecciona la frecuencia" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1">Cada 1 hora</SelectItem>
                        <SelectItem value="2">Cada 2 horas</SelectItem>
                        <SelectItem value="4">Cada 4 horas</SelectItem>
                        <SelectItem value="6">Cada 6 horas</SelectItem>
                        <SelectItem value="8">Cada 8 horas</SelectItem>
                        <SelectItem value="12">Cada 12 horas</SelectItem>
                        <SelectItem value="24">Cada 24 horas</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Los bots se ejecutarán automáticamente cada {form.watch("scheduleHours")} horas
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button
              type="submit"
              className="gap-2"
              disabled={updateSettingsMutation.isPending}
              data-testid="button-save-settings"
            >
              <Save className="w-4 h-4" />
              {updateSettingsMutation.isPending ? "Guardando..." : "Guardar Configuración"}
            </Button>
          </div>
        </form>
      </Form>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Contraseña Maestra
          </CardTitle>
          <CardDescription>
            Añade una capa extra de seguridad con una contraseña adicional después del login con Replit
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <div className="font-medium text-base">Estado de Contraseña Maestra</div>
              <div className="text-sm text-muted-foreground">
                {masterPasswordStatus?.isEnabled
                  ? "La contraseña maestra está activada"
                  : "La contraseña maestra está desactivada"}
              </div>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              masterPasswordStatus?.isEnabled
                ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                : "bg-muted text-muted-foreground"
            }`} data-testid="status-master-password">
              {masterPasswordStatus?.isEnabled ? "Activa" : "Inactiva"}
            </div>
          </div>

          {masterPasswordStatus?.isEnabled && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Contraseña Actual</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    id="current-password"
                    type={showCurrentPassword ? "text" : "password"}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Ingresa tu contraseña actual"
                    className="pl-10 pr-10"
                    data-testid="input-current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="text-sm font-medium">
              {masterPasswordStatus?.isEnabled ? "Cambiar Contraseña" : "Configurar Contraseña Maestra"}
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">Nueva Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    id="new-password"
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Mínimo 4 caracteres"
                    className="pl-10 pr-10"
                    data-testid="input-new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirmar Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    id="confirm-password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirma tu contraseña"
                    className="pl-10"
                    data-testid="input-confirm-password"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                onClick={handleSetMasterPassword}
                disabled={setMasterPasswordMutation.isPending || !newPassword || !confirmPassword}
                data-testid="button-set-master-password"
              >
                {setMasterPasswordMutation.isPending ? "Guardando..." : 
                  masterPasswordStatus?.isEnabled ? "Cambiar Contraseña" : "Activar Contraseña Maestra"}
              </Button>

              {masterPasswordStatus?.isEnabled && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleDisableMasterPassword}
                  disabled={disableMasterPasswordMutation.isPending || !currentPassword}
                  data-testid="button-disable-master-password"
                >
                  {disableMasterPasswordMutation.isPending ? "Desactivando..." : "Desactivar Contraseña"}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
