import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink, ArrowRight, TrendingUp, ShoppingCart, Store, DollarSign } from "lucide-react";
import type { Product } from "@shared/schema";

export default function ListaCompraVenta() {
  const { data, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/filter"],
  });

  const products = data || [];
  
  // Filter products with profit opportunities and sort by profit percentage (highest first)
  const opportunities = products
    .filter(p => p.estimatedProfit && p.estimatedProfit > 0 && p.targetMarketplace && p.targetPrice)
    .sort((a, b) => (b.profitPercentage || 0) - (a.profitPercentage || 0));

  const formatPrice = (price: number | null, currency: string | null) => {
    if (!price) return "N/A";
    const curr = currency || "USD";
    return `$${price.toFixed(2)} ${curr}`;
  };

  const getMarketplaceName = (mp: string | null) => {
    const names: Record<string, string> = {
      ebay: "eBay",
      mercadolibre: "Mercado Libre",
      amazon: "Amazon",
      walmart: "Walmart",
      aliexpress: "AliExpress",
      tiktokshop: "TikTok Shop",
    };
    return names[mp || ""] || mp || "N/A";
  };

  const getMarketplaceColor = (mp: string | null, type: "buy" | "sell") => {
    if (type === "buy") {
      return "bg-blue-500 text-white";
    }
    return "bg-green-500 text-white";
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="space-y-3">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2" data-testid="text-page-title">
            <DollarSign className="h-7 w-7 text-emerald-500" />
            Lista de Compra / Venta
          </h1>
          <p className="text-muted-foreground">
            Compra barato, vende caro - ordenado por mayor margen de ganancia
          </p>
        </div>
        <Badge variant="outline" className="text-lg px-3 py-1">
          {opportunities.length} productos
        </Badge>
      </div>

      {/* Summary Stats */}
      {opportunities.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-muted-foreground">Inversion Total</p>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                ${opportunities.reduce((sum, p) => sum + (p.sourcePrice || 0), 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-green-500/10 border-green-500/20">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-muted-foreground">Venta Total</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                ${opportunities.reduce((sum, p) => sum + (p.targetPrice || 0), 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-emerald-500/10 border-emerald-500/20">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-muted-foreground">Ganancia Total</p>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                ${opportunities.reduce((sum, p) => sum + (p.estimatedProfit || 0), 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-purple-500/10 border-purple-500/20">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-muted-foreground">Mejor Margen</p>
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                +{Math.max(...opportunities.map(p => p.profitPercentage || 0)).toFixed(1)}%
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Products List */}
      {opportunities.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground">No hay oportunidades de arbitraje disponibles.</p>
            <p className="text-sm text-muted-foreground mt-1">Ejecuta los bots para encontrar productos.</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-500" />
              Productos Ordenados por Ganancia ({opportunities.length} oportunidades)
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-auto max-h-[70vh]">
              <table className="w-full" data-testid="table-buy-sell">
                <thead className="sticky top-0 z-10">
                  <tr className="border-b bg-muted">
                    <th className="text-left p-4 font-medium text-muted-foreground">#</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Producto</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <ShoppingCart className="h-4 w-4 text-blue-500" />
                        Comprar En
                      </div>
                    </th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Precio Compra</th>
                    <th className="text-center p-4 font-medium text-muted-foreground"></th>
                    <th className="text-left p-4 font-medium text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Store className="h-4 w-4 text-green-500" />
                        Vender En
                      </div>
                    </th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Precio Venta</th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Ganancia</th>
                    <th className="text-center p-4 font-medium text-muted-foreground">Links</th>
                  </tr>
                </thead>
                <tbody>
                  {opportunities.map((product, index) => (
                    <tr 
                      key={product.id} 
                      className="border-b hover:bg-muted/30 transition-colors"
                      data-testid={`row-product-${product.id}`}
                    >
                      {/* Rank */}
                      <td className="p-4">
                        <div className="flex items-center justify-center w-7 h-7 rounded-full bg-primary/10 text-primary font-bold text-sm">
                          {index + 1}
                        </div>
                      </td>
                      
                      {/* Product Name */}
                      <td className="p-4">
                        <div className="max-w-xs">
                          <p className="font-medium truncate" title={product.name}>{product.name}</p>
                          <Badge variant="outline" className="text-xs mt-1">{product.category}</Badge>
                        </div>
                      </td>
                      
                      {/* Buy Marketplace */}
                      <td className="p-4">
                        <Badge className={getMarketplaceColor(product.sourceMarketplace, "buy")}>
                          {getMarketplaceName(product.sourceMarketplace)}
                        </Badge>
                      </td>
                      
                      {/* Buy Price */}
                      <td className="p-4 text-right">
                        <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                          {formatPrice(product.sourcePrice, product.sourceCurrency)}
                        </span>
                      </td>
                      
                      {/* Arrow */}
                      <td className="p-4 text-center">
                        <ArrowRight className="h-4 w-4 text-muted-foreground mx-auto" />
                      </td>
                      
                      {/* Sell Marketplace */}
                      <td className="p-4">
                        <Badge className={getMarketplaceColor(product.targetMarketplace, "sell")}>
                          {getMarketplaceName(product.targetMarketplace)}
                        </Badge>
                      </td>
                      
                      {/* Sell Price */}
                      <td className="p-4 text-right">
                        <span className="font-mono font-bold text-green-600 dark:text-green-400">
                          {formatPrice(product.targetPrice, product.targetCurrency)}
                        </span>
                      </td>
                      
                      {/* Profit */}
                      <td className="p-4 text-right">
                        <div className="flex flex-col items-end gap-1">
                          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                            +${product.estimatedProfit?.toFixed(2)}
                          </span>
                          <Badge className="bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-0 text-xs">
                            +{product.profitPercentage?.toFixed(1)}%
                          </Badge>
                        </div>
                      </td>
                      
                      {/* Links */}
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1">
                          {product.sourceUrl && (
                            <Button
                              variant="ghost"
                              size="icon"
                              asChild
                              title="Ver donde comprar"
                              data-testid={`button-buy-link-${product.id}`}
                            >
                              <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                                <ShoppingCart className="h-4 w-4 text-blue-500" />
                              </a>
                            </Button>
                          )}
                          {product.targetUrl && (
                            <Button
                              variant="ghost"
                              size="icon"
                              asChild
                              title="Ver donde vender"
                              data-testid={`button-sell-link-${product.id}`}
                            >
                              <a href={product.targetUrl} target="_blank" rel="noopener noreferrer">
                                <Store className="h-4 w-4 text-green-500" />
                              </a>
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
