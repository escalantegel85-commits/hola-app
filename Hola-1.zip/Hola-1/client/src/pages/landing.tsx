import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { 
  BarChart3, 
  Target, 
  Scale, 
  Package, 
  TrendingUp, 
  Shield,
  Zap,
  ArrowRight,
  Sparkles,
  Globe,
  DollarSign,
  ShoppingCart
} from "lucide-react";

function AnimatedCounter({ end, duration = 2000, suffix = "" }: { end: number; duration?: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    let startTime: number | null = null;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [end, duration]);
  
  return <span>{count.toLocaleString()}{suffix}</span>;
}

function FloatingIcon({ icon: Icon, className, delay = 0 }: { icon: React.ElementType; className: string; delay?: number }) {
  return (
    <motion.div
      className={`absolute ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: [0.2, 0.4, 0.2],
        y: [0, -15, 0],
      }}
      transition={{
        duration: 4,
        delay,
        repeat: Infinity,
        ease: "easeInOut"
      }}
    >
      <Icon className="w-8 h-8 text-slate-500" />
    </motion.div>
  );
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 12
    }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 40, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

const botCards = [
  {
    icon: Target,
    title: "Bot 1: Productos Top",
    description: "Analiza los productos más vendidos en eBay, Mercado Libre y TikTok Shop",
    gradient: "from-blue-500 to-blue-600",
    shadow: "shadow-blue-500/25"
  },
  {
    icon: Scale,
    title: "Bot 2: Arbitraje",
    description: "Identifica diferencias de precio entre Amazon, Walmart y AliExpress",
    gradient: "from-emerald-500 to-emerald-600",
    shadow: "shadow-emerald-500/25"
  },
  {
    icon: Package,
    title: "Bot 3: Escasez",
    description: "Detecta productos con bajo stock y alta demanda para oportunidades rápidas",
    gradient: "from-orange-500 to-orange-600",
    shadow: "shadow-orange-500/25"
  },
  {
    icon: TrendingUp,
    title: "Bot 4: Reportes",
    description: "Genera hojas de cálculo Excel y reportes PDF automáticamente",
    gradient: "from-violet-500 to-violet-600",
    shadow: "shadow-violet-500/25"
  }
];

const stats = [
  { value: 50000, suffix: "+", label: "Productos Analizados" },
  { value: 6, suffix: "", label: "Marketplaces" },
  { value: 24, suffix: "/7", label: "Monitoreo Activo" },
  { value: 85, suffix: "%", label: "Precisión IA" }
];

export default function Landing() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 overflow-hidden">
      <div className="relative">
        <motion.div 
          className="absolute inset-0 bg-grid-white/[0.03] bg-[size:32px_32px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        />
        
        <motion.div 
          className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.15, 0.25, 0.15]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-500/15 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.15, 1],
            opacity: [0.15, 0.25, 0.15]
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        <motion.div 
          className="absolute top-1/2 left-1/2 w-[300px] h-[300px] bg-violet-500/10 rounded-full blur-3xl"
          animate={{ 
            x: [-150, -100, -150],
            y: [-150, -200, -150],
            scale: [1, 1.2, 1]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />

        <div className="hidden md:block">
          <FloatingIcon icon={ShoppingCart} className="top-20 left-[10%]" delay={0} />
          <FloatingIcon icon={DollarSign} className="top-40 right-[15%]" delay={0.5} />
          <FloatingIcon icon={Globe} className="bottom-40 left-[20%]" delay={1} />
          <FloatingIcon icon={Sparkles} className="top-60 left-[80%]" delay={1.5} />
          <FloatingIcon icon={BarChart3} className="bottom-60 right-[10%]" delay={2} />
        </div>
        
        <div className="relative container mx-auto px-4 py-10 sm:py-16 lg:py-24">
          <motion.div 
            className="text-center max-w-4xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate={isVisible ? "visible" : "hidden"}
          >
            <motion.div 
              className="flex justify-center mb-6 sm:mb-8"
              variants={itemVariants}
            >
              <motion.div 
                className="flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/25"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
              >
                <BarChart3 className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </motion.div>
            </motion.div>
            
            <motion.h1 
              className="text-3xl sm:text-4xl lg:text-6xl font-bold tracking-tight mb-4 sm:mb-6 text-white"
              variants={itemVariants}
            >
              <motion.span
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                Mi Bot{" "}
              </motion.span>
              <motion.span
                className="bg-gradient-to-r from-blue-400 via-violet-400 to-emerald-400 bg-clip-text text-transparent"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
              >
                Empresarial
              </motion.span>
            </motion.h1>
            
            <motion.p 
              className="text-base sm:text-xl lg:text-2xl text-slate-300 mb-6 sm:mb-8 max-w-2xl mx-auto px-2"
              variants={itemVariants}
            >
              Descubre productos ganadores y oportunidades de arbitraje en múltiples marketplaces con análisis automatizado impulsado por IA
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center mb-10 sm:mb-16"
              variants={itemVariants}
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button 
                  size="lg" 
                  className="gap-2 text-base sm:text-lg py-5 sm:py-6 px-6 sm:px-8 relative overflow-visible w-full sm:w-auto"
                  onClick={() => window.location.href = "/api/login"}
                  data-testid="button-login"
                >
                  <motion.span
                    className="absolute -inset-1 rounded-lg bg-gradient-to-r from-blue-500 via-violet-500 to-emerald-500 opacity-30 blur-lg"
                    animate={{ 
                      opacity: [0.2, 0.4, 0.2],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="relative flex items-center gap-2">
                    Iniciar Sesión
                    <ArrowRight className="w-5 h-5" />
                  </span>
                </Button>
              </motion.div>
            </motion.div>

            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-10 sm:mb-16 max-w-3xl mx-auto"
              variants={containerVariants}
            >
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="text-center p-3 sm:p-0"
                  variants={itemVariants}
                  whileHover={{ scale: 1.05 }}
                >
                  <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white">
                    {isVisible && <AnimatedCounter end={stat.value} suffix={stat.suffix} duration={2000 + index * 300} />}
                  </div>
                  <div className="text-xs sm:text-sm text-slate-400 mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 max-w-6xl mx-auto px-1"
            variants={containerVariants}
            initial="hidden"
            animate={isVisible ? "visible" : "hidden"}
          >
            {botCards.map((bot, index) => (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover={{ 
                  y: -8,
                  transition: { type: "spring", stiffness: 300 }
                }}
              >
                <Card className="bg-slate-800/50 backdrop-blur border-slate-700/50 h-full cursor-pointer group">
                  <CardContent className="p-4 sm:p-6">
                    <motion.div 
                      className={`flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br ${bot.gradient} text-white shadow-lg ${bot.shadow} mb-3 sm:mb-4`}
                      whileHover={{ rotate: 10, scale: 1.1 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <bot.icon className="w-5 h-5 sm:w-6 sm:h-6" />
                    </motion.div>
                    <h3 className="font-semibold text-sm sm:text-lg mb-1 sm:mb-2 text-white group-hover:text-blue-400 transition-colors">
                      {bot.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-400 line-clamp-3">
                      {bot.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
          
          <motion.div 
            className="mt-12 sm:mt-20 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.5 }}
          >
            <motion.div 
              className="flex flex-wrap justify-center gap-4 sm:gap-8 text-slate-400"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {[
                { icon: Shield, text: "Acceso Seguro", color: "text-emerald-400" },
                { icon: Zap, text: "Análisis con IA", color: "text-amber-400" },
                { icon: BarChart3, text: "Reportes Automáticos", color: "text-blue-400" }
              ].map((feature, index) => (
                <motion.div 
                  key={index}
                  className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-base"
                  variants={itemVariants}
                  whileHover={{ scale: 1.1 }}
                >
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                  >
                    <feature.icon className={`w-4 h-4 sm:w-5 sm:h-5 ${feature.color}`} />
                  </motion.div>
                  <span>{feature.text}</span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          <motion.div 
            className="mt-8 sm:mt-16 text-center pb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            <p className="text-xs sm:text-sm text-slate-500 px-4">
              Potenciado por inteligencia artificial para decisiones de negocio más inteligentes
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
