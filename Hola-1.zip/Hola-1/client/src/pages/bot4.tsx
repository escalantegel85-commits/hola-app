import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { GenerateExcelButton } from "@/components/generate-excel-button";
import { BotStatusCard } from "@/components/bot-status-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  FileSpreadsheet, 
  Download, 
  Mail, 
  Calendar,
  Clock,
  FileCheck,
  FileText
} from "lucide-react";
import type { Report, BotRun } from "@shared/schema";

interface Bot4Data {
  reports: Report[];
  lastRun: BotRun | null;
  stats: {
    totalReports: number;
    lastReportDate: string | null;
    emailsSent: number;
    totalProducts: number;
  };
}

function formatDate(date: string | null): string {
  if (!date) return "Nunca";
  return new Date(date).toLocaleString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Bot4Page() {
  const { toast } = useToast();

  const { data, isLoading } = useQuery<Bot4Data>({
    queryKey: ["/api/bots/4/reports"],
  });

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/reports/generate");
    },
    onSuccess: () => {
      toast({
        title: "Reporte Generado",
        description: "La hoja de cálculo ha sido generada y está lista para descargar",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/4/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const downloadReport = async (reportId: string, fileName: string) => {
    try {
      const response = await fetch(`/api/reports/${reportId}/download`);
      if (!response.ok) throw new Error("Error al descargar");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo descargar el reporte",
        variant: "destructive",
      });
    }
  };

  const stats = data?.stats || {
    totalReports: 0,
    lastReportDate: null,
    emailsSent: 0,
    totalProducts: 0,
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-purple-500/10">
              <FileSpreadsheet className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h1 className="text-3xl font-semibold">Generador de Reportes</h1>
          </div>
          <p className="text-muted-foreground">
            Descarga todos los productos en Excel para análisis detallado
          </p>
        </div>
        <GenerateExcelButton
          onClick={() => generateReportMutation.mutate()}
          isLoading={generateReportMutation.isPending}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <BotStatusCard
            botNumber={4}
            title="Reportes Excel"
            description="Genera reportes con todos los productos"
            lastRun={data?.lastRun}
            isRunning={generateReportMutation.isPending}
            onRun={() => generateReportMutation.mutate()}
          />
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Estadísticas de Reportes</CardTitle>
              <CardDescription>Resumen de reportes generados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <FileCheck className="w-4 h-4" />
                    Reportes Totales
                  </div>
                  <p className="text-2xl font-bold font-mono">{stats.totalReports}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Calendar className="w-4 h-4" />
                    Último Reporte
                  </div>
                  <p className="text-sm font-medium">{formatDate(stats.lastReportDate)}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Mail className="w-4 h-4" />
                    Emails Enviados
                  </div>
                  <p className="text-2xl font-bold font-mono">{stats.emailsSent}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    Productos Totales
                  </div>
                  <p className="text-2xl font-bold font-mono text-purple-600">{stats.totalProducts}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Historial de Reportes</CardTitle>
          <CardDescription>
            Descarga reportes generados anteriormente
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <Skeleton className="w-10 h-10 rounded-lg" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </div>
                  <Skeleton className="h-9 w-24" />
                </div>
              ))}
            </div>
          ) : data?.reports && data.reports.length > 0 ? (
            <div className="space-y-3">
              {data.reports.map((report) => (
                <div 
                  key={report.id} 
                  className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                  data-testid={`report-row-${report.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/10">
                      <FileSpreadsheet className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">{report.fileName}</p>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatDate(report.generatedAt?.toString() || null)}
                        </span>
                        <span>{report.productCount} productos</span>
                        {report.sentByEmail && (
                          <Badge variant="secondary" className="text-xs gap-1">
                            <Mail className="w-3 h-3" />
                            Enviado
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="default"
                      size="sm"
                      className="gap-2"
                      onClick={() => downloadReport(report.id, report.fileName)}
                      data-testid={`button-download-${report.id}`}
                    >
                      <Download className="w-4 h-4" />
                      CSV
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileSpreadsheet className="w-12 h-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">Sin reportes</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Genera tu primer reporte con el botón de arriba
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
