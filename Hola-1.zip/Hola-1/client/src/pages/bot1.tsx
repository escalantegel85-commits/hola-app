import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { ProductTable } from "@/components/product-table";
import { ProductFilters } from "@/components/product-filters";
import { BotStatusCard } from "@/components/bot-status-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Target, ShoppingCart, Store } from "lucide-react";
import type { Product, BotRun } from "@shared/schema";

interface Bot1Data {
  products: Product[];
  lastRun: BotRun | null;
  stats: {
    ebayProducts: number;
    mercadoLibreProducts: number;
    tiktokProducts: number;
    highDemand: number;
    worthPublishing: number;
  };
}

export default function Bot1Page() {
  const { toast } = useToast();
  const [filters, setFilters] = useState<Record<string, string | undefined>>({});

  const { data, isLoading } = useQuery<Bot1Data>({
    queryKey: ["/api/bots/1/products"],
  });

  const { data: filteredProducts } = useQuery<Product[]>({
    queryKey: ["/api/products/filter", { ...filters, botType: "1" }],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("botType", "1");
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });
      const res = await fetch(`/api/products/filter?${params}`);
      return res.json();
    },
    enabled: Object.keys(filters).some(k => filters[k] !== undefined),
  });

  const displayProducts = Object.values(filters).some(v => v !== undefined)
    ? (filteredProducts || [])
    : (data?.products || []);

  const runBotMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/bots/1/run");
    },
    onSuccess: () => {
      toast({
        title: "Bot Iniciado",
        description: "El Bot 1 ha comenzado a buscar productos ganadores",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/1/products"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stats = data?.stats || {
    ebayProducts: 0,
    mercadoLibreProducts: 0,
    tiktokProducts: 0,
    highDemand: 0,
    worthPublishing: 0,
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-blue-500/10">
              <Target className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h1 className="text-3xl font-semibold">Bot 1: Cazador de Productos Ganadores</h1>
          </div>
          <p className="text-muted-foreground">
            Investiga los productos más vendidos en eBay, Mercado Libre y TikTok Shop cada 6 horas
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <BotStatusCard
            botNumber={1}
            title="Bot 1: Productos Ganadores"
            description="Busca productos con alta demanda y baja competencia"
            lastRun={data?.lastRun}
            isRunning={runBotMutation.isPending}
            onRun={() => runBotMutation.mutate()}
          />
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Estadísticas del Bot</CardTitle>
              <CardDescription>Resumen de productos encontrados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <ShoppingCart className="w-4 h-4" />
                    eBay
                  </div>
                  <p className="text-2xl font-bold font-mono">{stats.ebayProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Store className="w-4 h-4" />
                    Mercado Libre
                  </div>
                  <p className="text-2xl font-bold font-mono">{stats.mercadoLibreProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-[#00F2EA]/10">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    TikTok Shop
                  </div>
                  <p className="text-2xl font-bold font-mono" style={{ color: "#00F2EA" }}>{stats.tiktokProducts}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    Alta Demanda
                  </div>
                  <p className="text-2xl font-bold font-mono text-green-600">{stats.highDemand}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    Vale Publicar
                  </div>
                  <p className="text-2xl font-bold font-mono text-blue-600">{stats.worthPublishing}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="text-xl">Productos Ganadores</CardTitle>
            <CardDescription>
              Productos con alto potencial de venta que puedes publicar hoy
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="gap-1">
              <ShoppingCart className="w-3 h-3" />
              eBay
            </Badge>
            <Badge variant="outline" className="gap-1">
              <Store className="w-3 h-3" />
              Mercado Libre
            </Badge>
            <Badge variant="outline" className="gap-1 bg-[#00F2EA]/10 border-[#00F2EA]/30">
              TikTok Shop
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <ProductFilters
            onFiltersChange={setFilters}
            showDemandLevel={true}
            showWorthPublishing={true}
          />
          <ProductTable 
            products={displayProducts} 
            isLoading={isLoading}
          />
        </CardContent>
      </Card>
    </div>
  );
}
