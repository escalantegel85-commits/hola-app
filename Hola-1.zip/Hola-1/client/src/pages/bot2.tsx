import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { ProductTable } from "@/components/product-table";
import { ProductFilters } from "@/components/product-filters";
import { BotStatusCard } from "@/components/bot-status-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Scale, TrendingUp, DollarSign, Percent } from "lucide-react";
import type { Product, BotRun } from "@shared/schema";

interface Bot2Data {
  products: Product[];
  lastRun: BotRun | null;
  stats: {
    totalOpportunities: number;
    avgProfitPercentage: number;
    totalPotentialProfit: number;
    bestMargin: number;
  };
}

export default function Bot2Page() {
  const { toast } = useToast();
  const [filters, setFilters] = useState<Record<string, string | undefined>>({});

  const { data, isLoading } = useQuery<Bot2Data>({
    queryKey: ["/api/bots/2/products"],
  });

  const { data: filteredProducts } = useQuery<Product[]>({
    queryKey: ["/api/products/filter", { ...filters, botType: "2" }],
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("botType", "2");
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.set(key, value);
      });
      const res = await fetch(`/api/products/filter?${params}`);
      return res.json();
    },
    enabled: Object.keys(filters).some(k => filters[k] !== undefined),
  });

  const displayProducts = Object.values(filters).some(v => v !== undefined)
    ? (filteredProducts || [])
    : (data?.products || []);

  const runBotMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/bots/2/run");
    },
    onSuccess: () => {
      toast({
        title: "Bot Iniciado",
        description: "El Bot 2 ha comenzado a buscar oportunidades de arbitraje",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/2/products"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stats = data?.stats || {
    totalOpportunities: 0,
    avgProfitPercentage: 0,
    totalPotentialProfit: 0,
    bestMargin: 0,
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-green-500/10">
              <Scale className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h1 className="text-3xl font-semibold">Bot 2: Comparador de Arbitraje</h1>
          </div>
          <p className="text-muted-foreground">
            Encuentra ganancias instantáneas comprando en Amazon, Walmart, AliExpress y vendiendo en eBay o Mercado Libre
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <BotStatusCard
            botNumber={2}
            title="Bot 2: Arbitraje"
            description="Compara precios 24/7 para encontrar oportunidades"
            lastRun={data?.lastRun}
            isRunning={runBotMutation.isPending}
            onRun={() => runBotMutation.mutate()}
          />
        </div>
        
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Oportunidades de Arbitraje</CardTitle>
              <CardDescription>Resumen de ganancias potenciales</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <TrendingUp className="w-4 h-4" />
                    Oportunidades
                  </div>
                  <p className="text-2xl font-bold font-mono">{stats.totalOpportunities}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Percent className="w-4 h-4" />
                    Margen Promedio
                  </div>
                  <p className="text-2xl font-bold font-mono text-green-600">
                    {stats.avgProfitPercentage.toFixed(1)}%
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <DollarSign className="w-4 h-4" />
                    Ganancia Total
                  </div>
                  <p className="text-2xl font-bold font-mono text-green-600">
                    ${stats.totalPotentialProfit.toLocaleString("es-ES")}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    Mejor Margen
                  </div>
                  <p className="text-2xl font-bold font-mono text-blue-600">
                    {stats.bestMargin.toFixed(1)}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="text-xl">Oportunidades de Arbitraje</CardTitle>
            <CardDescription>
              Productos listos para comprar y revender con ganancia garantizada
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="text-xs">Amazon</Badge>
            <Badge variant="secondary" className="text-xs">Walmart</Badge>
            <Badge variant="secondary" className="text-xs">AliExpress</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <ProductFilters
            onFiltersChange={setFilters}
            showDemandLevel={false}
          />
          <ProductTable 
            products={displayProducts} 
            isLoading={isLoading}
            showArbitrage
          />
        </CardContent>
      </Card>
    </div>
  );
}
