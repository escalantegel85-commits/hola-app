import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useState } from "react";
import {
  Upload,
  Store,
  DollarSign,
  Percent,
  TrendingUp,
  ExternalLink,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Info,
  ShoppingCart,
  Package,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "wouter";
import type { Product, MarketplaceConnection, PublishedListing } from "@shared/schema";

interface ProductWithListings extends Product {
  listings: PublishedListing[];
  canPublishTo: string[];
}

interface ReadyToPublishData {
  products: ProductWithListings[];
  connectedMarketplaces: string[];
}

const MARKETPLACE_NAMES: Record<string, string> = {
  mercadolibre: "Mercado Libre",
  ebay: "eBay",
};

export default function PublicarPage() {
  const { toast } = useToast();
  const [publishingProduct, setPublishingProduct] = useState<string | null>(null);

  const { data, isLoading, refetch } = useQuery<ReadyToPublishData>({
    queryKey: ["/api/products/ready-to-publish"],
  });

  const publishMutation = useMutation({
    mutationFn: async ({ productId, marketplace }: { productId: string; marketplace: string }) => {
      return await apiRequest("POST", `/api/products/${productId}/publish/${marketplace}`, {});
    },
    onSuccess: (result: any) => {
      toast({
        title: "Producto Publicado",
        description: result.message || "El producto ha sido publicado exitosamente.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products/ready-to-publish"] });
      queryClient.invalidateQueries({ queryKey: ["/api/listings"] });
      setPublishingProduct(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error al Publicar",
        description: error.message,
        variant: "destructive",
      });
      setPublishingProduct(null);
    },
  });

  const handlePublish = (productId: string, marketplace: string) => {
    setPublishingProduct(`${productId}-${marketplace}`);
    publishMutation.mutate({ productId, marketplace });
  };

  const formatPrice = (price: number | null, currency: string | null) => {
    if (price === null) return "-";
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: currency || "USD",
    }).format(price);
  };

  const formatPercent = (value: number | null) => {
    if (value === null) return "-";
    return `${value.toFixed(1)}%`;
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-8">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const hasNoConnections = !data?.connectedMarketplaces?.length;
  const hasNoProducts = !data?.products?.length;

  return (
    <div className="p-8 space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-muted">
            <Upload className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-semibold" data-testid="text-page-title">Publicar Productos</h1>
        </div>
        <p className="text-muted-foreground">
          Publica productos rentables en tus marketplaces conectados
        </p>
      </div>

      {hasNoConnections && (
        <Alert className="border-amber-500/50 bg-amber-500/10" data-testid="alert-no-connections">
          <AlertCircle className="h-4 w-4 text-amber-500" />
          <AlertTitle className="text-amber-600 dark:text-amber-400">Sin Marketplaces Conectados</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            <p className="mb-3">
              No tienes ningun marketplace conectado. Conecta tu cuenta de Mercado Libre o eBay para comenzar a publicar.
            </p>
            <Link href="/marketplaces">
              <Button variant="outline" size="sm" className="gap-2">
                <Store className="w-4 h-4" />
                Ir a Configurar Marketplaces
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {!hasNoConnections && (
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm text-muted-foreground">Marketplaces conectados:</span>
          {data?.connectedMarketplaces.map((mp) => (
            <Badge key={mp} variant="default" className="bg-green-500/20 text-green-600 dark:text-green-400">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              {MARKETPLACE_NAMES[mp] || mp}
            </Badge>
          ))}
        </div>
      )}

      {hasNoProducts ? (
        <Card data-testid="card-no-products">
          <CardContent className="py-12 text-center">
            <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Sin productos para publicar</h3>
            <p className="text-muted-foreground mb-4">
              No hay productos rentables listos para publicar. Ejecuta el Bot 2 para encontrar oportunidades de arbitraje.
            </p>
            <Link href="/bot2">
              <Button variant="outline" className="gap-2">
                <TrendingUp className="w-4 h-4" />
                Ir al Buscador de Arbitraje
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Card data-testid="card-products-table">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  Productos Listos para Publicar
                </CardTitle>
                <CardDescription>
                  {data?.products.length} productos con buen margen de ganancia
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => refetch()} className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Actualizar
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Producto</TableHead>
                    <TableHead className="text-right">Comprar en</TableHead>
                    <TableHead className="text-right">Vender en</TableHead>
                    <TableHead className="text-right">Ganancia</TableHead>
                    <TableHead className="text-right">Margen</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data?.products.map((product) => {
                    const isPublished = product.listings?.some((l) => l.status === "publicado");
                    const publishedMarketplaces = product.listings
                      ?.filter((l) => l.status === "publicado")
                      .map((l) => l.marketplace);

                    return (
                      <TableRow key={product.id} data-testid={`row-product-${product.id}`}>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="font-medium line-clamp-1">{product.name}</div>
                            <div className="text-xs text-muted-foreground">{product.category}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="space-y-1">
                            <Badge variant="outline" className="text-xs">
                              {product.sourceMarketplace}
                            </Badge>
                            <div className="text-sm font-mono">
                              {formatPrice(product.sourcePrice, product.sourceCurrency)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="space-y-1">
                            <Badge variant="outline" className="text-xs">
                              {product.targetMarketplace || "ML/eBay"}
                            </Badge>
                            <div className="text-sm font-mono">
                              {formatPrice(product.targetPrice, product.targetCurrency)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1 text-green-600 dark:text-green-400 font-medium">
                            <DollarSign className="w-3 h-3" />
                            {product.estimatedProfit?.toFixed(2) || "-"}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1 text-blue-600 dark:text-blue-400 font-medium">
                            <Percent className="w-3 h-3" />
                            {formatPercent(product.profitPercentage)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {isPublished ? (
                            <div className="flex flex-col gap-1">
                              {publishedMarketplaces?.map((mp) => (
                                <Badge key={mp} variant="default" className="bg-green-500/20 text-green-600 text-xs">
                                  <CheckCircle2 className="w-3 h-3 mr-1" />
                                  {MARKETPLACE_NAMES[mp] || mp}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <Badge variant="secondary" className="text-xs">
                              Sin publicar
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            {product.canPublishTo?.map((mp) => (
                              <Button
                                key={mp}
                                size="sm"
                                variant="outline"
                                className="gap-1 text-xs"
                                disabled={publishingProduct === `${product.id}-${mp}`}
                                onClick={() => handlePublish(product.id, mp)}
                                data-testid={`button-publish-${product.id}-${mp}`}
                              >
                                {publishingProduct === `${product.id}-${mp}` ? (
                                  <RefreshCw className="w-3 h-3 animate-spin" />
                                ) : (
                                  <Upload className="w-3 h-3" />
                                )}
                                {MARKETPLACE_NAMES[mp] || mp}
                              </Button>
                            ))}
                            {product.listings?.some((l) => l.status === "publicado" && l.listingUrl) && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="gap-1 text-xs"
                                onClick={() => {
                                  const listing = product.listings?.find((l) => l.listingUrl);
                                  if (listing?.listingUrl) window.open(listing.listingUrl, "_blank");
                                }}
                                data-testid={`button-view-${product.id}`}
                              >
                                <ExternalLink className="w-3 h-3" />
                                Ver
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <Alert className="border-blue-500/50 bg-blue-500/10" data-testid="alert-info">
        <Info className="h-4 w-4 text-blue-500" />
        <AlertTitle className="text-blue-600 dark:text-blue-400">Como funciona</AlertTitle>
        <AlertDescription className="text-muted-foreground">
          <ul className="list-disc list-inside space-y-1 mt-2">
            <li>Los productos mostrados tienen un margen de ganancia atractivo segun los analisis del Bot 2</li>
            <li>Al publicar, se crea automaticamente un listado en el marketplace seleccionado</li>
            <li>El precio de venta se calcula automaticamente para maximizar ganancias</li>
            <li>Puedes publicar el mismo producto en multiples marketplaces</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
}
