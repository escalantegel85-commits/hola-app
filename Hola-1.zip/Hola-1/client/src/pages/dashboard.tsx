import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { BotStatusCard } from "@/components/bot-status-card";
import { MetricsCard } from "@/components/metrics-card";
import { GenerateExcelButton } from "@/components/generate-excel-button";
import { ProductTable } from "@/components/product-table";
import { ProfitAlerts } from "@/components/profit-alerts";
import { ActivityChart } from "@/components/activity-chart";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Package, 
  TrendingUp, 
  Scale, 
  AlertTriangle,
  Target,
  RefreshCw,
  Flame,
  ExternalLink,
  ShoppingCart,
  Zap,
  BarChart3,
  Bot,
  Clock,
  CheckCircle2,
  Activity
} from "lucide-react";
import type { Product, BotRun, Settings } from "@shared/schema";
import { useMemo } from "react";

interface DashboardData {
  metrics: {
    totalProducts: number;
    potentialProfit: number;
    arbitrageOpportunities: number;
    lowStockProducts: number;
  };
  latestProducts: Product[];
  botRuns: Record<number, BotRun | null>;
}

const botDescriptions = {
  1: "Analiza productos más vendidos en eBay, Mercado Libre y TikTok Shop",
  2: "Compara precios entre Amazon, Walmart, AliExpress",
  3: "Detecta productos con bajo stock y alta demanda",
  4: "Recopila datos y genera hojas de cálculo",
};

export default function Dashboard() {
  const { toast } = useToast();

  const { data, isLoading } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
  });

  const { data: settings } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  const runBotMutation = useMutation({
    mutationFn: async (botType: number) => {
      return await apiRequest("POST", `/api/bots/${botType}/run`);
    },
    onSuccess: (_, botType) => {
      toast({
        title: "Bot Iniciado",
        description: `El Bot ${botType} ha comenzado a ejecutarse`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const refreshProductsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/products/refresh");
    },
    onSuccess: (data: any) => {
      toast({
        title: "Productos Actualizados",
        description: `Se encontraron ${data.totalProducts} productos nuevos`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const result = await apiRequest("POST", "/api/reports/generate");
      const reportData = await result.json();
      
      if (reportData.success && reportData.report?.id) {
        const downloadUrl = `/api/reports/${reportData.report.id}/download`;
        const fileName = reportData.report.fileName || `reporte_productos_${new Date().toISOString().slice(0, 10)}.csv`;
        
        try {
          const downloadResponse = await fetch(downloadUrl);
          if (!downloadResponse.ok) {
            throw new Error("Error al descargar el reporte");
          }
          const blob = await downloadResponse.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = fileName;
          a.style.display = "none";
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            window.URL.revokeObjectURL(url);
            if (a.parentNode) a.parentNode.removeChild(a);
          }, 250);
        } catch (downloadError) {
          console.log("Descarga blob falló, abriendo URL directamente");
          window.location.href = downloadUrl;
        }
      }
      return reportData;
    },
    onSuccess: () => {
      toast({
        title: "Reporte Generado",
        description: "La hoja de cálculo está lista para descargar",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const downloadPDFMutation = useMutation({
    mutationFn: async () => {
      const downloadUrl = "/api/reports/download-pdf";
      const fileName = `reporte_productos_${new Date().toISOString().slice(0, 10)}.pdf`;
      
      try {
        const response = await fetch(downloadUrl);
        if (!response.ok) {
          throw new Error("Error al generar el PDF");
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
          window.URL.revokeObjectURL(url);
          if (a.parentNode) a.parentNode.removeChild(a);
        }, 250);
      } catch (downloadError) {
        console.log("Descarga blob falló, abriendo URL directamente");
        window.location.href = downloadUrl;
      }
    },
    onSuccess: () => {
      toast({
        title: "Reporte PDF Generado",
        description: "El PDF está listo para descargar",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const metrics = data?.metrics || {
    totalProducts: 0,
    potentialProfit: 0,
    arbitrageOpportunities: 0,
    lowStockProducts: 0,
  };

  // Get top 10 best selling products
  const topSellingProducts = useMemo(() => {
    if (!data?.latestProducts) return [];
    return [...data.latestProducts]
      .filter(p => p.dailySales && p.dailySales > 0)
      .sort((a, b) => (b.dailySales || 0) - (a.dailySales || 0))
      .slice(0, 10);
  }, [data?.latestProducts]);

  // Calculate system status
  const activeBotsCount = Object.values(data?.botRuns || {}).filter(
    (run) => run?.status === "ejecutando"
  ).length;
  const completedToday = Object.values(data?.botRuns || {}).filter(
    (run) => run?.status === "completado" && 
    run?.completedAt && 
    new Date(run.completedAt).toDateString() === new Date().toDateString()
  ).length;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6">
      {/* Professional Header Section */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 sm:p-6 lg:p-8">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:32px_32px]" />
        <div className="absolute top-0 right-0 w-48 sm:w-96 h-48 sm:h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 sm:w-64 h-32 sm:h-64 bg-emerald-500/10 rounded-full blur-3xl" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 sm:gap-6">
          <div className="space-y-2 sm:space-y-3">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/25">
                <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-white">
                  Centro de Control
                </h1>
                <p className="text-slate-400 text-xs sm:text-sm lg:text-base">
                  G Mi Bot Empresarial
                </p>
              </div>
            </div>
            
            {/* Status indicators */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 pt-1 sm:pt-2">
              <div className="flex items-center gap-1.5 sm:gap-2 bg-white/5 backdrop-blur-sm rounded-full px-2 sm:px-3 py-1 sm:py-1.5 border border-white/10">
                <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] sm:text-xs text-slate-300">Activo</span>
              </div>
              {activeBotsCount > 0 && (
                <div className="flex items-center gap-1.5 sm:gap-2 bg-blue-500/10 backdrop-blur-sm rounded-full px-2 sm:px-3 py-1 sm:py-1.5 border border-blue-500/20">
                  <Activity className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-blue-400 animate-pulse" />
                  <span className="text-[10px] sm:text-xs text-blue-300">{activeBotsCount} bot{activeBotsCount > 1 ? 's' : ''}</span>
                </div>
              )}
              {completedToday > 0 && (
                <div className="flex items-center gap-1.5 sm:gap-2 bg-emerald-500/10 backdrop-blur-sm rounded-full px-2 sm:px-3 py-1 sm:py-1.5 border border-emerald-500/20">
                  <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-emerald-400" />
                  <span className="text-[10px] sm:text-xs text-emerald-300">{completedToday} hoy</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex flex-col items-start lg:items-end gap-2 sm:gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <Button
                onClick={() => refreshProductsMutation.mutate()}
                disabled={refreshProductsMutation.isPending}
                variant="outline"
                size="sm"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                data-testid="button-refresh-products"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshProductsMutation.isPending ? 'animate-spin' : ''}`} />
                {refreshProductsMutation.isPending ? 'Buscando...' : 'Nuevos Productos'}
              </Button>
              <GenerateExcelButton
                onClick={() => generateReportMutation.mutate()}
                isLoading={generateReportMutation.isPending}
                onDownloadPDF={() => downloadPDFMutation.mutate()}
                isPDFLoading={downloadPDFMutation.isPending}
              />
            </div>
            <p className="text-[10px] sm:text-xs text-slate-500">
              Última actualización: {new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}
            </p>
          </div>
        </div>
      </div>

      <ProfitAlerts 
        products={data?.latestProducts || []} 
        settings={settings || null}
      />

      {/* Metrics Section with improved styling */}
      <div className="space-y-2 sm:space-y-3">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
          <h2 className="text-base sm:text-lg font-semibold">Resumen del Día</h2>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <MetricsCard
            title="Productos Encontrados"
            value={metrics.totalProducts}
            icon={Package}
            testId="metric-total-products"
            index={0}
          />
          <MetricsCard
            title="Ganancia Potencial"
            value={`$${metrics.potentialProfit.toLocaleString("es-ES", { minimumFractionDigits: 2 })}`}
            icon={TrendingUp}
            testId="metric-potential-profit"
            index={1}
          />
          <MetricsCard
            title="Oportunidades Arbitraje"
            value={metrics.arbitrageOpportunities}
            icon={Scale}
            testId="metric-arbitrage"
            index={2}
          />
          <MetricsCard
            title="Productos Escasez"
            value={metrics.lowStockProducts}
            icon={AlertTriangle}
            testId="metric-low-stock"
            index={3}
          />
        </div>
      </div>

      {/* Activity Chart */}
      <ActivityChart />

      {/* Bots Section with improved layout */}
      <div className="space-y-2 sm:space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex items-center gap-2">
            <Bot className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
            <h2 className="text-base sm:text-lg font-semibold">Bots de Análisis</h2>
          </div>
          <div className="flex items-center gap-2 text-[10px] sm:text-xs text-muted-foreground bg-muted/50 rounded-full px-2 sm:px-3 py-1 sm:py-1.5">
            <RefreshCw className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
            <span>Bot 3 y 4 automáticos</span>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:gap-4">
          {[1, 2].map((botNumber) => (
            <BotStatusCard
              key={botNumber}
              botNumber={botNumber as 1 | 2 | 3 | 4}
              title={`Bot ${botNumber}`}
              description={botDescriptions[botNumber as keyof typeof botDescriptions]}
              lastRun={data?.botRuns?.[botNumber]}
              isRunning={runBotMutation.isPending && runBotMutation.variables === botNumber}
              onRun={() => runBotMutation.mutate(botNumber)}
            />
          ))}
        </div>
      </div>

      {/* TOP 10 MÁS VENDIDOS - Visible Section */}
      {topSellingProducts.length > 0 && (
        <Card>
          <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 pb-3 sm:pb-4">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-orange-500/10">
                <Flame className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
              </div>
              <div>
                <CardTitle className="text-base sm:text-xl font-semibold">TOP 10 Más Vendidos</CardTitle>
                <CardDescription className="text-xs sm:text-sm">Productos con más ventas diarias</CardDescription>
              </div>
            </div>
            <Badge variant="secondary" className="text-xs sm:text-sm w-fit">
              {topSellingProducts.length} productos
            </Badge>
          </CardHeader>
          <CardContent className="p-3 sm:p-6">
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
              {topSellingProducts.map((product, index) => (
                <Card key={product.id} className="overflow-visible relative group" data-testid={`top-product-${product.id}`}>
                  {/* Ranking Badge */}
                  <div className="absolute -top-1.5 -left-1.5 sm:-top-2 sm:-left-2 z-10">
                    <div className={`w-5 h-5 sm:w-7 sm:h-7 rounded-full flex items-center justify-center text-white text-[10px] sm:text-xs font-bold shadow-md ${
                      index === 0 ? 'bg-yellow-500' : 
                      index === 1 ? 'bg-gray-400' : 
                      index === 2 ? 'bg-amber-600' : 
                      'bg-muted-foreground'
                    }`}>
                      #{index + 1}
                    </div>
                  </div>
                  
                  <CardContent className="p-3 sm:p-4">
                    {/* Category Placeholder */}
                    <div className="relative aspect-square mb-2 sm:mb-3 rounded-md overflow-hidden bg-muted flex flex-col items-center justify-center">
                      <Package className="w-6 h-6 sm:w-10 sm:h-10 text-muted-foreground" />
                      {product.category && (
                        <span className="text-[10px] sm:text-xs text-muted-foreground mt-1 sm:mt-2 text-center px-1 sm:px-2 line-clamp-1">
                          {product.category}
                        </span>
                      )}
                      {(product.dailySales || 0) >= 50 && (
                        <div className="absolute top-0.5 right-0.5 sm:top-1 sm:right-1">
                          <Badge className="bg-orange-500 text-white text-[8px] sm:text-xs px-1 sm:px-1.5 py-0.5">
                            <Flame className="w-2 h-2 sm:w-3 sm:h-3 mr-0.5" />
                            TOP
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    {/* Product Info */}
                    <div className="space-y-1.5 sm:space-y-2">
                      <h4 className="font-medium text-xs sm:text-sm line-clamp-2 leading-tight min-h-[2rem] sm:min-h-[2.5rem]" title={product.name}>
                        {product.name}
                      </h4>
                      
                      <div className="flex items-center justify-between gap-1 sm:gap-2">
                        <div className="text-center">
                          <p className="text-sm sm:text-lg font-bold text-orange-500">{product.dailySales}</p>
                          <p className="text-[8px] sm:text-[10px] text-muted-foreground leading-none">ventas/día</p>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-xs sm:text-sm font-semibold">
                            {product.targetPrice?.toFixed(2) || product.sourcePrice?.toFixed(2) || '—'}
                          </p>
                          <Badge variant="secondary" className="text-[8px] sm:text-[10px] px-0.5 sm:px-1">
                            {product.targetCurrency || product.sourceCurrency || 'USD'}
                          </Badge>
                        </div>
                      </div>
                      
                      {/* Marketplace & Action */}
                      <div className="pt-1.5 sm:pt-2 border-t">
                        <div className="flex items-center justify-between gap-1 sm:gap-2">
                          <Badge variant="outline" className="text-[8px] sm:text-[10px] px-1 sm:px-1.5">
                            {product.sourceMarketplace}
                          </Badge>
                          {product.sourceUrl && (
                            <Button variant="outline" size="sm" asChild className="h-6 sm:h-7 text-[10px] sm:text-xs gap-0.5 sm:gap-1 px-1.5 sm:px-2">
                              <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                                <ShoppingCart className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                                <span className="hidden xs:inline">Comprar</span>
                              </a>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-4">
          <CardTitle className="text-base sm:text-xl font-semibold">Últimos Productos</CardTitle>
          <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-sm text-muted-foreground">
            <RefreshCw className="w-3 h-3 sm:w-4 sm:h-4" />
            Actualización cada 6 horas
          </div>
        </CardHeader>
        <CardContent className="p-3 sm:p-6">
          <Tabs defaultValue="todos" className="w-full">
            <TabsList className="mb-3 sm:mb-4 flex flex-wrap h-auto gap-1">
              <TabsTrigger value="todos" data-testid="tab-all-products" className="text-xs sm:text-sm">Todos</TabsTrigger>
              <TabsTrigger value="ganadores" data-testid="tab-winning-products" className="text-xs sm:text-sm gap-0.5 sm:gap-1">
                <Target className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden xs:inline">Ganadores</span>
              </TabsTrigger>
              <TabsTrigger value="arbitraje" data-testid="tab-arbitrage-products" className="text-xs sm:text-sm gap-0.5 sm:gap-1">
                <Scale className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden xs:inline">Arbitraje</span>
              </TabsTrigger>
              <TabsTrigger value="escasez" data-testid="tab-scarcity-products" className="text-xs sm:text-sm gap-0.5 sm:gap-1">
                <AlertTriangle className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden xs:inline">Escasez</span>
              </TabsTrigger>
            </TabsList>
            <TabsContent value="todos">
              <ProductTable 
                products={data?.latestProducts || []} 
                isLoading={isLoading}
                showArbitrage
              />
            </TabsContent>
            <TabsContent value="ganadores">
              <ProductTable 
                products={(data?.latestProducts || []).filter(p => p.botType === 1)} 
                isLoading={isLoading}
              />
            </TabsContent>
            <TabsContent value="arbitraje">
              <ProductTable 
                products={(data?.latestProducts || []).filter(p => p.botType === 2)} 
                isLoading={isLoading}
                showArbitrage
              />
            </TabsContent>
            <TabsContent value="escasez">
              <ProductTable 
                products={(data?.latestProducts || []).filter(p => p.botType === 3)} 
                isLoading={isLoading}
                showStock
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
