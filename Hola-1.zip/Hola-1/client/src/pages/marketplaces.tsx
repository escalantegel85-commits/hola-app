import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useState, useEffect } from "react";
import {
  Store,
  Link2,
  Unlink,
  ExternalLink,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Key,
  RefreshCw,
  Info,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import type { MarketplaceConnection } from "@shared/schema";

interface MarketplaceInfo {
  id: string;
  name: string;
  icon: string;
  description: string;
  devPortalUrl: string;
  setupSteps: string[];
}

const MARKETPLACES: MarketplaceInfo[] = [
  {
    id: "mercadolibre",
    name: "Mercado Libre",
    icon: "ML",
    description: "Conecta tu cuenta de vendedor de Mercado Libre para publicar productos automáticamente",
    devPortalUrl: "https://developers.mercadolibre.com.mx/devcenter",
    setupSteps: [
      "Ve al portal de desarrolladores de Mercado Libre",
      "Crea una nueva aplicación",
      "Copia tu App ID y Secret Key",
      "Configura la URL de redirección como se indica abajo",
    ],
  },
  {
    id: "ebay",
    name: "eBay",
    icon: "eB",
    description: "Conecta tu cuenta de vendedor de eBay para listar productos en el mercado internacional",
    devPortalUrl: "https://developer.ebay.com/my/keys",
    setupSteps: [
      "Ve al portal de desarrolladores de eBay",
      "Crea un conjunto de credenciales de API",
      "Selecciona Production environment",
      "Copia tu Client ID y Client Secret",
    ],
  },
];

export default function MarketplacesPage() {
  const { toast } = useToast();
  const [selectedMarketplace, setSelectedMarketplace] = useState<string | null>(null);
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: connections, isLoading } = useQuery<MarketplaceConnection[]>({
    queryKey: ["/api/marketplace/connections"],
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const connected = params.get("connected");
    const error = params.get("error");
    const message = params.get("message");

    if (connected) {
      toast({
        title: "Conexion Exitosa",
        description: `Tu cuenta de ${connected === "mercadolibre" ? "Mercado Libre" : "eBay"} ha sido conectada correctamente.`,
      });
      window.history.replaceState({}, "", window.location.pathname);
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace/connections"] });
    }

    if (error) {
      toast({
        title: "Error de Conexion",
        description: message ? decodeURIComponent(message) : `No se pudo conectar a ${error}.`,
        variant: "destructive",
      });
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [toast]);

  const connectMutation = useMutation({
    mutationFn: async ({ marketplace, clientId, clientSecret }: { marketplace: string; clientId: string; clientSecret: string }) => {
      return await apiRequest("POST", `/api/marketplace/connections/${marketplace}/credentials`, {
        clientId,
        clientSecret,
      });
    },
    onSuccess: (data: any) => {
      if (data.authUrl) {
        window.location.href = data.authUrl;
      } else {
        toast({
          title: "Credenciales Guardadas",
          description: "Ahora necesitas autorizar la conexión.",
        });
      }
      setDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async (marketplace: string) => {
      return await apiRequest("POST", `/api/marketplace/connections/${marketplace}/disconnect`, {});
    },
    onSuccess: () => {
      toast({
        title: "Desconectado",
        description: "La cuenta del marketplace ha sido desconectada.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace/connections"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getConnection = (marketplaceId: string): MarketplaceConnection | undefined => {
    return connections?.find((c) => c.marketplace === marketplaceId);
  };

  const handleConnect = () => {
    if (!selectedMarketplace || !clientId || !clientSecret) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos.",
        variant: "destructive",
      });
      return;
    }
    connectMutation.mutate({ marketplace: selectedMarketplace, clientId, clientSecret });
  };

  const openConnectDialog = (marketplaceId: string) => {
    setSelectedMarketplace(marketplaceId);
    setClientId("");
    setClientSecret("");
    setDialogOpen(true);
  };

  const getRedirectUri = (marketplaceId: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/api/auth/${marketplaceId}/callback`;
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-8">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-muted">
            <Store className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-semibold" data-testid="text-page-title">Marketplaces</h1>
        </div>
        <p className="text-muted-foreground">
          Conecta tus cuentas de vendedor para publicar productos automaticamente
        </p>
      </div>

      <Alert className="border-blue-500/50 bg-blue-500/10" data-testid="alert-setup-info">
        <Info className="h-4 w-4 text-blue-500" />
        <AlertTitle className="text-blue-600 dark:text-blue-400">Configuracion requerida</AlertTitle>
        <AlertDescription className="text-muted-foreground">
          Para conectar cada marketplace necesitas crear una aplicacion en su portal de desarrolladores 
          y obtener las credenciales de API (Client ID y Secret). Una vez conectado, podras publicar 
          productos directamente desde la plataforma.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 md:grid-cols-2">
        {MARKETPLACES.map((mp) => {
          const connection = getConnection(mp.id);
          const isConnected = connection?.isConnected === true;

          return (
            <Card key={mp.id} data-testid={`card-marketplace-${mp.id}`}>
              <CardHeader>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center font-bold text-lg">
                      {mp.icon}
                    </div>
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {mp.name}
                        {isConnected ? (
                          <Badge variant="default" className="bg-green-500/20 text-green-600 dark:text-green-400">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Conectado
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-muted-foreground">
                            <XCircle className="w-3 h-3 mr-1" />
                            No conectado
                          </Badge>
                        )}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {mp.description}
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {isConnected ? (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                      {connection?.userName && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Usuario:</span>
                          <span className="font-medium">{connection.userName}</span>
                        </div>
                      )}
                      {connection?.userId && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">ID:</span>
                          <span className="font-mono text-xs">{connection.userId}</span>
                        </div>
                      )}
                      {connection?.connectedAt && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Conectado:</span>
                          <span>{new Date(connection.connectedAt).toLocaleDateString()}</span>
                        </div>
                      )}
                      {connection?.expiresAt && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Expira:</span>
                          <span>{new Date(connection.expiresAt).toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1 gap-2"
                        onClick={() => disconnectMutation.mutate(mp.id)}
                        disabled={disconnectMutation.isPending}
                        data-testid={`button-disconnect-${mp.id}`}
                      >
                        <Unlink className="w-4 h-4" />
                        Desconectar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <Key className="w-4 h-4" />
                        Pasos para conectar:
                      </h4>
                      <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                        {mp.setupSteps.map((step, i) => (
                          <li key={i}>{step}</li>
                        ))}
                      </ol>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        variant="outline"
                        className="gap-2"
                        onClick={() => window.open(mp.devPortalUrl, "_blank")}
                        data-testid={`button-portal-${mp.id}`}
                      >
                        <ExternalLink className="w-4 h-4" />
                        Portal de Desarrolladores
                      </Button>
                      <Button
                        className="gap-2"
                        onClick={() => openConnectDialog(mp.id)}
                        data-testid={`button-connect-${mp.id}`}
                      >
                        <Link2 className="w-4 h-4" />
                        Conectar
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Conectar {selectedMarketplace === "mercadolibre" ? "Mercado Libre" : "eBay"}
            </DialogTitle>
            <DialogDescription>
              Ingresa las credenciales de API de tu aplicacion de desarrollador
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="clientId">Client ID / App ID</Label>
              <Input
                id="clientId"
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                placeholder="Ingresa tu Client ID"
                data-testid="input-client-id"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientSecret">Client Secret / Secret Key</Label>
              <Input
                id="clientSecret"
                type="password"
                value={clientSecret}
                onChange={(e) => setClientSecret(e.target.value)}
                placeholder="Ingresa tu Client Secret"
                data-testid="input-client-secret"
              />
            </div>
            <Alert data-testid="alert-redirect-uri">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>URL de Redireccion</AlertTitle>
              <AlertDescription>
                <p className="text-sm text-muted-foreground mb-2">
                  Configura esta URL en tu aplicacion del marketplace:
                </p>
                <code className="text-xs bg-muted p-2 rounded block break-all">
                  {selectedMarketplace && getRedirectUri(selectedMarketplace)}
                </code>
              </AlertDescription>
            </Alert>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleConnect}
              disabled={connectMutation.isPending || !clientId || !clientSecret}
              className="gap-2"
              data-testid="button-submit-credentials"
            >
              {connectMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Conectando...
                </>
              ) : (
                <>
                  <Link2 className="w-4 h-4" />
                  Autorizar Conexion
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
