import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { useAuth } from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";
import Dashboard from "@/pages/dashboard";
import Bot1Page from "@/pages/bot1";
import Bot2Page from "@/pages/bot2";
import Bot4Page from "@/pages/bot4";
import ConfiguracionPage from "@/pages/configuracion";
import HistorialPage from "@/pages/historial";
import TendenciasPage from "@/pages/tendencias";
import ListaCompraVentaPage from "@/pages/lista-compra-venta";
import MarketplacesPage from "@/pages/marketplaces";
import PublicarPage from "@/pages/publicar";
import Landing from "@/pages/landing";
import MasterPassword from "@/pages/master-password";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/bot1" component={Bot1Page} />
      <Route path="/bot2" component={Bot2Page} />
      <Route path="/bot4" component={Bot4Page} />
      <Route path="/configuracion" component={ConfiguracionPage} />
      <Route path="/historial" component={HistorialPage} />
      <Route path="/tendencias" component={TendenciasPage} />
      <Route path="/lista-compra-venta" component={ListaCompraVentaPage} />
      <Route path="/marketplaces" component={MarketplacesPage} />
      <Route path="/publicar" component={PublicarPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AuthenticatedApp() {
  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <SidebarInset className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 px-4 py-3 border-b bg-background sticky top-0 z-50">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto bg-muted/30">
            <Router />
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth();
  const [masterPasswordVerified, setMasterPasswordVerified] = useState(() => {
    return sessionStorage.getItem("masterPasswordVerified") === "true";
  });

  const { data: masterPasswordStatus, isLoading: isLoadingStatus } = useQuery({
    queryKey: ["/api/auth/master-password-status"],
    enabled: isAuthenticated && !isLoading,
  });

  if (isLoading || (isAuthenticated && isLoadingStatus)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  const needsMasterPassword = masterPasswordStatus?.isEnabled && !masterPasswordVerified;
  
  if (needsMasterPassword) {
    return <MasterPassword onSuccess={() => setMasterPasswordVerified(true)} />;
  }

  return <AuthenticatedApp />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
