import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Filter, X } from "lucide-react";

interface FilterOptions {
  categories: string[];
  marketplaces: string[];
  demandLevels: string[];
  stockLevels: string[];
}

interface ProductFiltersProps {
  onFiltersChange: (filters: Record<string, string | undefined>) => void;
  showBotType?: boolean;
  showDemandLevel?: boolean;
  showStockLevel?: boolean;
  showWorthPublishing?: boolean;
}

export function ProductFilters({
  onFiltersChange,
  showBotType = false,
  showDemandLevel = true,
  showStockLevel = false,
  showWorthPublishing = false,
}: ProductFiltersProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState<Record<string, string | undefined>>({});

  const { data: options } = useQuery<FilterOptions>({
    queryKey: ["/api/filters/options"],
  });

  const updateFilter = (key: string, value: string | undefined) => {
    const newFilters = { ...filters, [key]: value === "all" ? undefined : value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearFilters = () => {
    setFilters({});
    onFiltersChange({});
  };

  const hasActiveFilters = Object.values(filters).some(v => v !== undefined);

  const demandLabels: Record<string, string> = {
    alto: "Alta",
    medio: "Media",
    bajo: "Baja",
  };

  const stockLabels: Record<string, string> = {
    alto: "Alto",
    medio: "Medio",
    bajo: "Bajo",
    agotado: "Agotado",
  };

  const marketplaceLabels: Record<string, string> = {
    ebay: "eBay",
    mercadolibre: "Mercado Libre",
    amazon: "Amazon",
    walmart: "Walmart",
    aliexpress: "AliExpress",
    tiktokshop: "TikTok Shop",
  };

  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 mb-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="gap-2"
          data-testid="button-toggle-filters"
        >
          <Filter className="w-4 h-4" />
          {isExpanded ? "Ocultar Filtros" : "Mostrar Filtros"}
        </Button>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="gap-2 text-muted-foreground"
            data-testid="button-clear-filters"
          >
            <X className="w-4 h-4" />
            Limpiar
          </Button>
        )}
      </div>

      {isExpanded && (
        <Card>
          <CardContent className="pt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {showBotType && (
                <div className="space-y-1.5">
                  <Label>Bot</Label>
                  <Select
                    value={filters.botType || "all"}
                    onValueChange={(v) => updateFilter("botType", v)}
                  >
                    <SelectTrigger data-testid="select-filter-bot">
                      <SelectValue placeholder="Todos los bots" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los bots</SelectItem>
                      <SelectItem value="1">Bot 1 - Productos Ganadores</SelectItem>
                      <SelectItem value="2">Bot 2 - Arbitraje</SelectItem>
                      <SelectItem value="3">Bot 3 - Reabastecimiento</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-1.5">
                <Label>Categoría</Label>
                <Select
                  value={filters.category || "all"}
                  onValueChange={(v) => updateFilter("category", v)}
                >
                  <SelectTrigger data-testid="select-filter-category">
                    <SelectValue placeholder="Todas las categorías" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {options?.categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label>Marketplace</Label>
                <Select
                  value={filters.marketplace || "all"}
                  onValueChange={(v) => updateFilter("marketplace", v)}
                >
                  <SelectTrigger data-testid="select-filter-marketplace">
                    <SelectValue placeholder="Todos los marketplaces" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los marketplaces</SelectItem>
                    {options?.marketplaces.map((mp) => (
                      <SelectItem key={mp} value={mp}>
                        {marketplaceLabels[mp] || mp}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {showDemandLevel && (
                <div className="space-y-1.5">
                  <Label>Nivel de Demanda</Label>
                  <Select
                    value={filters.demandLevel || "all"}
                    onValueChange={(v) => updateFilter("demandLevel", v)}
                  >
                    <SelectTrigger data-testid="select-filter-demand">
                      <SelectValue placeholder="Todos los niveles" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los niveles</SelectItem>
                      {options?.demandLevels.map((level) => (
                        <SelectItem key={level} value={level}>
                          {demandLabels[level] || level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {showStockLevel && (
                <div className="space-y-1.5">
                  <Label>Nivel de Stock</Label>
                  <Select
                    value={filters.stockLevel || "all"}
                    onValueChange={(v) => updateFilter("stockLevel", v)}
                  >
                    <SelectTrigger data-testid="select-filter-stock">
                      <SelectValue placeholder="Todos los niveles" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los niveles</SelectItem>
                      {options?.stockLevels.map((level) => (
                        <SelectItem key={level} value={level}>
                          {stockLabels[level] || level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-1.5">
                <Label>Precio Mínimo</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={filters.minPrice || ""}
                  onChange={(e) => updateFilter("minPrice", e.target.value || undefined)}
                  data-testid="input-filter-min-price"
                />
              </div>

              <div className="space-y-1.5">
                <Label>Precio Máximo</Label>
                <Input
                  type="number"
                  placeholder="Sin límite"
                  value={filters.maxPrice || ""}
                  onChange={(e) => updateFilter("maxPrice", e.target.value || undefined)}
                  data-testid="input-filter-max-price"
                />
              </div>

              {showWorthPublishing && (
                <div className="space-y-1.5">
                  <Label>Solo Vale Publicar</Label>
                  <div className="flex items-center h-9">
                    <Switch
                      checked={filters.isWorthPublishing === "true"}
                      onCheckedChange={(checked) =>
                        updateFilter("isWorthPublishing", checked ? "true" : undefined)
                      }
                      data-testid="switch-filter-worth-publishing"
                    />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
