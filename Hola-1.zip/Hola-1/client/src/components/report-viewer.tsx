import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Download, X, Eye } from "lucide-react";

interface ReportViewerProps {
  isOpen: boolean;
  onClose: () => void;
  reportData: string | null;
  fileName: string;
  onDownload: () => void;
}

interface ParsedProduct {
  id: string;
  nombre: string;
  categoria: string;
  marketplaceOrigen: string;
  precioOrigen: string;
  monedaOrigen: string;
  marketplaceDestino: string;
  precioDestino: string;
  monedaDestino: string;
  gananciaEstimada: string;
  porcentajeGanancia: string;
  ventasDiarias: string;
  competidores: string;
  nivelStock: string;
  nivelDemanda: string;
  cambioPrecio: string;
  bot: string;
  valePublicar: string;
  fechaEncontrado: string;
}

function parseCSV(base64Data: string): ParsedProduct[] {
  try {
    const decoded = atob(base64Data);
    const lines = decoded.split("\n");
    
    if (lines.length < 2) return [];
    
    const products: ParsedProduct[] = [];
    
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const values: string[] = [];
      let current = "";
      let inQuotes = false;
      
      for (let j = 0; j < line.length; j++) {
        const char = line[j];
        if (char === '"') {
          if (inQuotes && line[j + 1] === '"') {
            current += '"';
            j++;
          } else {
            inQuotes = !inQuotes;
          }
        } else if (char === ',' && !inQuotes) {
          values.push(current);
          current = "";
        } else {
          current += char;
        }
      }
      values.push(current);
      
      if (values.length >= 19) {
        products.push({
          id: values[0] || "",
          nombre: values[1] || "",
          categoria: values[2] || "",
          marketplaceOrigen: values[3] || "",
          precioOrigen: values[4] || "",
          monedaOrigen: values[5] || "",
          marketplaceDestino: values[6] || "",
          precioDestino: values[7] || "",
          monedaDestino: values[8] || "",
          gananciaEstimada: values[9] || "",
          porcentajeGanancia: values[10] || "",
          ventasDiarias: values[11] || "",
          competidores: values[12] || "",
          nivelStock: values[13] || "",
          nivelDemanda: values[14] || "",
          cambioPrecio: values[15] || "",
          bot: values[16] || "",
          valePublicar: values[17] || "",
          fechaEncontrado: values[18] || "",
        });
      }
    }
    
    return products;
  } catch (error) {
    console.error("Error parsing CSV:", error);
    return [];
  }
}

function formatCurrency(value: string, currency: string): string {
  if (!value || value === "") return "-";
  const num = parseFloat(value);
  if (isNaN(num)) return "-";
  
  const symbols: Record<string, string> = {
    USD: "$",
    EUR: "€",
    MXN: "MX$",
    ARS: "AR$",
    BRL: "R$",
    CLP: "CL$",
    COP: "CO$",
  };
  
  const symbol = symbols[currency] || currency + " ";
  return `${symbol}${num.toLocaleString("es-ES", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function ReportViewer({ isOpen, onClose, reportData, fileName, onDownload }: ReportViewerProps) {
  const products = reportData ? parseCSV(reportData) : [];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[95vw] w-full max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Vista Previa del Reporte
          </DialogTitle>
          <DialogDescription className="flex items-center justify-between">
            <span>{fileName} - {products.length} productos</span>
            <Button variant="outline" size="sm" className="gap-2" onClick={onDownload}>
              <Download className="w-4 h-4" />
              Descargar CSV
            </Button>
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="flex-1 max-h-[70vh]">
          {products.length > 0 ? (
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead className="min-w-[200px]">Producto</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Origen</TableHead>
                  <TableHead className="text-right">Precio</TableHead>
                  <TableHead>Destino</TableHead>
                  <TableHead className="text-right">Precio Dest.</TableHead>
                  <TableHead className="text-right">Ganancia</TableHead>
                  <TableHead className="text-center">Ventas/Día</TableHead>
                  <TableHead>Bot</TableHead>
                  <TableHead className="text-center">Publicar</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product, index) => (
                  <TableRow key={product.id || index} data-testid={`report-product-row-${index}`}>
                    <TableCell className="font-medium max-w-[250px]">
                      <div className="truncate" title={product.nombre}>
                        {product.nombre || "Sin nombre"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {product.categoria || "-"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs capitalize">
                        {product.marketplaceOrigen || "-"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm">
                      {formatCurrency(product.precioOrigen, product.monedaOrigen)}
                    </TableCell>
                    <TableCell>
                      {product.marketplaceDestino ? (
                        <Badge variant="secondary" className="text-xs capitalize">
                          {product.marketplaceDestino}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm">
                      {formatCurrency(product.precioDestino, product.monedaDestino)}
                    </TableCell>
                    <TableCell className="text-right">
                      {product.gananciaEstimada ? (
                        <div className="flex flex-col items-end">
                          <span className="font-mono font-medium text-green-600 dark:text-green-400">
                            {formatCurrency(product.gananciaEstimada, product.monedaDestino || "USD")}
                          </span>
                          {product.porcentajeGanancia && (
                            <span className="text-xs text-muted-foreground">
                              +{parseFloat(product.porcentajeGanancia).toFixed(1)}%
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center font-mono">
                      {product.ventasDiarias || "-"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {product.bot}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {product.valePublicar === "Sí" ? (
                        <Badge className="bg-green-500/20 text-green-700 dark:text-green-400 text-xs">
                          Sí
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          No
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <p className="text-muted-foreground">No hay productos en este reporte</p>
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
