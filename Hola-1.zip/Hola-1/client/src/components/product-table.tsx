import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink, Package, TrendingUp, TrendingDown, Minus, ShoppingCart, Store, Flame, ArrowUpDown } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { Product } from "@shared/schema";
import { useState, useMemo } from "react";

import electronicaImg from "@assets/stock_images/smartphone_iphone_sa_d6150817.jpg";
import hogarImg from "@assets/stock_images/home_kitchen_applian_3912e830.jpg";
import modaImg from "@assets/stock_images/fashion_sneakers_sho_cadea70b.jpg";
import deportesImg from "@assets/stock_images/sports_fitness_gym_e_8c819c4f.jpg";
import juguetesImg from "@assets/stock_images/toys_lego_games_chil_33f52177.jpg";
import herramientasImg from "@assets/stock_images/power_tools_drill_co_9a1ca8a4.jpg";
import jardinImg from "@assets/stock_images/garden_lawn_mower_ou_12b367b6.jpg";
import bellezaImg from "@assets/stock_images/beauty_cosmetics_ski_5520ae6d.jpg";

const CATEGORY_IMAGES: Record<string, string> = {
  "Electrónica": electronicaImg,
  "Electronica": electronicaImg,
  "Electronics": electronicaImg,
  "Hogar": hogarImg,
  "Hogar y cocina": hogarImg,
  "Home": hogarImg,
  "Moda": modaImg,
  "Fashion": modaImg,
  "Ropa": modaImg,
  "Deportes": deportesImg,
  "Deportes y fitness": deportesImg,
  "Deportes y aire libre": deportesImg,
  "Sports": deportesImg,
  "Juguetes": juguetesImg,
  "Toys": juguetesImg,
  "Herramientas": herramientasImg,
  "Tools": herramientasImg,
  "Jardín": jardinImg,
  "Jardinería": jardinImg,
  "Garden": jardinImg,
  "Belleza": bellezaImg,
  "Beauty": bellezaImg,
  "Salud y bienestar": bellezaImg,
  "Accesorios móviles": electronicaImg,
  "Alimentación": hogarImg,
  "Mascotas": hogarImg,
};

function getCategoryImage(category: string | null | undefined): string | null {
  if (!category) return null;
  const normalizedCategory = category.trim();
  return CATEGORY_IMAGES[normalizedCategory] || null;
}

interface ProductTableProps {
  products: Product[];
  isLoading?: boolean;
  showArbitrage?: boolean;
  showStock?: boolean;
}

function formatCurrency(value: number | null | undefined, currency: string | null | undefined = "USD"): string {
  if (value === null || value === undefined) return "-";
  
  const currencyCode = currency || "USD";
  const formatted = value.toLocaleString("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  
  // Show currency code explicitly for clarity
  const currencyDisplay: Record<string, string> = {
    USD: "USD $",
    EUR: "EUR €",
    MXN: "MXN $",
    ARS: "ARS $",
    BRL: "BRL R$",
    CLP: "CLP $",
    COP: "COP $",
    CNY: "CNY ¥",
    GBP: "GBP £",
  };
  
  const prefix = currencyDisplay[currencyCode] || `${currencyCode} `;
  return `${prefix}${formatted}`;
}

function formatCurrencyShort(value: number | null | undefined, currency: string | null | undefined = "USD"): string {
  if (value === null || value === undefined) return "-";
  
  const currencyCode = currency || "USD";
  const formatted = value.toLocaleString("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  
  const symbols: Record<string, string> = {
    USD: "$",
    EUR: "€",
    MXN: "$",
    CNY: "¥",
    GBP: "£",
  };
  
  return `${symbols[currencyCode] || "$"}${formatted}`;
}

function getCurrencyBadge(currency: string | null | undefined) {
  const code = currency || "USD";
  const colors: Record<string, string> = {
    USD: "bg-green-500/20 text-green-700 dark:text-green-400",
    EUR: "bg-blue-500/20 text-blue-700 dark:text-blue-400",
    MXN: "bg-orange-500/20 text-orange-700 dark:text-orange-400",
    CNY: "bg-red-500/20 text-red-700 dark:text-red-400",
    GBP: "bg-purple-500/20 text-purple-700 dark:text-purple-400",
  };
  return (
    <Badge variant="secondary" className={`text-[10px] ml-1 ${colors[code] || ""}`}>
      {code}
    </Badge>
  );
}

function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined) return "-";
  return value.toLocaleString("es-ES");
}

function getStockBadge(level: string | null | undefined) {
  switch (level) {
    case "bajo":
      return <Badge variant="destructive" className="text-xs">Stock Bajo</Badge>;
    case "medio":
      return <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700 dark:text-yellow-400">Stock Medio</Badge>;
    case "alto":
      return <Badge variant="secondary" className="text-xs bg-green-500/20 text-green-700 dark:text-green-400">Stock Alto</Badge>;
    case "agotado":
      return <Badge variant="destructive" className="text-xs">Agotado</Badge>;
    default:
      return null;
  }
}

function getDemandBadge(level: string | null | undefined) {
  switch (level) {
    case "alto":
      return <Badge variant="secondary" className="text-xs bg-green-500/20 text-green-700 dark:text-green-400">Alta Demanda</Badge>;
    case "medio":
      return <Badge variant="secondary" className="text-xs">Demanda Media</Badge>;
    case "bajo":
      return <Badge variant="outline" className="text-xs">Baja Demanda</Badge>;
    default:
      return null;
  }
}

function getPriceChangeIcon(change: number | null | undefined) {
  if (change === null || change === undefined || change === 0) {
    return <Minus className="w-4 h-4 text-muted-foreground" />;
  }
  if (change > 0) {
    return <TrendingUp className="w-4 h-4 text-green-600" />;
  }
  return <TrendingDown className="w-4 h-4 text-red-600" />;
}

export function ProductTable({ products, isLoading, showArbitrage, showStock }: ProductTableProps) {
  const [sortBy, setSortBy] = useState<"sales" | "profit" | "default">("sales");
  
  // Sort products by daily sales (highest first) by default
  const sortedProducts = useMemo(() => {
    const sorted = [...products];
    if (sortBy === "sales") {
      sorted.sort((a, b) => (b.dailySales || 0) - (a.dailySales || 0));
    } else if (sortBy === "profit") {
      sorted.sort((a, b) => (b.estimatedProfit || 0) - (a.estimatedProfit || 0));
    }
    return sorted;
  }, [products, sortBy]);

  // Determine top sellers (top 20% or minimum 50 sales/day)
  const getTopSellerBadge = (dailySales: number | null | undefined) => {
    if (!dailySales) return null;
    if (dailySales >= 50) {
      return (
        <Badge className="text-xs bg-orange-500/20 text-orange-600 dark:text-orange-400 gap-1">
          <Flame className="w-3 h-3" />
          TOP VENTAS
        </Badge>
      );
    }
    if (dailySales >= 30) {
      return (
        <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-700 dark:text-yellow-400">
          Alta Rotacion
        </Badge>
      );
    }
    return null;
  };
  
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex items-center gap-4 p-4">
            <Skeleton className="w-20 h-20 rounded-lg" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
            <Skeleton className="h-8 w-24" />
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Package className="w-12 h-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium">Sin productos</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Ejecuta el bot para encontrar productos
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border overflow-hidden">
      <Table>
        <TableHeader className="sticky top-0 bg-card z-10">
          <TableRow>
            <TableHead className="w-24">Imagen</TableHead>
            <TableHead>Producto</TableHead>
            <TableHead>Comprar en (Precio)</TableHead>
            <TableHead>Vender en (Precio)</TableHead>
            <TableHead className="text-right">Ganancia Est.</TableHead>
            {showStock && (
              <>
                <TableHead>Stock</TableHead>
                <TableHead>Demanda</TableHead>
                <TableHead className="text-center">Precio</TableHead>
              </>
            )}
            <TableHead className="text-right">
              <Button 
                variant="ghost" 
                size="sm" 
                className="gap-1 -mr-2"
                onClick={() => setSortBy(sortBy === "sales" ? "default" : "sales")}
                data-testid="button-sort-sales"
              >
                Ventas/Dia
                <ArrowUpDown className="w-3 h-3" />
              </Button>
            </TableHead>
            <TableHead className="text-right">Competencia</TableHead>
            <TableHead className="text-center">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedProducts.map((product, index) => (
            <TableRow key={product.id} data-testid={`product-row-${product.id}`}>
              <TableCell>
                <div className="w-20 h-20 rounded-lg bg-muted flex flex-col items-center justify-center overflow-hidden relative">
                  <Package className="w-6 h-6 text-muted-foreground" />
                  {product.category && (
                    <span className="text-[9px] text-muted-foreground mt-1 text-center px-1 truncate max-w-full">
                      {product.category}
                    </span>
                  )}
                  {index < 3 && sortBy === "sales" && (product.dailySales || 0) >= 30 && (
                    <div className="absolute top-0 left-0 bg-orange-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-br">
                      #{index + 1}
                    </div>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <div className="max-w-xs">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-medium line-clamp-2">{product.name}</p>
                    {getTopSellerBadge(product.dailySales)}
                  </div>
                  {product.category && (
                    <p className="text-xs text-muted-foreground mt-1">{product.category}</p>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex flex-col gap-1">
                  <Badge variant="outline" className="text-xs capitalize bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/30 w-fit">
                    <ShoppingCart className="w-3 h-3 mr-1" />
                    {product.sourceMarketplace}
                  </Badge>
                  <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                    {formatCurrency(product.sourcePrice, product.sourceCurrency)}
                  </span>
                  {product.sourceUrl && (
                    <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:underline flex items-center gap-1">
                      <ExternalLink className="w-3 h-3" /> Ver tienda
                    </a>
                  )}
                </div>
              </TableCell>
              <TableCell>
                {product.targetMarketplace ? (
                  <div className="flex flex-col gap-1">
                    <Badge variant="outline" className="text-xs capitalize bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/30 w-fit">
                      <Store className="w-3 h-3 mr-1" />
                      {product.targetMarketplace}
                    </Badge>
                    <span className="font-mono font-bold text-green-600 dark:text-green-400">
                      {product.targetPrice ? formatCurrency(product.targetPrice, product.targetCurrency) : "-"}
                    </span>
                    {product.targetUrl && (
                      <a href={product.targetUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-green-500 hover:underline flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" /> Ver tienda
                      </a>
                    )}
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">-</span>
                )}
              </TableCell>
              <TableCell className="text-right">
                {product.estimatedProfit ? (
                  <div className="flex flex-col items-end">
                    <span className="font-mono font-medium text-green-600 dark:text-green-400">
                      {formatCurrency(product.estimatedProfit, product.targetCurrency || product.sourceCurrency)}
                    </span>
                    {product.profitPercentage && (
                      <span className="text-xs text-muted-foreground">
                        +{product.profitPercentage.toFixed(1)}%
                      </span>
                    )}
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">-</span>
                )}
              </TableCell>
              {showStock && (
                <>
                  <TableCell>{getStockBadge(product.stockLevel)}</TableCell>
                  <TableCell>{getDemandBadge(product.demandLevel)}</TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      {getPriceChangeIcon(product.priceChange)}
                      {product.priceChange !== null && product.priceChange !== undefined && product.priceChange !== 0 && (
                        <span className={`text-xs ${product.priceChange > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {product.priceChange > 0 ? '+' : ''}{product.priceChange.toFixed(1)}%
                        </span>
                      )}
                    </div>
                  </TableCell>
                </>
              )}
              <TableCell className="text-right">
                <div className="flex flex-col items-end">
                  <span className={`font-mono font-bold text-lg ${(product.dailySales || 0) >= 50 ? 'text-orange-600 dark:text-orange-400' : (product.dailySales || 0) >= 30 ? 'text-yellow-600 dark:text-yellow-400' : ''}`}>
                    {formatNumber(product.dailySales)}
                  </span>
                  <span className="text-xs text-muted-foreground">por dia</span>
                </div>
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatNumber(product.competitorCount)}
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-1">
                  {product.sourceUrl && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          asChild
                          className="gap-1 text-xs"
                          data-testid={`button-view-source-${product.id}`}
                        >
                          <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                            <ShoppingCart className="w-3 h-3" />
                            Comprar
                          </a>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Buscar en {product.sourceMarketplace} para comprar</p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                  {product.targetUrl && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="default"
                          size="sm"
                          asChild
                          className="gap-1 text-xs"
                          data-testid={`button-view-target-${product.id}`}
                        >
                          <a href={product.targetUrl} target="_blank" rel="noopener noreferrer">
                            <Store className="w-3 h-3" />
                            Vender
                          </a>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Buscar en {product.targetMarketplace} para vender</p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                  {!product.sourceUrl && !product.targetUrl && (
                    <span className="text-xs text-muted-foreground">-</span>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
