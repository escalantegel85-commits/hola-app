import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { Activity } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import type { BotRun } from "@shared/schema";

interface ChartDataPoint {
  fecha: string;
  bot1: number;
  bot2: number;
  total: number;
}

function generateChartData(botRuns: BotRun[]): ChartDataPoint[] {
  const last7Days: ChartDataPoint[] = [];
  const today = new Date();
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateStr = date.toLocaleDateString("es-ES", { weekday: "short", day: "numeric" });
    
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(date);
    dayEnd.setHours(23, 59, 59, 999);
    
    const bot1Runs = botRuns.filter(run => {
      if (run.botType !== 1 || !run.startedAt) return false;
      const runDate = new Date(run.startedAt);
      return runDate >= dayStart && runDate <= dayEnd;
    });
    
    const bot2Runs = botRuns.filter(run => {
      if (run.botType !== 2 || !run.startedAt) return false;
      const runDate = new Date(run.startedAt);
      return runDate >= dayStart && runDate <= dayEnd;
    });
    
    const bot1Products = bot1Runs.reduce((sum, run) => sum + (run.productsFound || 0), 0);
    const bot2Products = bot2Runs.reduce((sum, run) => sum + (run.productsFound || 0), 0);
    
    last7Days.push({
      fecha: dateStr,
      bot1: bot1Products,
      bot2: bot2Products,
      total: bot1Products + bot2Products
    });
  }
  
  return last7Days;
}

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <motion.div 
        className="bg-popover border border-border rounded-lg p-3 shadow-lg"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        <p className="font-medium text-sm mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-mono font-medium">{entry.value}</span>
          </div>
        ))}
      </motion.div>
    );
  }
  return null;
}

export function ActivityChart() {
  const { data: botRuns = [] } = useQuery<BotRun[]>({
    queryKey: ["/api/bot-runs"],
  });

  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 300);
    return () => clearTimeout(timer);
  }, []);

  const chartData = generateChartData(botRuns);
  const hasData = chartData.some(d => d.bot1 > 0 || d.bot2 > 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="col-span-full overflow-hidden" data-testid="activity-chart">
        <CardHeader className="flex flex-row items-center gap-2 sm:gap-3 pb-2 p-3 sm:p-6">
          <motion.div 
            className="p-1.5 sm:p-2 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-lg shadow-indigo-500/25"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Activity className="w-4 h-4 sm:w-5 sm:h-5" />
          </motion.div>
          <div>
            <CardTitle className="text-sm sm:text-base font-semibold">Actividad - Últimos 7 Días</CardTitle>
            <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">Productos por bot</p>
          </div>
        </CardHeader>
        <CardContent className="relative p-3 sm:p-6 pt-0 sm:pt-0">
          {!hasData && (
            <motion.div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center z-10 pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <p className="text-xs sm:text-sm text-muted-foreground">Ejecuta los bots para ver la actividad</p>
            </motion.div>
          )}
          <div className="h-[200px] sm:h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="gradientBot1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradientBot2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  vertical={false}
                  stroke="hsl(var(--border))"
                />
                <XAxis 
                  dataKey="fecha" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                  dx={-5}
                  width={30}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  wrapperStyle={{ paddingTop: "10px", fontSize: "10px" }}
                  formatter={(value) => (
                    <span className="text-[10px] sm:text-xs text-foreground">{value === "Bot 1 - Productos Top" ? "Bot 1" : value === "Bot 2 - Arbitraje" ? "Bot 2" : value}</span>
                  )}
                />
                <Area
                  type="monotone"
                  dataKey="bot1"
                  name="Bot 1 - Productos Top"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  fill="url(#gradientBot1)"
                  dot={{ fill: "#3b82f6", strokeWidth: 0, r: 4 }}
                  activeDot={{ r: 8, stroke: "#3b82f6", strokeWidth: 2, fill: "white" }}
                  isAnimationActive={isVisible}
                  animationBegin={0}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
                <Area
                  type="monotone"
                  dataKey="bot2"
                  name="Bot 2 - Arbitraje"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  fill="url(#gradientBot2)"
                  dot={{ fill: "#10b981", strokeWidth: 0, r: 4 }}
                  activeDot={{ r: 8, stroke: "#10b981", strokeWidth: 2, fill: "white" }}
                  isAnimationActive={isVisible}
                  animationBegin={300}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
