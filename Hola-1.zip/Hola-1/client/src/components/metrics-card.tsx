import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";

interface MetricsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  testId?: string;
  index?: number;
}

function AnimatedNumber({ value }: { value: string | number }) {
  const [displayValue, setDisplayValue] = useState<string | number>(typeof value === 'number' ? 0 : value);
  
  useEffect(() => {
    if (typeof value === 'number') {
      const duration = 1500;
      const startTime = Date.now();
      const startValue = 0;
      
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.floor(startValue + (value - startValue) * easeOut);
        setDisplayValue(current);
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setDisplayValue(value);
        }
      };
      
      requestAnimationFrame(animate);
    } else if (typeof value === 'string' && value.startsWith('$')) {
      const numericPart = parseFloat(value.replace(/[$,]/g, ''));
      if (!isNaN(numericPart)) {
        const duration = 1500;
        const startTime = Date.now();
        
        const animate = () => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          const easeOut = 1 - Math.pow(1 - progress, 3);
          const current = numericPart * easeOut;
          setDisplayValue(`$${current.toLocaleString("es-ES", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
          
          if (progress < 1) {
            requestAnimationFrame(animate);
          } else {
            setDisplayValue(value);
          }
        };
        
        requestAnimationFrame(animate);
      } else {
        setDisplayValue(value);
      }
    } else {
      setDisplayValue(value);
    }
  }, [value]);
  
  return <>{displayValue}</>;
}

export function MetricsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  testId,
  index = 0,
}: MetricsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        duration: 0.4, 
        delay: index * 0.1,
        type: "spring",
        stiffness: 100
      }}
      whileHover={{ y: -4 }}
    >
      <Card data-testid={testId} className="relative overflow-hidden group">
        <motion.div 
          className="absolute top-0 right-0 w-16 sm:w-24 h-16 sm:h-24 bg-gradient-to-br from-primary/5 to-primary/10 rounded-full blur-2xl"
          initial={{ opacity: 0.3, scale: 0.8 }}
          animate={{ opacity: 0.5, scale: 1 }}
          whileHover={{ opacity: 0.75, scale: 1.2 }}
          transition={{ duration: 0.3 }}
        />
        <CardContent className="p-3 sm:p-5">
          <div className="flex items-start justify-between gap-2 sm:gap-4">
            <div className="space-y-1 sm:space-y-2 min-w-0">
              <p className="text-[10px] sm:text-sm font-medium text-muted-foreground truncate">
                {title}
              </p>
              <motion.div 
                className="text-lg sm:text-2xl lg:text-3xl font-bold font-mono tracking-tight" 
                data-testid={`${testId}-value`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <AnimatedNumber value={value} />
              </motion.div>
              {subtitle && (
                <p className="text-[8px] sm:text-xs text-muted-foreground">{subtitle}</p>
              )}
              {trend && (
                <motion.div 
                  className={`inline-flex items-center gap-0.5 sm:gap-1 text-[8px] sm:text-xs font-medium px-1.5 sm:px-2 py-0.5 rounded-full ${
                    trend.isPositive 
                      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" 
                      : "bg-red-500/10 text-red-600 dark:text-red-400"
                  }`}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  {trend.isPositive ? "+" : ""}{trend.value}%
                </motion.div>
              )}
            </div>
            <motion.div 
              className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-primary/10 text-primary shrink-0"
              whileHover={{ scale: 1.15, rotate: 10 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
            </motion.div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
