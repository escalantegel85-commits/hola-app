import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target, 
  Scale, 
  Package, 
  FileSpreadsheet,
  Play,
  Loader2,
  Check,
  AlertCircle
} from "lucide-react";
import type { BotRun } from "@shared/schema";

interface BotStatusCardProps {
  botNumber: 1 | 2 | 3 | 4;
  title: string;
  description: string;
  lastRun?: BotRun | null;
  isRunning?: boolean;
  onRun: () => void;
}

const botIcons = {
  1: Target,
  2: Scale,
  3: Package,
  4: FileSpreadsheet,
};

const botColors = {
  1: "bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/25",
  2: "bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/25",
  3: "bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-lg shadow-orange-500/25",
  4: "bg-gradient-to-br from-violet-500 to-violet-600 text-white shadow-lg shadow-violet-500/25",
};

const botAccentColors = {
  1: "from-blue-500/5 to-blue-500/10",
  2: "from-emerald-500/5 to-emerald-500/10",
  3: "from-orange-500/5 to-orange-500/10",
  4: "from-violet-500/5 to-violet-500/10",
};

function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "Nunca";
  const d = new Date(date);
  return d.toLocaleString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function getStatusBadge(status: string | undefined) {
  switch (status) {
    case "ejecutando":
      return (
        <Badge variant="secondary" className="gap-1">
          <Loader2 className="w-3 h-3 animate-spin" />
          Ejecutando
        </Badge>
      );
    case "completado":
      return (
        <Badge variant="default" className="gap-1 bg-green-600">
          <Check className="w-3 h-3" />
          Completado
        </Badge>
      );
    case "error":
      return (
        <Badge variant="destructive" className="gap-1">
          <AlertCircle className="w-3 h-3" />
          Error
        </Badge>
      );
    default:
      return (
        <Badge variant="outline" className="gap-1">
          En espera
        </Badge>
      );
  }
}

export function BotStatusCard({
  botNumber,
  title,
  description,
  lastRun,
  isRunning,
  onRun,
}: BotStatusCardProps) {
  const Icon = botIcons[botNumber];
  const colorClass = botColors[botNumber];
  const accentClass = botAccentColors[botNumber];

  return (
    <Card className="relative overflow-hidden group">
      <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${accentClass} rounded-full blur-2xl opacity-60`} />
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-3 relative">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl ${colorClass}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <CardTitle className="text-base font-semibold">{title}</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{description}</p>
          </div>
        </div>
        {getStatusBadge(lastRun?.status)}
      </CardHeader>
      <CardContent className="space-y-4 relative">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-xs text-muted-foreground block mb-1">Última ejecución</span>
            <p className="text-sm font-medium">{formatDate(lastRun?.completedAt || lastRun?.startedAt)}</p>
          </div>
          <div className="bg-muted/50 rounded-lg p-3">
            <span className="text-xs text-muted-foreground block mb-1">Productos encontrados</span>
            <p className="text-sm font-bold font-mono">{lastRun?.productsFound ?? 0}</p>
          </div>
        </div>
        {isRunning && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Progreso</span>
              <span>Analizando...</span>
            </div>
            <Progress value={undefined} className="h-2" />
          </div>
        )}
        <Button
          className="w-full gap-2"
          onClick={onRun}
          disabled={isRunning}
          data-testid={`button-run-bot-${botNumber}`}
        >
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Ejecutando...
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              Ejecutar Ahora
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
