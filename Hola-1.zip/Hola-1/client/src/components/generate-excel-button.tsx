import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FileSpreadsheet, Download, Loader2, FileText, ChevronDown, Sparkles } from "lucide-react";

interface GenerateExcelButtonProps {
  onClick: () => void;
  isLoading?: boolean;
  onDownloadPDF?: () => void;
  isPDFLoading?: boolean;
}

export function GenerateExcelButton({ 
  onClick, 
  isLoading, 
  onDownloadPDF, 
  isPDFLoading 
}: GenerateExcelButtonProps) {
  const isAnyLoading = isLoading || isPDFLoading;

  return (
    <div className="flex items-center gap-2">
      <Button
        size="lg"
        onClick={onClick}
        disabled={isAnyLoading}
        className="relative gap-2 py-5 px-6 text-base font-semibold bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white shadow-lg shadow-emerald-500/25 border-0"
        data-testid="button-generate-excel"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Generando...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Generar Hoja de Cálculo</span>
            <span className="sm:hidden">Generar Excel</span>
            <Download className="w-4 h-4" />
          </>
        )}
      </Button>

      {onDownloadPDF && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="lg"
              variant="outline"
              disabled={isAnyLoading}
              className="py-5 px-3 border-white/20 bg-white/5 hover:bg-white/10 text-white"
              data-testid="button-export-dropdown"
            >
              {isPDFLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem 
              onClick={onClick}
              disabled={isAnyLoading}
              data-testid="menu-item-csv"
              className="gap-2"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Descargar CSV/Excel
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={onDownloadPDF}
              disabled={isAnyLoading}
              data-testid="menu-item-pdf"
              className="gap-2"
            >
              <FileText className="w-4 h-4" />
              Descargar PDF
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
}
