import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bell, TrendingUp, DollarSign, ShoppingCart, Store, X } from "lucide-react";
import { formatCurrency } from "@/lib/currency";
import { useState } from "react";
import type { Product, Settings } from "@shared/schema";

interface ProfitAlertsProps {
  products: Product[];
  settings: Settings | null;
  compact?: boolean;
}

export function ProfitAlerts({ products, settings, compact = false }: ProfitAlertsProps) {
  const [dismissedAlerts, setDismissedAlerts] = useState<Set<string>>(new Set());

  if (!settings?.alertsEnabled) {
    return null;
  }

  const minProfit = settings.minProfitAlert ?? 20;
  const minPercentage = settings.minProfitPercentageAlert ?? 15;

  const alertProducts = products.filter((p) => {
    if (dismissedAlerts.has(p.id)) return false;
    const meetsProfit = p.estimatedProfit && p.estimatedProfit >= minProfit;
    const meetsPercentage = p.profitPercentage && p.profitPercentage >= minPercentage;
    return meetsProfit || meetsPercentage;
  });

  if (alertProducts.length === 0) {
    return null;
  }

  const dismissAlert = (id: string) => {
    setDismissedAlerts((prev) => {
      const newSet = new Set(prev);
      newSet.add(id);
      return newSet;
    });
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-green-500/10 border border-green-500/20 rounded-lg">
        <Bell className="w-4 h-4 text-green-600 dark:text-green-400 animate-pulse" />
        <span className="text-sm font-medium text-green-700 dark:text-green-300">
          {alertProducts.length} producto{alertProducts.length !== 1 ? "s" : ""} con alta rentabilidad
        </span>
        <Badge variant="secondary" className="bg-green-500/20 text-green-700 dark:text-green-300">
          Ver
        </Badge>
      </div>
    );
  }

  return (
    <Card className="border-green-500/30 bg-green-500/5">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/20">
              <Bell className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <CardTitle className="text-lg text-green-700 dark:text-green-300">
                Alertas de Rentabilidad
              </CardTitle>
              <CardDescription>
                Productos que superan tus umbrales configurados
              </CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className="bg-green-500/20 text-green-700 dark:text-green-300">
            {alertProducts.length} alerta{alertProducts.length !== 1 ? "s" : ""}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="max-h-64">
          <div className="space-y-3">
            {alertProducts.slice(0, 5).map((product) => (
              <div
                key={product.id}
                className="flex items-center justify-between gap-4 p-3 rounded-lg bg-background/80 border"
                data-testid={`alert-product-${product.id}`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <p className="text-sm font-medium truncate">{product.name}</p>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                    <span className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      Ganancia: {formatCurrency(product.estimatedProfit || 0, product.targetCurrency || "USD")}
                    </span>
                    <span className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      Margen: {(product.profitPercentage || 0).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-xs">
                      <ShoppingCart className="w-3 h-3 mr-1" />
                      Comprar: {product.sourceMarketplace}
                    </Badge>
                    {product.targetMarketplace && (
                      <Badge variant="secondary" className="text-xs bg-blue-500/20 text-blue-700 dark:text-blue-300">
                        <Store className="w-3 h-3 mr-1" />
                        Vender: {product.targetMarketplace}
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {product.sourceUrl && (
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      className="text-xs gap-1"
                      data-testid={`button-buy-product-${product.id}`}
                    >
                      <a href={product.sourceUrl} target="_blank" rel="noopener noreferrer">
                        <ShoppingCart className="w-3 h-3" />
                        Comprar
                      </a>
                    </Button>
                  )}
                  {product.targetUrl && (
                    <Button
                      variant="default"
                      size="sm"
                      asChild
                      className="text-xs gap-1"
                      data-testid={`button-sell-product-${product.id}`}
                    >
                      <a href={product.targetUrl} target="_blank" rel="noopener noreferrer">
                        <Store className="w-3 h-3" />
                        Vender
                      </a>
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => dismissAlert(product.id)}
                    data-testid={`button-dismiss-alert-${product.id}`}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            {alertProducts.length > 5 && (
              <p className="text-sm text-center text-muted-foreground py-2">
                +{alertProducts.length - 5} productos más con alertas
              </p>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
