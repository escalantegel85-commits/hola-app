const currencySymbols: Record<string, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  MXN: "MX$",
  ARS: "AR$",
  BRL: "R$",
  CLP: "CL$",
  COP: "CO$",
  PEN: "S/.",
  CNY: "¥",
  JPY: "¥",
};

export function formatCurrency(amount: number, currency: string = "USD"): string {
  const symbol = currencySymbols[currency] || currency + " ";
  return `${symbol}${amount.toLocaleString("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function getCurrencySymbol(currency: string): string {
  return currencySymbols[currency] || currency;
}
